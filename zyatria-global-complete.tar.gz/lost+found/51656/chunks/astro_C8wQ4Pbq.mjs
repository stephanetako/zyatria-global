globalThis.process ??= {}; globalThis.process.env ??= {};
import './astro/server_BbsiYKQe.mjs';
