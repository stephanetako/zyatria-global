globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, f as createAstro, r as renderTemplate, o as renderSlot, p as renderHead, h as addAttribute } from './astro/server_BbsiYKQe.mjs';
/* empty css                         */
import { a as reactExports } from './_@astro-renderers_Bjg41kJa.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro = createAstro();
const $$Main = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Main;
  const {
    pageClass = "",
    title = "ZyatrIA Global | AI Agents & Automation Without Borders",
    description = "Transform your business with intelligent AI agents and advanced automation. Deploy in 7-15 days. Available in North America, Europe, Africa, and Latin America.",
    ogImage = "/og-image.svg",
    canonical
  } = Astro2.props;
  const canonicalURL = canonical || (Astro2.site ? new URL(Astro2.url.pathname, Astro2.site) : Astro2.url.pathname);
  return renderTemplate(_a || (_a = __template(['<html lang="en"', '> <head><meta charset="utf-8"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><meta name="viewport" content="width=device-width"><meta name="generator"', "><!-- Primary Meta Tags --><title>", '</title><meta name="title"', '><meta name="description"', '><link rel="canonical"', '><!-- Open Graph / Facebook --><meta property="og:type" content="website"><meta property="og:url"', '><meta property="og:title"', '><meta property="og:description"', '><meta property="og:image"', '><!-- Twitter --><meta property="twitter:card" content="summary_large_image"><meta property="twitter:url"', '><meta property="twitter:title"', '><meta property="twitter:description"', '><meta property="twitter:image"', '><!-- Additional SEO --><meta name="robots" content="index, follow"><meta name="language" content="English"><meta name="author" content="ZyatrIA Global"><meta name="keywords" content="AI agents, automation, business automation, intelligent agents, micro-agents, CRM automation, workflow automation, AI without borders"><!-- Schema.org structured data --><script type="application/ld+json">\n{\n  "@context": "https://schema.org",\n  "@type": "Organization",\n  "name": "ZyatrIA Global",\n  "alternateName": "ZyatrIA",\n  "url": "https://zyatria.global",\n  "logo": "https://zyatria.global/logo.png",\n  "description": "International AI agency providing intelligent agents, advanced automation, and specialized micro-agents. Deploy in 7-15 days with multilingual support.",\n  "sameAs": [\n    "https://www.linkedin.com/company/zyatria-global",\n    "https://twitter.com/zyatriaglobal",\n    "https://www.facebook.com/zyatriaglobal"\n  ],\n  "contactPoint": {\n    "@type": "ContactPoint",\n    "telephone": "+1-555-123-4567",\n    "contactType": "Customer Service",\n    "areaServed": ["US", "CA", "FR", "ES", "PT", "BR"],\n    "availableLanguage": ["English", "French", "Spanish", "Portuguese"]\n  },\n  "address": {\n    "@type": "PostalAddress",\n    "addressCountry": "CA",\n    "addressRegion": "QC",\n    "addressLocality": "Montreal"\n  },\n  "founder": {\n    "@type": "Organization",\n    "name": "ZyatrIA Global Team"\n  },\n  "foundingDate": "2024",\n  "slogan": "AI Without Borders",\n  "aggregateRating": {\n    "@type": "AggregateRating",\n    "ratingValue": "4.9",\n    "reviewCount": "127",\n    "bestRating": "5"\n  }\n}\n<\/script><script type="application/ld+json">\n{\n  "@context": "https://schema.org",\n  "@type": "WebSite",\n  "name": "ZyatrIA Global",\n  "url": "https://zyatria.global",\n  "description": "Transform your business with intelligent AI agents and advanced automation. Deploy in 7-15 days. Available in North America, Europe, Africa, and Latin America.",\n  "inLanguage": ["en", "fr", "es", "pt"],\n  "potentialAction": {\n    "@type": "SearchAction",\n    "target": "https://zyatria.global/search?q={search_term_string}",\n    "query-input": "required name=search_term_string"\n  }\n}\n<\/script><script type="application/ld+json">\n{\n  "@context": "https://schema.org",\n  "@type": "WebPage",\n  "name": title,\n  "description": description,\n  "url": canonicalURL,\n  "inLanguage": "en",\n  "isPartOf": {\n    "@type": "WebSite",\n    "url": "https://zyatria.global"\n  },\n  "about": {\n    "@type": "Thing",\n    "name": "Artificial Intelligence Agents"\n  },\n  "audience": {\n    "@type": "BusinessAudience",\n    "audienceType": "Small and Medium Enterprises"\n  }\n}\n<\/script><!-- Preconnect to improve performance --><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><!-- DNS prefetch for external resources --><link rel="dns-prefetch" href="https://formspree.io"><!-- Alternate language versions --><link rel="alternate" hreflang="en"', '><link rel="alternate" hreflang="fr"', '><link rel="alternate" hreflang="es"', '><link rel="alternate" hreflang="pt"', '><link rel="alternate" hreflang="x-default"', ">", '</head> <!-- Dark mode class injection point - will be replaced with `dark` class based on your site palette --> <body class="__DARK_MODE_CLASS__"> ', " </body></html>"], ['<html lang="en"', '> <head><meta charset="utf-8"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><meta name="viewport" content="width=device-width"><meta name="generator"', "><!-- Primary Meta Tags --><title>", '</title><meta name="title"', '><meta name="description"', '><link rel="canonical"', '><!-- Open Graph / Facebook --><meta property="og:type" content="website"><meta property="og:url"', '><meta property="og:title"', '><meta property="og:description"', '><meta property="og:image"', '><!-- Twitter --><meta property="twitter:card" content="summary_large_image"><meta property="twitter:url"', '><meta property="twitter:title"', '><meta property="twitter:description"', '><meta property="twitter:image"', '><!-- Additional SEO --><meta name="robots" content="index, follow"><meta name="language" content="English"><meta name="author" content="ZyatrIA Global"><meta name="keywords" content="AI agents, automation, business automation, intelligent agents, micro-agents, CRM automation, workflow automation, AI without borders"><!-- Schema.org structured data --><script type="application/ld+json">\n{\n  "@context": "https://schema.org",\n  "@type": "Organization",\n  "name": "ZyatrIA Global",\n  "alternateName": "ZyatrIA",\n  "url": "https://zyatria.global",\n  "logo": "https://zyatria.global/logo.png",\n  "description": "International AI agency providing intelligent agents, advanced automation, and specialized micro-agents. Deploy in 7-15 days with multilingual support.",\n  "sameAs": [\n    "https://www.linkedin.com/company/zyatria-global",\n    "https://twitter.com/zyatriaglobal",\n    "https://www.facebook.com/zyatriaglobal"\n  ],\n  "contactPoint": {\n    "@type": "ContactPoint",\n    "telephone": "+1-555-123-4567",\n    "contactType": "Customer Service",\n    "areaServed": ["US", "CA", "FR", "ES", "PT", "BR"],\n    "availableLanguage": ["English", "French", "Spanish", "Portuguese"]\n  },\n  "address": {\n    "@type": "PostalAddress",\n    "addressCountry": "CA",\n    "addressRegion": "QC",\n    "addressLocality": "Montreal"\n  },\n  "founder": {\n    "@type": "Organization",\n    "name": "ZyatrIA Global Team"\n  },\n  "foundingDate": "2024",\n  "slogan": "AI Without Borders",\n  "aggregateRating": {\n    "@type": "AggregateRating",\n    "ratingValue": "4.9",\n    "reviewCount": "127",\n    "bestRating": "5"\n  }\n}\n<\/script><script type="application/ld+json">\n{\n  "@context": "https://schema.org",\n  "@type": "WebSite",\n  "name": "ZyatrIA Global",\n  "url": "https://zyatria.global",\n  "description": "Transform your business with intelligent AI agents and advanced automation. Deploy in 7-15 days. Available in North America, Europe, Africa, and Latin America.",\n  "inLanguage": ["en", "fr", "es", "pt"],\n  "potentialAction": {\n    "@type": "SearchAction",\n    "target": "https://zyatria.global/search?q={search_term_string}",\n    "query-input": "required name=search_term_string"\n  }\n}\n<\/script><script type="application/ld+json">\n{\n  "@context": "https://schema.org",\n  "@type": "WebPage",\n  "name": title,\n  "description": description,\n  "url": canonicalURL,\n  "inLanguage": "en",\n  "isPartOf": {\n    "@type": "WebSite",\n    "url": "https://zyatria.global"\n  },\n  "about": {\n    "@type": "Thing",\n    "name": "Artificial Intelligence Agents"\n  },\n  "audience": {\n    "@type": "BusinessAudience",\n    "audienceType": "Small and Medium Enterprises"\n  }\n}\n<\/script><!-- Preconnect to improve performance --><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><!-- DNS prefetch for external resources --><link rel="dns-prefetch" href="https://formspree.io"><!-- Alternate language versions --><link rel="alternate" hreflang="en"', '><link rel="alternate" hreflang="fr"', '><link rel="alternate" hreflang="es"', '><link rel="alternate" hreflang="pt"', '><link rel="alternate" hreflang="x-default"', ">", '</head> <!-- Dark mode class injection point - will be replaced with \\`dark\\` class based on your site palette --> <body class="__DARK_MODE_CLASS__"> ', " </body></html>"])), addAttribute(pageClass, "class"), addAttribute(Astro2.generator, "content"), title, addAttribute(title, "content"), addAttribute(description, "content"), addAttribute(canonicalURL, "href"), addAttribute(canonicalURL, "content"), addAttribute(title, "content"), addAttribute(description, "content"), addAttribute(ogImage, "content"), addAttribute(canonicalURL, "content"), addAttribute(title, "content"), addAttribute(description, "content"), addAttribute(ogImage, "content"), addAttribute(canonicalURL, "href"), addAttribute(canonicalURL.toString().replace("/en/", "/fr/"), "href"), addAttribute(canonicalURL.toString().replace("/en/", "/es/"), "href"), addAttribute(canonicalURL.toString().replace("/en/", "/pt/"), "href"), addAttribute(canonicalURL, "href"), renderHead(), renderSlot($$result, $$slots["default"]));
}, "/app/src/layouts/main.astro", void 0);

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
);
const toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
const mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();
const hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
};

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Icon = reactExports.forwardRef(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => reactExports.createElement(
    "svg",
    {
      ref,
      ...defaultAttributes,
      width: size,
      height: size,
      stroke: color,
      strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
      className: mergeClasses("lucide", className),
      ...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
      ...rest
    },
    [
      ...iconNode.map(([tag, attrs]) => reactExports.createElement(tag, attrs)),
      ...Array.isArray(children) ? children : [children]
    ]
  )
);

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const createLucideIcon = (iconName, iconNode) => {
  const Component = reactExports.forwardRef(
    ({ className, ...props }, ref) => reactExports.createElement(Icon, {
      ref,
      iconNode,
      className: mergeClasses(
        `lucide-${toKebabCase(toPascalCase(iconName))}`,
        `lucide-${iconName}`,
        className
      ),
      ...props
    })
  );
  Component.displayName = toPascalCase(iconName);
  return Component;
};

export { $$Main as $, createLucideIcon as c };
