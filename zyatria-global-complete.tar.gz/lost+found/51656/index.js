globalThis.process ??= {}; globalThis.process.env ??= {};
import { r as renderers } from './chunks/_@astro-renderers_Bjg41kJa.mjs';
import { c as createExports, s as serverEntrypointModule } from './chunks/_@astrojs-ssr-adapter_B3gR_JZ9.mjs';
import { manifest } from './manifest_5bE5tE5G.mjs';

const serverIslandMap = new Map();;

const _page0 = () => import('./pages/_image.astro.mjs');
const _page1 = () => import('./pages/about.astro.mjs');
const _page2 = () => import('./pages/api/create-checkout-session.astro.mjs');
const _page3 = () => import('./pages/demo.astro.mjs');
const _page4 = () => import('./pages/docs.astro.mjs');
const _page5 = () => import('./pages/knowledge-base.astro.mjs');
const _page6 = () => import('./pages/micro-agents.astro.mjs');
const _page7 = () => import('./pages/pricing.astro.mjs');
const _page8 = () => import('./pages/privacy.astro.mjs');
const _page9 = () => import('./pages/services.astro.mjs');
const _page10 = () => import('./pages/success.astro.mjs');
const _page11 = () => import('./pages/technology.astro.mjs');
const _page12 = () => import('./pages/terms.astro.mjs');
const _page13 = () => import('./pages/index.astro.mjs');
const pageMap = new Map([
    ["node_modules/@astrojs/cloudflare/dist/entrypoints/image-endpoint.js", _page0],
    ["src/pages/about.astro", _page1],
    ["src/pages/api/create-checkout-session.ts", _page2],
    ["src/pages/demo.astro", _page3],
    ["src/pages/docs.astro", _page4],
    ["src/pages/knowledge-base.astro", _page5],
    ["src/pages/micro-agents.astro", _page6],
    ["src/pages/pricing.astro", _page7],
    ["src/pages/privacy.astro", _page8],
    ["src/pages/services.astro", _page9],
    ["src/pages/success.astro", _page10],
    ["src/pages/technology.astro", _page11],
    ["src/pages/terms.astro", _page12],
    ["src/pages/index.astro", _page13]
]);

const _manifest = Object.assign(manifest, {
    pageMap,
    serverIslandMap,
    renderers,
    actions: () => import('./_noop-actions.mjs'),
    middleware: () => import('./_astro-internal_middleware.mjs')
});
const _args = undefined;
const _exports = createExports(_manifest);
const __astrojsSsrVirtualEntry = _exports.default;
const _start = 'start';
if (Object.prototype.hasOwnProperty.call(serverEntrypointModule, _start)) {
	serverEntrypointModule[_start](_manifest, _args);
}

export { __astrojsSsrVirtualEntry as default, pageMap };
