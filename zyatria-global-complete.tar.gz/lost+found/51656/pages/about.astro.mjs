globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BbsiYKQe.mjs';
import { $ as $$Main } from '../chunks/createLucideIcon_n5yAuAg7.mjs';
import { N as Navigation } from '../chunks/Navigation_DO2jpLlf.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_Bjg41kJa.mjs';

const $$About = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "\xC0 Propos de ZyatrIA Global | Agence IA Internationale | Entreprise Canadienne Qu\xE9bec",
    description: "ZyatrIA Global est une agence d'intelligence artificielle internationale bas\xE9e au Qu\xE9bec, Canada. Nous d\xE9veloppons des agents IA intelligents et des micro-agents sp\xE9cialis\xE9s pour les entreprises en Am\xE9rique du Nord, Europe, Afrique francophone et Am\xE9rique Latine. L'IA sans fronti\xE8res.",
    ogImage: "/og-image-about.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "AboutPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/AboutPage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/about.astro", void 0);

const $$file = "/app/src/pages/about.astro";
const $$url = "/about";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$About,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
