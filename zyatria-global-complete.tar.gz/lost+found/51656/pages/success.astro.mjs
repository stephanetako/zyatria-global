globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BbsiYKQe.mjs';
import { c as createLucideIcon, $ as $$Main } from '../chunks/createLucideIcon_n5yAuAg7.mjs';
/* empty css                                   */
export { r as renderers } from '../chunks/_@astro-renderers_Bjg41kJa.mjs';

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$4 = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }]
];
const ArrowRight = createLucideIcon("arrow-right", __iconNode$4);

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$3 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }]
];
const Calendar = createLucideIcon("calendar", __iconNode$3);

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$2 = [
  ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
];
const CircleCheckBig = createLucideIcon("circle-check-big", __iconNode$2);

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$1 = [
  ["path", { d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7", key: "132q7q" }],
  ["rect", { x: "2", y: "4", width: "20", height: "16", rx: "2", key: "izxlao" }]
];
const Mail = createLucideIcon("mail", __iconNode$1);

/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ],
  ["path", { d: "M20 2v4", key: "1rf3ol" }],
  ["path", { d: "M22 4h-4", key: "gwowj6" }],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
];
const Sparkles = createLucideIcon("sparkles", __iconNode);

const $$Success = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Paiement R\xE9ussi ! | ZyatrIA Global",
    description: "Bienvenue dans la famille ZyatrIA ! Votre abonnement a \xE9t\xE9 activ\xE9 avec succ\xE8s.",
    ogImage: "/og-image-success.svg"
  };
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage, "data-astro-cid-5y44lzmc": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="min-h-screen bg-gradient-to-b from-background to-muted/20 flex items-center justify-center px-4 py-12" data-astro-cid-5y44lzmc> <div class="max-w-2xl w-full" data-astro-cid-5y44lzmc>  <div class="bg-card border border-border rounded-2xl shadow-2xl p-8 md:p-12 text-center animate-fade-in-up" data-astro-cid-5y44lzmc>  <div class="flex justify-center mb-6 animate-scale-in delay-200" data-astro-cid-5y44lzmc> <div class="w-24 h-24 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center" data-astro-cid-5y44lzmc> ${renderComponent($$result2, "CheckCircle", CircleCheckBig, { "class": "w-14 h-14 text-green-600 dark:text-green-400", "data-astro-cid-5y44lzmc": true })} </div> </div>  <h1 class="text-3xl md:text-4xl font-bold font-heading mb-4 animate-fade-in-up delay-300" data-astro-cid-5y44lzmc>
🎉 Paiement Réussi !
</h1>  <p class="text-xl text-muted-foreground mb-8 animate-fade-in-up delay-400" data-astro-cid-5y44lzmc>
Bienvenue dans la famille ZyatrIA Global
</p>  <div class="bg-primary/5 border border-primary/20 rounded-lg p-6 mb-8 animate-fade-in-up delay-500" data-astro-cid-5y44lzmc> <p class="text-foreground mb-2" data-astro-cid-5y44lzmc> <strong data-astro-cid-5y44lzmc>Votre abonnement a été activé avec succès ! ✓</strong> </p> <p class="text-sm text-muted-foreground" data-astro-cid-5y44lzmc>
Un email de confirmation vous a été envoyé avec tous les détails.
</p> </div>  <div class="text-left mb-8 animate-fade-in-up delay-600" data-astro-cid-5y44lzmc> <h2 class="text-xl font-semibold font-heading mb-4 text-center" data-astro-cid-5y44lzmc>
📋 Prochaines Étapes
</h2> <div class="space-y-4" data-astro-cid-5y44lzmc>  <div class="flex items-start gap-4 bg-muted/50 rounded-lg p-4" data-astro-cid-5y44lzmc> <div class="flex-shrink-0" data-astro-cid-5y44lzmc> ${renderComponent($$result2, "Mail", Mail, { "class": "w-6 h-6 text-primary mt-1", "data-astro-cid-5y44lzmc": true })} </div> <div data-astro-cid-5y44lzmc> <h3 class="font-semibold mb-1" data-astro-cid-5y44lzmc>1. Vérifiez votre email</h3> <p class="text-sm text-muted-foreground" data-astro-cid-5y44lzmc>
Nous vous avons envoyé un email de bienvenue avec vos identifiants de connexion et les prochaines étapes.
</p> </div> </div>  <div class="flex items-start gap-4 bg-muted/50 rounded-lg p-4" data-astro-cid-5y44lzmc> <div class="flex-shrink-0" data-astro-cid-5y44lzmc> ${renderComponent($$result2, "Calendar", Calendar, { "class": "w-6 h-6 text-primary mt-1", "data-astro-cid-5y44lzmc": true })} </div> <div data-astro-cid-5y44lzmc> <h3 class="font-semibold mb-1" data-astro-cid-5y44lzmc>2. Réservez votre appel de lancement</h3> <p class="text-sm text-muted-foreground" data-astro-cid-5y44lzmc>
Notre équipe vous contactera dans les 24h pour programmer votre session d'onboarding personnalisée.
</p> </div> </div>  <div class="flex items-start gap-4 bg-muted/50 rounded-lg p-4" data-astro-cid-5y44lzmc> <div class="flex-shrink-0" data-astro-cid-5y44lzmc> ${renderComponent($$result2, "Sparkles", Sparkles, { "class": "w-6 h-6 text-primary mt-1", "data-astro-cid-5y44lzmc": true })} </div> <div data-astro-cid-5y44lzmc> <h3 class="font-semibold mb-1" data-astro-cid-5y44lzmc>3. Configuration de votre micro-agent</h3> <p class="text-sm text-muted-foreground" data-astro-cid-5y44lzmc>
Nous déployons votre solution IA en 7-15 jours. Vous recevrez des mises à jour régulières sur l'avancement.
</p> </div> </div> </div> </div>  <div class="flex flex-wrap justify-center gap-6 mb-8 text-sm text-muted-foreground animate-fade-in-up delay-700" data-astro-cid-5y44lzmc> <div class="flex items-center gap-2" data-astro-cid-5y44lzmc> ${renderComponent($$result2, "CheckCircle", CircleCheckBig, { "class": "w-4 h-4 text-green-500", "data-astro-cid-5y44lzmc": true })} <span data-astro-cid-5y44lzmc>Paiement sécurisé</span> </div> <div class="flex items-center gap-2" data-astro-cid-5y44lzmc> ${renderComponent($$result2, "CheckCircle", CircleCheckBig, { "class": "w-4 h-4 text-green-500", "data-astro-cid-5y44lzmc": true })} <span data-astro-cid-5y44lzmc>Support 24/7</span> </div> <div class="flex items-center gap-2" data-astro-cid-5y44lzmc> ${renderComponent($$result2, "CheckCircle", CircleCheckBig, { "class": "w-4 h-4 text-green-500", "data-astro-cid-5y44lzmc": true })} <span data-astro-cid-5y44lzmc>Annulation facile</span> </div> </div>  <div class="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up delay-800" data-astro-cid-5y44lzmc> <a href="/" class="inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl" data-astro-cid-5y44lzmc>
Retour à l'accueil
${renderComponent($$result2, "ArrowRight", ArrowRight, { "class": "w-4 h-4", "data-astro-cid-5y44lzmc": true })} </a> <a href="/demo" class="inline-flex items-center justify-center gap-2 px-6 py-3 bg-secondary text-secondary-foreground rounded-lg font-semibold hover:bg-secondary/80 transition-all" data-astro-cid-5y44lzmc>
Nous contacter
</a> </div>  <div class="mt-8 pt-8 border-t border-border animate-fade-in-up delay-900" data-astro-cid-5y44lzmc> <p class="text-sm text-muted-foreground mb-2" data-astro-cid-5y44lzmc>
Besoin d'aide ? Notre équipe est là pour vous.
</p> <div class="flex flex-wrap justify-center gap-4 text-sm" data-astro-cid-5y44lzmc> <a href="mailto:support@zyatria.global" class="text-primary hover:underline" data-astro-cid-5y44lzmc>
support@zyatria.global
</a> <span class="text-muted-foreground" data-astro-cid-5y44lzmc>•</span> <a href="/demo" class="text-primary hover:underline" data-astro-cid-5y44lzmc>
Planifier un appel
</a> </div> </div> </div>  <div class="mt-8 text-center text-sm text-muted-foreground animate-fade-in-up delay-1000" data-astro-cid-5y44lzmc> <p data-astro-cid-5y44lzmc>
Merci de faire confiance à ZyatrIA Global 🙏
</p> <p class="mt-2" data-astro-cid-5y44lzmc>
Questions ? Consultez notre <a href="/knowledge-base" class="text-primary hover:underline" data-astro-cid-5y44lzmc>base de connaissances</a> </p> </div> </div> </div> ` })} `;
}, "/app/src/pages/success.astro", void 0);

const $$file = "/app/src/pages/success.astro";
const $$url = "/success";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Success,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
