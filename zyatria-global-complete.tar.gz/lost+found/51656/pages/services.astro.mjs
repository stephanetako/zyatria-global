globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BbsiYKQe.mjs';
import { $ as $$Main } from '../chunks/createLucideIcon_n5yAuAg7.mjs';
import { N as Navigation } from '../chunks/Navigation_DO2jpLlf.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_Bjg41kJa.mjs';

const $$Services = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Nos Services IA | Agents Intelligents, Automatisation & Micro-Agents | ZyatrIA Global",
    description: "D\xE9couvrez nos services d'intelligence artificielle : agents IA conversationnels 24/7, automatisation avanc\xE9e de workflows, et micro-agents sp\xE9cialis\xE9s pour votre secteur. Support multilingue (FR, EN, ES, PT). D\xE9ploiement en 7-15 jours.",
    ogImage: "/og-image-services.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "ServicesPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/ServicesPage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/services.astro", void 0);

const $$file = "/app/src/pages/services.astro";
const $$url = "/services";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Services,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
