globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BbsiYKQe.mjs';
import { $ as $$Main } from '../chunks/createLucideIcon_n5yAuAg7.mjs';
import { N as Navigation } from '../chunks/Navigation_DO2jpLlf.mjs';
/* empty css                                 */
export { r as renderers } from '../chunks/_@astro-renderers_Bjg41kJa.mjs';

const $$Terms = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Terms of Service | ZyatrIA Global - AI Agents & Automation",
    description: "Terms of service and conditions for using ZyatrIA Global's AI agents and automation services.",
    ogImage: "/og-image.svg"
  };
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage, "data-astro-cid-y5py4vqc": true }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default", "data-astro-cid-y5py4vqc": true })} ${maybeRenderHead()}<main class="min-h-screen bg-background pt-24 pb-16" data-astro-cid-y5py4vqc> <div class="container-responsive max-w-4xl mx-auto" data-astro-cid-y5py4vqc> <!-- Header --> <div class="mb-12" data-astro-cid-y5py4vqc> <h1 class="text-4xl md:text-5xl font-bold text-foreground mb-4" data-astro-cid-y5py4vqc>
Terms of Service
</h1> <p class="text-muted-foreground text-lg" data-astro-cid-y5py4vqc>
Last updated: ${(/* @__PURE__ */ new Date()).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })} </p> </div> <!-- Content --> <div class="prose prose-lg max-w-none" data-astro-cid-y5py4vqc> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>1. Agreement to Terms</h2> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
By accessing or using ZyatrIA Global's services ("Services"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, please do not use our Services.
</p> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
These Terms constitute a legally binding agreement between you (either an individual or entity) and ZyatrIA Global, a Canadian company based in Quebec.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>2. Services Description</h2> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
ZyatrIA Global provides the following services:
</p> <ul class="list-disc pl-6 text-muted-foreground space-y-2" data-astro-cid-y5py4vqc> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Intelligent AI Agents:</strong> Custom AI solutions for business automation</li> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Advanced Automation:</strong> Workflow optimization and process automation</li> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Micro-Agents:</strong> Specialized AI agents for specific business functions</li> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Consulting and Support:</strong> Implementation, training, and ongoing support</li> </ul> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>3. Subscription Plans</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>3.1 Plans Available</h3> <ul class="list-disc pl-6 text-muted-foreground space-y-3" data-astro-cid-y5py4vqc> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Starter Plan:</strong> 69 CAD/month - 1 AI micro-agent, 24/7 responses, email support</li> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Business Plan:</strong> 169 CAD/month - 3 AI micro-agents, advanced automation, CRM integration, priority support</li> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Enterprise Plan:</strong> 500 CAD/month - Custom AI agents, complete automation, dedicated support</li> </ul> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>3.2 Free Trial</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
All plans include a 7-day free trial. You will not be charged until the trial period ends. You may cancel anytime during the trial without charge.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>3.3 Billing</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
Subscriptions are billed monthly in Canadian dollars (CAD). Payments are processed securely through Stripe. By subscribing, you authorize us to charge your payment method on a recurring basis.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>4. Payment Terms</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>4.1 Payment Processing</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
All payments are processed by Stripe, Inc. We do not store your payment card information. Stripe's terms and privacy policy apply to all transactions.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>4.2 Automatic Renewal</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
Your subscription will automatically renew at the end of each billing period unless you cancel before the renewal date.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>4.3 Price Changes</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
We reserve the right to modify subscription prices. We will provide at least 30 days' notice before any price increase. Continued use of the Services after the price change constitutes acceptance.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>4.4 Refunds</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
Refunds are provided on a case-by-case basis. If you cancel during the free trial, you will not be charged. For paid subscriptions, please contact us to discuss refund eligibility.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>5. Cancellation and Termination</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>5.1 Your Right to Cancel</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
You may cancel your subscription at any time through your account settings or by contacting us. Cancellation takes effect at the end of the current billing period.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>5.2 Our Right to Terminate</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
We may suspend or terminate your access to the Services if you:
</p> <ul class="list-disc pl-6 text-muted-foreground space-y-2" data-astro-cid-y5py4vqc> <li data-astro-cid-y5py4vqc>Violate these Terms</li> <li data-astro-cid-y5py4vqc>Engage in fraudulent activity</li> <li data-astro-cid-y5py4vqc>Fail to pay fees when due</li> <li data-astro-cid-y5py4vqc>Use the Services in a manner that harms us or others</li> </ul> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>5.3 Effect of Termination</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
Upon termination, your right to use the Services ceases immediately. We may delete your data in accordance with our data retention policy.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>6. User Responsibilities</h2> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>You agree to:</p> <ul class="list-disc pl-6 text-muted-foreground space-y-2" data-astro-cid-y5py4vqc> <li data-astro-cid-y5py4vqc>Provide accurate and complete information</li> <li data-astro-cid-y5py4vqc>Maintain the security of your account credentials</li> <li data-astro-cid-y5py4vqc>Use the Services in compliance with applicable laws</li> <li data-astro-cid-y5py4vqc>Not interfere with or disrupt the Services</li> <li data-astro-cid-y5py4vqc>Not attempt to gain unauthorized access to our systems</li> <li data-astro-cid-y5py4vqc>Not use the Services for illegal or harmful purposes</li> <li data-astro-cid-y5py4vqc>Not resell or redistribute the Services without permission</li> </ul> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>7. Intellectual Property</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>7.1 Our Property</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
All content, features, and functionality of the Services, including but not limited to text, graphics, logos, software, and AI models, are owned by ZyatrIA Global and protected by copyright, trademark, and other intellectual property laws.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>7.2 Your Data</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
You retain all rights to data you provide to the Services. By using the Services, you grant us a limited license to use your data solely to provide the Services.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>7.3 Feedback</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
If you provide feedback or suggestions, we may use them without obligation to you.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>8. Service Level and Availability</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>8.1 Uptime</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
We strive to maintain 99.9% uptime but do not guarantee uninterrupted access. The Services may be temporarily unavailable for maintenance, updates, or due to factors beyond our control.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>8.2 Support</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
Support availability varies by plan:
</p> <ul class="list-disc pl-6 text-muted-foreground space-y-2 mt-4" data-astro-cid-y5py4vqc> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Starter:</strong> Email support (48-hour response time)</li> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Business:</strong> Priority email support (24-hour response time)</li> <li data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Enterprise:</strong> Dedicated support with direct contact</li> </ul> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>9. Disclaimers and Limitations of Liability</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>9.1 Service "As Is"</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
The Services are provided "as is" without warranties of any kind, either express or implied. We do not warrant that the Services will meet your requirements or be error-free.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>9.2 AI Limitations</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
AI agents may produce unexpected or inaccurate results. You are responsible for reviewing and validating AI-generated outputs before use in critical applications.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>9.3 Limitation of Liability</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
To the maximum extent permitted by law, ZyatrIA Global shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly.
</p> <p class="text-muted-foreground mt-4" data-astro-cid-y5py4vqc>
Our total liability shall not exceed the amount you paid us in the 12 months preceding the claim.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>10. Indemnification</h2> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
You agree to indemnify and hold harmless ZyatrIA Global from any claims, damages, losses, liabilities, and expenses arising from:
</p> <ul class="list-disc pl-6 text-muted-foreground space-y-2 mt-4" data-astro-cid-y5py4vqc> <li data-astro-cid-y5py4vqc>Your use of the Services</li> <li data-astro-cid-y5py4vqc>Your violation of these Terms</li> <li data-astro-cid-y5py4vqc>Your violation of any rights of another party</li> <li data-astro-cid-y5py4vqc>Your data or content</li> </ul> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>11. Governing Law and Dispute Resolution</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>11.1 Governing Law</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
These Terms are governed by the laws of the Province of Quebec and the federal laws of Canada applicable therein.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>11.2 Dispute Resolution</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
Any disputes shall first be resolved through good-faith negotiation. If negotiation fails, disputes shall be resolved through arbitration in Quebec, Canada.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>11.3 Class Action Waiver</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
You agree to resolve disputes on an individual basis and waive the right to participate in class actions.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>12. Changes to Terms</h2> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
We may modify these Terms at any time. We will notify you of material changes by:
</p> <ul class="list-disc pl-6 text-muted-foreground space-y-2" data-astro-cid-y5py4vqc> <li data-astro-cid-y5py4vqc>Posting updated Terms on our website</li> <li data-astro-cid-y5py4vqc>Updating the "Last updated" date</li> <li data-astro-cid-y5py4vqc>Sending email notification (for significant changes)</li> </ul> <p class="text-muted-foreground mt-4" data-astro-cid-y5py4vqc>
Continued use of the Services after changes constitutes acceptance of the modified Terms.
</p> </div> <div class="bg-card rounded-lg p-8 mb-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>13. Miscellaneous</h2> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>13.1 Entire Agreement</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
These Terms constitute the entire agreement between you and ZyatrIA Global regarding the Services.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>13.2 Severability</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
If any provision of these Terms is found invalid, the remaining provisions remain in effect.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>13.3 No Waiver</h3> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
Our failure to enforce any right or provision does not constitute a waiver of that right.
</p> <h3 class="text-xl font-semibold mb-3 mt-6" data-astro-cid-y5py4vqc>13.4 Assignment</h3> <p class="text-muted-foreground" data-astro-cid-y5py4vqc>
You may not assign these Terms without our consent. We may assign these Terms without restriction.
</p> </div> <div class="bg-card rounded-lg p-8 border border-border" data-astro-cid-y5py4vqc> <h2 class="text-2xl font-semibold mb-4" data-astro-cid-y5py4vqc>14. Contact Information</h2> <p class="text-muted-foreground mb-4" data-astro-cid-y5py4vqc>
For questions about these Terms, contact us:
</p> <div class="space-y-2 text-muted-foreground" data-astro-cid-y5py4vqc> <p data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Email:</strong> <a href="mailto:legal@zyatria.global" class="text-primary hover:underline" data-astro-cid-y5py4vqc>legal@zyatria.global</a></p> <p data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>General inquiries:</strong> <a href="mailto:contact@zyatria.global" class="text-primary hover:underline" data-astro-cid-y5py4vqc>contact@zyatria.global</a></p> <p data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Phone:</strong> +1 (555) 123-4567</p> <p data-astro-cid-y5py4vqc><strong data-astro-cid-y5py4vqc>Address:</strong> ZyatrIA Global, Quebec, Canada</p> </div> </div> <div class="mt-8 p-6 bg-primary/10 border border-primary/20 rounded-lg" data-astro-cid-y5py4vqc> <p class="text-sm text-foreground" data-astro-cid-y5py4vqc> <strong data-astro-cid-y5py4vqc>Important:</strong> By clicking "I Agree" or using our Services, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service.
</p> </div> </div> </div> </main> ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "data-astro-cid-y5py4vqc": true, "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} ` })} `;
}, "/app/src/pages/terms.astro", void 0);

const $$file = "/app/src/pages/terms.astro";
const $$url = "/terms";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Terms,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
