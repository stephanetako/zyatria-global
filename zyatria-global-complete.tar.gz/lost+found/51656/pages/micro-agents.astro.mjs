globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BbsiYKQe.mjs';
import { $ as $$Main } from '../chunks/createLucideIcon_n5yAuAg7.mjs';
import { N as Navigation } from '../chunks/Navigation_DO2jpLlf.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_Bjg41kJa.mjs';

const $$MicroAgents = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Micro-Agents IA Sp\xE9cialis\xE9s | Immobilier, E-commerce, Support, Qualification | ZyatrIA",
    description: "D\xE9ployez des micro-agents IA sp\xE9cialis\xE9s en moins de 7 jours : Agent Immobilier, Agent E-commerce, Agent Support 24/7, Agent Qualification Leads, Agent Rendez-vous, Agent Sur-Mesure. Automatisation intelligente pour votre secteur.",
    ogImage: "/og-image-micro-agents.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "MicroAgentsPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/MicroAgentsPage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/micro-agents.astro", void 0);

const $$file = "/app/src/pages/micro-agents.astro";
const $$url = "/micro-agents";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$MicroAgents,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
