globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BbsiYKQe.mjs';
import { $ as $$Main } from '../chunks/createLucideIcon_n5yAuAg7.mjs';
import { N as Navigation } from '../chunks/Navigation_DO2jpLlf.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_Bjg41kJa.mjs';

const $$KnowledgeBase = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Base de Connaissances | Guides & Documentation Agents IA | ZyatrIA Global",
    description: "Acc\xE9dez \xE0 notre base de connaissances compl\xE8te sur les agents IA : guides de d\xE9marrage, documentation technique, meilleures pratiques, FAQ, tutoriels d'int\xE9gration. Ressources multilingues pour maximiser vos r\xE9sultats avec l'IA.",
    ogImage: "/og-image-knowledge.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "KnowledgeBasePage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/KnowledgeBasePage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/knowledge-base.astro", void 0);

const $$file = "/app/src/pages/knowledge-base.astro";
const $$url = "/knowledge-base";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$KnowledgeBase,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
