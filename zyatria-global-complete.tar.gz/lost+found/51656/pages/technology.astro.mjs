globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BbsiYKQe.mjs';
import { $ as $$Main } from '../chunks/createLucideIcon_n5yAuAg7.mjs';
import { N as Navigation } from '../chunks/Navigation_DO2jpLlf.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_Bjg41kJa.mjs';

const $$Technology = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Notre Technologie IA | Int\xE9grations HubSpot, Salesforce, OpenAI | ZyatrIA Global",
    description: "D\xE9couvrez notre stack technologique d'agents IA : int\xE9grations avec HubSpot, Salesforce, Notion, Slack, Stripe, OpenAI, Azure AI, Make, Zapier. Solutions compatibles avec vos outils existants. Architecture scalable et s\xE9curis\xE9e.",
    ogImage: "/og-image-technology.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "TechnologyPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/TechnologyPage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/technology.astro", void 0);

const $$file = "/app/src/pages/technology.astro";
const $$url = "/technology";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Technology,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
