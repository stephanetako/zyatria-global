globalThis.process ??= {}; globalThis.process.env ??= {};
export { r as renderers } from './chunks/_@astro-renderers_F_-x8amX.mjs';
