globalThis.process ??= {}; globalThis.process.env ??= {};
import { r as renderers } from './chunks/_@astro-renderers_F_-x8amX.mjs';
import { c as createExports, s as serverEntrypointModule } from './chunks/_@astrojs-ssr-adapter_DM5MnmjN.mjs';
import { manifest } from './manifest_DGNSjaLq.mjs';

const serverIslandMap = new Map();;

const _page0 = () => import('./pages/_image.astro.mjs');
const _page1 = () => import('./pages/about.astro.mjs');
const _page2 = () => import('./pages/demo.astro.mjs');
const _page3 = () => import('./pages/docs.astro.mjs');
const _page4 = () => import('./pages/knowledge-base.astro.mjs');
const _page5 = () => import('./pages/micro-agents.astro.mjs');
const _page6 = () => import('./pages/pricing.astro.mjs');
const _page7 = () => import('./pages/services.astro.mjs');
const _page8 = () => import('./pages/technology.astro.mjs');
const _page9 = () => import('./pages/index.astro.mjs');
const pageMap = new Map([
    ["node_modules/@astrojs/cloudflare/dist/entrypoints/image-endpoint.js", _page0],
    ["src/pages/about.astro", _page1],
    ["src/pages/demo.astro", _page2],
    ["src/pages/docs.astro", _page3],
    ["src/pages/knowledge-base.astro", _page4],
    ["src/pages/micro-agents.astro", _page5],
    ["src/pages/pricing.astro", _page6],
    ["src/pages/services.astro", _page7],
    ["src/pages/technology.astro", _page8],
    ["src/pages/index.astro", _page9]
]);

const _manifest = Object.assign(manifest, {
    pageMap,
    serverIslandMap,
    renderers,
    actions: () => import('./_noop-actions.mjs'),
    middleware: () => import('./_astro-internal_middleware.mjs')
});
const _args = undefined;
const _exports = createExports(_manifest);
const __astrojsSsrVirtualEntry = _exports.default;
const _start = 'start';
if (Object.prototype.hasOwnProperty.call(serverEntrypointModule, _start)) {
	serverEntrypointModule[_start](_manifest, _args);
}

export { __astrojsSsrVirtualEntry as default, pageMap };
