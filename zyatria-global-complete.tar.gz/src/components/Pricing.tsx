import React from 'react';
import { Check, ArrowRight, Sparkles, Zap, Rocket, DollarSign, Gift } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { STRIPE_PAYMENT_LINKS } from '../config/stripe-links';
import { cn } from '../lib/utils';
import { baseUrl } from '../lib/base-url';

type StripePlan = 'starter' | 'business' | 'enterprise';

interface PricingProps {
  lang?: string;
}

const translations = {
  en: {
    badge: "Transparent Pricing",
    title: "Choose Your Growth Plan",
    subtitle: "Simple pricing. No hidden fees. Cancel anytime.",
    monthly: 'per month',
    yearlyDiscount: 'Save 20% with annual billing',
    from: 'Starting at',
    trialBadge: "7-day free trial",
    plans: [
      {
        name: "Starter",
        subtitle: "Perfect to get started",
        price: 69,
        period: "CAD/month",
        description: "Ideal for small businesses and entrepreneurs",
        features: [
          "1 AI micro-agent specialized",
          "Automatic 24/7 responses",
          "Email support (48h)",
          "Basic analytics dashboard",
          "Up to 500 interactions/month"
        ],
        cta: "Start Free Trial",
        demoCta: "Or schedule a demo",
        popular: false,
        highlight: "✓ 7-day free trial included",
        icon: Sparkles,
        stripePlan: 'starter' as StripePlan
      },
      {
        name: "Business",
        subtitle: "Most popular",
        price: 169,
        period: "CAD/month",
        description: "For teams ready to scale",
        features: [
          "3 specialized AI micro-agents",
          "Advanced workflow automation",
          "CRM integrations (HubSpot, Salesforce)",
          "Priority support (24h)",
          "Up to 2,000 interactions/month",
          "Advanced analytics & reports",
          "Customizable templates"
        ],
        cta: "Start Free Trial",
        demoCta: "Or schedule a demo",
        popular: true,
        highlight: "✓ Best value for growing businesses",
        icon: Zap,
        stripePlan: 'business' as StripePlan,
        badge: "Recommended"
      },
      {
        name: "Enterprise",
        subtitle: "Tailored solutions",
        priceFrom: 500,
        period: "CAD/month",
        description: "Custom solutions for large organizations",
        features: [
          "Unlimited custom AI agents",
          "Complete automation & integrations",
          "Dedicated account manager",
          "24/7 priority support",
          "Unlimited interactions",
          "Custom training & onboarding",
          "SLA guarantee 99.9%",
          "Advanced security & compliance"
        ],
        cta: "Contact Sales",
        demoCta: "Let's discuss your needs",
        popular: false,
        highlight: "✓ ROI guarantee or money back",
        icon: Rocket,
        stripePlan: 'enterprise' as StripePlan,
        isCustom: true
      }
    ],
    note: "All prices in Canadian Dollars (CAD). Cancel anytime, no questions asked. Money-back guarantee within 30 days.",
    popular: "Most Popular",
    paymentSecure: "🔒 Secure payments powered by Stripe",
    moneyBack: "30-day money-back guarantee",
    enterprise: {
      title: "Need a custom solution?",
      description: "Our experts are here to design a plan perfectly adapted to your business needs and goals.",
      cta: "Talk to an Expert"
    },
    faq: {
      title: "Frequently Asked Questions",
      items: [
        {
          q: "Can I change plans later?",
          a: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately."
        },
        {
          q: "What happens after the trial?",
          a: "After your 7-day trial, you'll be automatically charged unless you cancel. No surprises."
        },
        {
          q: "Do you offer refunds?",
          a: "Yes! 30-day money-back guarantee if you're not satisfied. No questions asked."
        }
      ]
    }
  },
  fr: {
    badge: "Tarification Transparente",
    title: "Choisissez Votre Plan de Croissance",
    subtitle: "Tarification simple. Sans frais cachés. Annulez à tout moment.",
    monthly: 'par mois',
    yearlyDiscount: 'Économisez 20% avec facturation annuelle',
    from: 'À partir de',
    trialBadge: "Essai gratuit de 7 jours",
    plans: [
      {
        name: "Starter",
        subtitle: "Parfait pour débuter",
        price: 69,
        period: "CAD/mois",
        description: "Idéal pour petites entreprises et entrepreneurs",
        features: [
          "1 micro-agent IA spécialisé",
          "Réponses automatiques 24/7",
          "Support email (48h)",
          "Tableau de bord analytique basique",
          "Jusqu'à 500 interactions/mois"
        ],
        cta: "Démarrer l'Essai Gratuit",
        demoCta: "Ou planifier une démo",
        popular: false,
        highlight: "✓ Essai gratuit de 7 jours inclus",
        icon: Sparkles,
        badge: undefined
      },
      {
        name: "Business",
        subtitle: "Le plus populaire",
        price: 169,
        period: "CAD/mois",
        description: "Pour équipes prêtes à évoluer",
        features: [
          "3 micro-agents IA spécialisés",
          "Automatisation avancée des workflows",
          "Intégrations CRM (HubSpot, Salesforce)",
          "Support prioritaire (24h)",
          "Jusqu'à 2 000 interactions/mois",
          "Analytiques et rapports avancés",
          "Modèles personnalisables"
        ],
        cta: "Démarrer l'Essai Gratuit",
        demoCta: "Ou planifier une démo",
        popular: true,
        highlight: "✓ Meilleur rapport qualité-prix",
        icon: Zap,
        badge: "Recommandé"
      },
      {
        name: "Enterprise",
        subtitle: "Solutions sur-mesure",
        priceFrom: 500,
        period: "CAD/mois",
        description: "Solutions personnalisées pour grandes organisations",
        features: [
          "Agents IA personnalisés illimités",
          "Automatisation et intégrations complètes",
          "Gestionnaire de compte dédié",
          "Support prioritaire 24/7",
          "Interactions illimitées",
          "Formation et accompagnement personnalisés",
          "Garantie SLA 99.9%",
          "Sécurité et conformité avancées"
        ],
        cta: "Contacter les Ventes",
        demoCta: "Discutons de vos besoins",
        popular: false,
        highlight: "✓ Garantie ROI ou remboursement",
        icon: Rocket,
        isCustom: true,
        badge: undefined
      }
    ],
    note: "Tous les prix en dollars canadiens (CAD). Annulez à tout moment, sans questions. Garantie satisfait ou remboursé sous 30 jours.",
    popular: "Le Plus Populaire",
    paymentSecure: "🔒 Paiements sécurisés par Stripe",
    moneyBack: "Garantie satisfait ou remboursé 30 jours",
    enterprise: {
      title: "Besoin d'une solution personnalisée ?",
      description: "Nos experts sont là pour concevoir un plan parfaitement adapté aux besoins et objectifs de votre entreprise.",
      cta: "Parler à un Expert"
    },
    faq: {
      title: "Questions Fréquentes",
      items: [
        {
          q: "Puis-je changer de plan plus tard ?",
          a: "Oui, vous pouvez améliorer ou réduire votre plan à tout moment. Les changements prennent effet immédiatement."
        },
        {
          q: "Que se passe-t-il après l'essai ?",
          a: "Après votre essai de 7 jours, vous serez automatiquement facturé sauf si vous annulez. Aucune surprise."
        },
        {
          q: "Offrez-vous des remboursements ?",
          a: "Oui ! Garantie satisfait ou remboursé de 30 jours si vous n'êtes pas satisfait. Sans questions."
        }
      ]
    }
  },
  es: {
    badge: "Precios Transparentes",
    title: "Elija Su Plan de Crecimiento",
    subtitle: "Precios simples. Sin tarifas ocultas. Cancele en cualquier momento.",
    monthly: 'por mes',
    yearlyDiscount: 'Ahorre 20% con facturación anual',
    from: 'Desde',
    trialBadge: "Prueba gratuita de 7 días",
    plans: [
      {
        name: "Starter",
        subtitle: "Perfecto para empezar",
        price: 69,
        period: "CAD/mes",
        description: "Ideal para pequeñas empresas y emprendedores",
        features: [
          "1 micro-agente IA especializado",
          "Respuestas automáticas 24/7",
          "Soporte por email (48h)",
          "Panel analítico básico",
          "Hasta 500 interacciones/mes"
        ],
        cta: "Iniciar Prueba Gratuita",
        demoCta: "O programar una demo",
        popular: false,
        highlight: "✓ Prueba gratuita de 7 días incluida",
        icon: Sparkles,
        badge: undefined
      },
      {
        name: "Business",
        subtitle: "Más popular",
        price: 169,
        period: "CAD/mes",
        description: "Para equipos listos para escalar",
        features: [
          "3 micro-agentes IA especializados",
          "Automatización avanzada de workflows",
          "Integraciones CRM (HubSpot, Salesforce)",
          "Soporte prioritario (24h)",
          "Hasta 2,000 interacciones/mes",
          "Analíticas e informes avanzados",
          "Plantillas personalizables"
        ],
        cta: "Iniciar Prueba Gratuita",
        demoCta: "O programar una demo",
        popular: true,
        highlight: "✓ Mejor relación calidad-precio",
        icon: Zap,
        badge: "Recomendado"
      },
      {
        name: "Enterprise",
        subtitle: "Soluciones personalizadas",
        priceFrom: 500,
        period: "CAD/mes",
        description: "Soluciones personalizadas para grandes organizaciones",
        features: [
          "Agentes IA personalizados ilimitados",
          "Automatización e integraciones completas",
          "Gerente de cuenta dedicado",
          "Soporte prioritario 24/7",
          "Interacciones ilimitadas",
          "Capacitación y onboarding personalizados",
          "Garantía SLA 99.9%",
          "Seguridad y cumplimiento avanzados"
        ],
        cta: "Contactar Ventas",
        demoCta: "Hablemos de sus necesidades",
        popular: false,
        highlight: "✓ Garantía ROI o reembolso",
        icon: Rocket,
        isCustom: true,
        badge: undefined
      }
    ],
    note: "Todos los precios en dólares canadienses (CAD). Cancele en cualquier momento, sin preguntas. Garantía de devolución de dinero de 30 días.",
    popular: "Más Popular",
    paymentSecure: "🔒 Pagos seguros con Stripe",
    moneyBack: "Garantía de devolución de 30 días",
    enterprise: {
      title: "¿Necesita una solución personalizada?",
      description: "Nuestros expertos están aquí para diseñar un plan perfectamente adaptado a las necesidades y objetivos de su negocio.",
      cta: "Hablar con un Experto"
    },
    faq: {
      title: "Preguntas Frecuentes",
      items: [
        {
          q: "¿Puedo cambiar de plan más tarde?",
          a: "Sí, puede actualizar o reducir su plan en cualquier momento. Los cambios tienen efecto inmediatamente."
        },
        {
          q: "¿Qué pasa después de la prueba?",
          a: "Después de su prueba de 7 días, se le cobrará automáticamente a menos que cancele. Sin sorpresas."
        },
        {
          q: "¿Ofrecen reembolsos?",
          a: "¡Sí! Garantía de devolución de dinero de 30 días si no está satisfecho. Sin preguntas."
        }
      ]
    }
  },
  pt: {
    badge: "Preços Transparentes",
    title: "Escolha Seu Plano de Crescimento",
    subtitle: "Preços simples. Sem taxas ocultas. Cancele a qualquer momento.",
    monthly: 'por mês',
    yearlyDiscount: 'Economize 20% com faturamento anual',
    from: 'A partir de',
    trialBadge: "Teste gratuito de 7 dias",
    plans: [
      {
        name: "Starter",
        subtitle: "Perfeito para começar",
        price: 69,
        period: "CAD/mês",
        description: "Ideal para pequenas empresas e empreendedores",
        features: [
          "1 micro-agente IA especializado",
          "Respostas automáticas 24/7",
          "Suporte por email (48h)",
          "Painel analítico básico",
          "Até 500 interações/mês"
        ],
        cta: "Iniciar Teste Gratuito",
        demoCta: "Ou agendar uma demo",
        popular: false,
        highlight: "✓ Teste gratuito de 7 dias incluído",
        icon: Sparkles,
        badge: undefined
      },
      {
        name: "Business",
        subtitle: "Mais popular",
        price: 169,
        period: "CAD/mês",
        description: "Para equipes prontas para escalar",
        features: [
          "3 micro-agentes IA especializados",
          "Automatização avançada de workflows",
          "Integrações CRM (HubSpot, Salesforce)",
          "Suporte prioritário (24h)",
          "Até 2.000 interações/mês",
          "Análises e relatórios avançados",
          "Modelos personalizáveis"
        ],
        cta: "Iniciar Teste Gratuito",
        demoCta: "Ou agendar uma demo",
        popular: true,
        highlight: "✓ Melhor custo-benefício",
        icon: Zap,
        badge: "Recomendado"
      },
      {
        name: "Enterprise",
        subtitle: "Soluções personalizadas",
        priceFrom: 500,
        period: "CAD/mês",
        description: "Soluções personalizadas para grandes organizações",
        features: [
          "Agentes IA personalizados ilimitados",
          "Automação e integrações completas",
          "Gerente de conta dedicado",
          "Suporte prioritário 24/7",
          "Interações ilimitadas",
          "Treinamento e onboarding personalizados",
          "Garantia SLA 99.9%",
          "Segurança e conformidade avançadas"
        ],
        cta: "Contactar Vendas",
        demoCta: "Vamos discutir suas necessidades",
        popular: false,
        highlight: "✓ Garantia ROI ou reembolso",
        icon: Rocket,
        isCustom: true,
        badge: undefined
      }
    ],
    note: "Todos os preços em dólares canadenses (CAD). Cancele a qualquer momento, sem perguntas. Garantia de devolução do dinheiro em 30 dias.",
    popular: "Mais Popular",
    paymentSecure: "🔒 Pagamentos seguros com Stripe",
    moneyBack: "Garantia de devolução de 30 dias",
    enterprise: {
      title: "Precisa de uma solução personalizada?",
      description: "Nossos especialistas estão aqui para projetar um plano perfeitamente adaptado às necessidades e objetivos do seu negócio.",
      cta: "Falar com um Especialista"
    },
    faq: {
      title: "Perguntas Frequentes",
      items: [
        {
          q: "Posso mudar de plano depois?",
          a: "Sim, você pode atualizar ou reduzir seu plano a qualquer momento. As mudanças têm efeito imediatamente."
        },
        {
          q: "O que acontece após o teste?",
          a: "Após seu teste de 7 dias, você será cobrado automaticamente, a menos que cancele. Sem surpresas."
        },
        {
          q: "Vocês oferecem reembolsos?",
          a: "Sim! Garantia de devolução do dinheiro de 30 dias se você não estiver satisfeito. Sem perguntas."
        }
      ]
    }
  }
};

const Pricing: React.FC<PricingProps> = ({ lang = 'en' }) => {
  const t = translations[lang];

  const handleStripePurchase = (stripePlan: StripePlan) => {
    // Redirect to Stripe payment link
    window.location.href = STRIPE_PAYMENT_LINKS[stripePlan];
  };

  const scrollToContact = () => {
    window.location.href = `${baseUrl}/demo`;
  };

  return (
    <section id="pricing" className="py-24 bg-gradient-to-b from-white via-blue-50/30 to-white dark:from-zinc-950 dark:via-blue-950/10 dark:to-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 border border-blue-200 rounded-full mb-4">
            <DollarSign className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-600">{t.badge}</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold font-heading mb-4">
            {t.title}
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-3">
            {t.subtitle}
          </p>
          <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <Gift className="w-4 h-4 text-blue-500" />
              {t.trialBadge}
            </span>
            <span>•</span>
            <span>{t.moneyBack}</span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {t.plans.map((plan: any, index: number) => {
            const Icon = plan.icon;

            return (
              <Card
                key={index}
                className={cn(
                  'relative overflow-hidden transition-all duration-300 hover:shadow-2xl group',
                  plan.popular
                    ? 'border-blue-500 border-2 shadow-xl shadow-blue-500/20 scale-105 md:scale-110'
                    : 'border-border hover:border-blue-400/50'
                )}
              >
                {/* Popular Badge */}
                {plan.badge && (
                  <div className="absolute top-0 right-0 bg-gradient-to-r from-blue-500 to-violet-500 text-white px-4 py-1.5 text-xs font-bold rounded-bl-lg shadow-lg">
                    {plan.badge}
                  </div>
                )}

                <div className="p-8">
                  {/* Icon */}
                  <div className={cn(
                    "w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110",
                    plan.popular 
                      ? 'bg-gradient-to-br from-blue-500 to-violet-500 text-white shadow-lg shadow-blue-500/30' 
                      : 'bg-blue-50 text-blue-600'
                  )}>
                    <Icon className="w-7 h-7" />
                  </div>

                  {/* Plan Name & Subtitle */}
                  <div className="mb-6">
                    <h3 className="text-2xl font-bold font-heading mb-1">{plan.name}</h3>
                    <p className="text-sm text-muted-foreground">{plan.subtitle}</p>
                  </div>

                  {/* Price */}
                  <div className="mb-6 pb-6 border-b border-border">
                    {plan.isCustom ? (
                      <div>
                        <div className="text-sm text-muted-foreground mb-2">{t.from}</div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-4xl font-bold font-heading">
                            ${plan.priceFrom}
                          </span>
                          <span className="text-muted-foreground">
                            {t.monthly}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-baseline gap-2 mb-2">
                          <span className="text-5xl font-bold font-heading text-foreground">
                            ${plan.price}
                          </span>
                          <span className="text-muted-foreground text-lg">
                            {t.monthly}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {plan.period}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground mb-6 font-medium">
                    {plan.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-3.5 mb-8">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <div className="mt-0.5">
                          <Check className="w-5 h-5 text-blue-500" />
                        </div>
                        <span className="text-sm leading-relaxed">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Highlight */}
                  <div className="mb-6 px-3 py-2 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                    <p className="text-xs text-blue-600 dark:text-blue-400 font-medium text-center">
                      {plan.highlight}
                    </p>
                  </div>

                  {/* CTA Buttons */}
                  <div className="space-y-3">
                    <Button
                      onClick={() => {
                        if (plan.isCustom) {
                          scrollToContact();
                        } else {
                          handleStripePurchase(plan.stripePlan);
                        }
                      }}
                      className={cn(
                        'w-full font-button text-base h-12',
                        plan.popular
                          ? 'bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600 text-white shadow-lg shadow-blue-500/30'
                          : 'bg-blue-500 hover:bg-blue-600 text-white'
                      )}
                    >
                      {plan.cta}
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>

                    {/* Demo Link */}
                    <button
                      onClick={scrollToContact}
                      className="w-full text-sm text-blue-400 hover:text-blue-500 transition-colors font-medium"
                    >
                      {plan.demoCta}
                    </button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Trust Badges */}
        <div className="text-center mb-16">
          <p className="text-sm text-muted-foreground mb-4">
            {t.paymentSecure}
          </p>
          <p className="text-xs text-muted-foreground max-w-2xl mx-auto">
            {t.note}
          </p>
        </div>

        {/* Enterprise CTA */}
        <div className="max-w-3xl mx-auto">
          <Card className="bg-gradient-to-br from-blue-50 via-violet-50 to-cyan-50 dark:from-blue-950/20 dark:via-violet-950/20 dark:to-cyan-950/20 border-blue-200 dark:border-blue-800/50 p-8 md:p-10 text-center overflow-hidden relative">
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-blue-400/10 to-violet-400/10 rounded-full blur-3xl -z-0" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-tr from-cyan-400/10 to-blue-400/10 rounded-full blur-3xl -z-0" />
            
            <div className="relative z-10">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-violet-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-500/30">
                <Rocket className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-3xl font-bold font-heading mb-4">
                {t.enterprise.title}
              </h3>
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto text-lg">
                {t.enterprise.description}
              </p>
              <Button 
                asChild 
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600 text-white shadow-lg shadow-blue-500/30 font-button text-base h-12 px-8"
              >
                <a href={`${baseUrl}/demo`}>
                  {t.enterprise.cta}
                  <ArrowRight className="ml-2 w-5 h-5" />
                </a>
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Pricing;

