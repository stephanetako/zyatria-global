﻿/// <reference types="astro/client" />
