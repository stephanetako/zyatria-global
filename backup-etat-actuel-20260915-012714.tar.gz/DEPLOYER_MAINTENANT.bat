@echo off
echo.
echo ========================================
echo   DEPLOIEMENT ZYATRIA GLOBAL
echo ========================================
echo.
echo Ce script va deployer votre site en ligne
echo.
pause

powershell -ExecutionPolicy Bypass -File "%~dp0deployer-maintenant.ps1"

pause
