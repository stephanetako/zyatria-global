@echo off
chcp 65001 >nul
cls

echo ═══════════════════════════════════════════════════════════
echo 🚀 ZYATRIA GLOBAL - DÉPLOIEMENT HAUTE TECHNOLOGIE
echo ═══════════════════════════════════════════════════════════
echo.
echo 📋 Configuration restaurée du 19 juillet 2026
echo ✅ Mode SERVER activé (SSR)
echo ✅ Toutes les améliorations conservées
echo.
echo ⚠️  Ce script va:
echo    1. Authentifier avec Cloudflare
echo    2. Déployer votre site
echo.
echo 🌐 Site final: https://zyatria-global.pages.dev
echo.
pause

powershell.exe -ExecutionPolicy Bypass -File "%~dp0DEPLOYER_AUTHENTIFIE.ps1"

pause
