@echo off
chcp 65001 >nul
color 0B
cls

echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║                                                                ║
echo ║          🚀 DEPLOIEMENT ZYATRIA GLOBAL EN LIGNE 🚀            ║
echo ║                                                                ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.
echo.
echo   Ce script va déployer votre site automatiquement
echo.
echo   ✅ Installation des dépendances
echo   ✅ Build du projet
echo   ✅ Déploiement en ligne
echo.
echo   Temps estimé : 5 minutes
echo.
echo ════════════════════════════════════════════════════════════════
echo.
pause

powershell -ExecutionPolicy Bypass -File "%~dp0deployer-maintenant.ps1"

echo.
echo ════════════════════════════════════════════════════════════════
echo.
echo   Appuyez sur une touche pour fermer cette fenêtre...
echo.
pause >nul
