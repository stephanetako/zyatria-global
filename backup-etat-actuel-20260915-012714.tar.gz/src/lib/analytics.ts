// Analytics configuration for ZyatrIA Global
// Supports Google Analytics, Plausible, and custom events

export const ANALYTICS_CONFIG = {
  // Google Analytics 4
  googleAnalytics: {
    enabled: false, // Set to true when you have a GA4 ID
    measurementId: '', // Replace with your GA4 Measurement ID (G-XXXXXXXXXX)
  },
  
  // Plausible Analytics (privacy-friendly alternative)
  plausible: {
    enabled: false, // Set to true to enable Plausible
    domain: 'zyatria.global', // Your domain
    apiHost: 'https://plausible.io', // Or your self-hosted instance
  },
  
  // Custom events tracking
  events: {
    enabled: true,
    debug: false, // Set to true to log events to console
  }
};

// Event types for type safety
export type AnalyticsEvent = 
  | 'page_view'
  | 'cta_click'
  | 'form_submit'
  | 'demo_request'
  | 'pricing_view'
  | 'micro_agent_select'
  | 'stripe_checkout_start'
  | 'newsletter_signup'
  | 'contact_form_submit';

// Track custom events
export function trackEvent(
  eventName: AnalyticsEvent,
  eventData?: Record<string, any>
) {
  if (!ANALYTICS_CONFIG.events.enabled) return;

  // Debug logging
  if (ANALYTICS_CONFIG.events.debug) {
    console.log('[Analytics]', eventName, eventData);
  }

  // Google Analytics 4
  if (ANALYTICS_CONFIG.googleAnalytics.enabled && typeof window !== 'undefined') {
    const gtag = (window as any).gtag;
    if (gtag) {
      gtag('event', eventName, eventData);
    }
  }

  // Plausible Analytics
  if (ANALYTICS_CONFIG.plausible.enabled && typeof window !== 'undefined') {
    const plausible = (window as any).plausible;
    if (plausible) {
      plausible(eventName, { props: eventData });
    }
  }

  // Custom analytics endpoint (optional)
  // You can send events to your own API for custom tracking
  if (typeof window !== 'undefined') {
    // Example: fetch('/api/analytics', { method: 'POST', body: JSON.stringify({ event: eventName, data: eventData }) });
  }
}

// Track page views
export function trackPageView(url?: string) {
  const pageUrl = url || (typeof window !== 'undefined' ? window.location.pathname : '');
  trackEvent('page_view', { page_path: pageUrl });
}

// Track CTA clicks
export function trackCTAClick(ctaName: string, ctaLocation: string) {
  trackEvent('cta_click', {
    cta_name: ctaName,
    cta_location: ctaLocation,
  });
}

// Track form submissions
export function trackFormSubmit(formName: string, formData?: Record<string, any>) {
  trackEvent('form_submit', {
    form_name: formName,
    ...formData,
  });
}

// Track Stripe checkout starts
export function trackStripeCheckout(plan: string, price: number, currency: string = 'CAD') {
  trackEvent('stripe_checkout_start', {
    plan_name: plan,
    price,
    currency,
  });
}

// Track micro-agent selections
export function trackMicroAgentSelect(agentName: string, agentType: string) {
  trackEvent('micro_agent_select', {
    agent_name: agentName,
    agent_type: agentType,
  });
}

// Initialize analytics on page load
export function initAnalytics() {
  if (typeof window === 'undefined') return;

  // Track initial page view
  trackPageView();

  // Google Analytics initialization
  if (ANALYTICS_CONFIG.googleAnalytics.enabled && ANALYTICS_CONFIG.googleAnalytics.measurementId) {
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${ANALYTICS_CONFIG.googleAnalytics.measurementId}`;
    document.head.appendChild(script);

    (window as any).dataLayer = (window as any).dataLayer || [];
    function gtag(...args: any[]) {
      (window as any).dataLayer.push(args);
    }
    (window as any).gtag = gtag;
    gtag('js', new Date());
    gtag('config', ANALYTICS_CONFIG.googleAnalytics.measurementId);
  }

  // Plausible Analytics initialization
  if (ANALYTICS_CONFIG.plausible.enabled) {
    const script = document.createElement('script');
    script.defer = true;
    script.setAttribute('data-domain', ANALYTICS_CONFIG.plausible.domain);
    script.src = `${ANALYTICS_CONFIG.plausible.apiHost}/js/script.js`;
    document.head.appendChild(script);
  }
}
