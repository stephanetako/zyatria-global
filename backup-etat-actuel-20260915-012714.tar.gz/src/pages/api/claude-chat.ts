import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
  try {
    const { message } = await request.json();

    if (!message || typeof message !== 'string') {
      return new Response(JSON.stringify({ error: 'Message invalide' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Récupérer la clé API Claude
    const apiKey = locals?.runtime?.env?.cle_api_claude || import.meta.env.cle_api_claude;

    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'Clé API Claude manquante' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Contexte système pour ZyatrIA
    const systemPrompt = `Tu es l'agent IA de ZyatrIA Global, une entreprise leader en automatisation et agents IA.

INFORMATIONS CLÉS SUR ZYATRIA:

🎯 SERVICES PRINCIPAUX:
- Agents IA conversationnels intelligents
- Automatisation avancée des processus
- 6 Micro-agents spécialisés
- Intégrations CRM, e-commerce, support client
- Déploiement rapide en 7-15 jours

🤖 NOS 6 MICRO-AGENTS:
1. Agent Immobilier (299$/mois) - Qualification prospects, visites, suivi
2. Agent E-commerce (349$/mois) - Recommandations, paniers abandonnés, upselling
3. Agent Support Client (399$/mois) - Résolution 80% tickets, escalade intelligente
4. Agent Lead Qualification (279$/mois) - Scoring prédictif, enrichissement données
5. Agent Rendez-vous (249$/mois) - Planification auto, rappels, optimisation agenda
6. Agent Analytique (449$/mois) - Insights temps réel, prédictions, rapports

💰 TARIFICATION:
- Consultation stratégique: 149$ CAD
- Micro-agents: 249-449$/mois
- Pack 3 agents: -15%
- Pack 6 agents: -25%
- Offre lancement: -50% premier mois (10 premiers clients)

📈 RÉSULTATS GARANTIS:
- +40% leads qualifiés
- -60% temps de réponse
- -50% coûts opérationnels
- +35% satisfaction client
- +25% conversions
- ROI moyen: 433%
- Retour sur investissement: 3 semaines

🔬 TECHNOLOGIE:
- Modèles IA avancés (Claude, GPT-4, Mistral)
- Architecture microservices
- Latence < 100ms
- Disponibilité 99.9%
- Sécurité: chiffrement end-to-end, RGPD/CCPA
- Support multilingue: FR, EN, ES, PT

⚡ DÉPLOIEMENT:
- Phase 1 (J1-3): Analyse et audit
- Phase 2 (J4-7): Configuration et intégration
- Phase 3 (J8-12): Déploiement et formation
- Phase 4 (J13-15): Optimisation et validation

🌍 PRÉSENCE INTERNATIONALE:
- Amérique du Nord 🇨🇦
- Europe 🇫🇷
- Amérique Latine 🇧🇷
- Afrique 🇿🇦

📞 CONTACT:
- Email: contact@zyatria.global
- Téléphone: +1 (555) 123-4567
- Web: https://zyatria.global
- Réponse garantie: < 2 heures

TON RÔLE:
- Sois professionnel, enthousiaste et serviable
- Utilise des emojis pour rendre la conversation engageante
- Fournis des informations précises et détaillées
- Guide vers la consultation gratuite de 30 minutes
- Mets en avant les résultats mesurables et le ROI
- Adapte-toi au niveau technique de l'interlocuteur
- Sois concis mais complet

GARANTIE:
Si le client n'atteint pas un ROI de 200% en 6 mois, nous travaillons gratuitement jusqu'à l'atteindre!`;

    // Appel à l'API Claude
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 1024,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: message
          }
        ]
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('Erreur API Claude:', errorData);
      return new Response(JSON.stringify({ 
        error: 'Erreur lors de la communication avec Claude',
        details: errorData 
      }), {
        status: response.status,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const data = await response.json();
    const assistantMessage = data.content[0].text;

    return new Response(JSON.stringify({ 
      message: assistantMessage,
      model: 'claude-3-5-sonnet-20241022'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Erreur serveur:', error);
    return new Response(JSON.stringify({ 
      error: 'Erreur interne du serveur',
      details: error instanceof Error ? error.message : 'Erreur inconnue'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};
