import React from 'react';
import { LanguageProvider } from '../lib/language-context';
import NavigationDesignSystem from './NavigationDesignSystem';
import HeroDesignSystem from './HeroDesignSystem';
import TrustStatsSimple from './TrustStatsSimple';
import Services from './Services';
import MicroAgents from './MicroAgents';
import RoadmapDesignSystem from './RoadmapDesignSystem';
import PricingDesignSystem from './PricingDesignSystem';
import TestimonialsDesignSystem from './TestimonialsDesignSystem';
import FAQDesignSystem from './FAQDesignSystem';
import CTAFinal from './CTAFinal';
import FooterDesignSystem from './FooterDesignSystem';
import IntelligentChatBot from './IntelligentChatBot';
import CookieConsent from './CookieConsent';
import EnhancedClaudeChatBot from './EnhancedClaudeChatBot';

const AppWrapper: React.FC = () => {
  return (
    <LanguageProvider>
      <div className="min-h-screen bg-background text-foreground">
        <NavigationDesignSystem />
        <main>
          <section id="hero">
            <HeroDesignSystem />
          </section>
          <TrustStatsSimple />
          <section id="services">
            <Services />
          </section>
          <section id="micro-agents">
            <MicroAgents />
          </section>
          <section id="technology">
            <RoadmapDesignSystem />
          </section>
          <section id="pricing">
            <PricingDesignSystem />
          </section>
          <section id="docs">
            <TestimonialsDesignSystem />
          </section>
          <section id="faq">
            <FAQDesignSystem />
          </section>
          <section id="contact">
            <CTAFinal />
          </section>
        </main>
        <FooterDesignSystem />
        {/* Chatbot IA Enhanced avec toutes les fonctionnalités */}
        <EnhancedClaudeChatBot />

        {/* Cookie Consent */}
        <CookieConsent />
      </div>
    </LanguageProvider>
  );
};

export default AppWrapper;















