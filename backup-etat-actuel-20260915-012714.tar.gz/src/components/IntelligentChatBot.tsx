import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, Loader2, X, Minimize2, ShoppingCart, CreditCard } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { STRIPE_PAYMENT_LINKS } from '../config/stripe-links';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
  productLinks?: { label: string; url: string }[];
}

// Base de connaissances des produits ZyatrIA
const PRODUCT_KNOWLEDGE = {
  plans: {
    starter: {
      name: 'Plan Starter',
      price: '68 $CA/mois',
      features: ['1 Bot IA spécialisé', 'Déploiement en 7-15 jours', 'Support email (48h)', "Jusqu'à 1 000 interactions/mois"],
      stripeLink: STRIPE_PAYMENT_LINKS.starter.monthly,
      ideal: 'petites entreprises qui démarrent avec l\'IA'
    },
    professional: {
      name: 'Plan Professional',
      price: '208 $CA/mois',
      features: ['3 Bots IA spécialisés', 'Automatisation avancée', 'Intégrations CRM', 'Support prioritaire (24h)', "Jusqu'à 5 000 interactions/mois"],
      stripeLink: STRIPE_PAYMENT_LINKS.professional.monthly,
      ideal: 'entreprises en croissance qui veulent automatiser plusieurs processus'
    },
    enterprise: {
      name: 'Plan Enterprise',
      price: '698 $CA/mois',
      features: ['7 Bots IA - Suite complète', 'Déploiement personnalisé', 'Automatisation complète', 'Gestionnaire dédié', 'Support 24/7'],
      stripeLink: STRIPE_PAYMENT_LINKS.enterprise.monthly,
      ideal: 'grandes entreprises avec des besoins complexes'
    }
  },
  microAgents: {
    leadQualification: {
      name: 'Qualification de Leads',
      price: '68 $CA/mois',
      description: 'Qualifie automatiquement vos prospects 24/7',
      benefits: ['Économie de temps', 'Meilleure conversion', 'Disponibilité 24/7'],
      stripeLink: STRIPE_PAYMENT_LINKS.starter.monthly
    },
    customerSupport: {
      name: 'Support Client 24/7',
      price: '68 $CA/mois',
      description: 'Répond aux questions courantes instantanément',
      benefits: ['Satisfaction client accrue', 'Réduction des coûts', 'Disponibilité permanente'],
      stripeLink: STRIPE_PAYMENT_LINKS.starter.monthly
    },
    appointmentManagement: {
      name: 'Gestion de Rendez-vous',
      price: '68 $CA/mois',
      description: 'Automatise la prise de rendez-vous',
      benefits: ['Moins de no-shows', 'Calendrier optimisé', 'Rappels automatiques'],
      stripeLink: STRIPE_PAYMENT_LINKS.starter.monthly
    },
    prospectTracking: {
      name: 'Suivi de Prospects',
      price: '208 $CA/mois',
      description: 'Suit et relance vos prospects automatiquement',
      benefits: ['Meilleur taux de conversion', 'Suivi personnalisé', 'Relances automatiques'],
      stripeLink: STRIPE_PAYMENT_LINKS.professional.monthly
    },
    realEstate: {
      name: 'Agent Immobilier IA',
      price: '208 $CA/mois',
      description: 'Spécialisé pour l\'immobilier',
      benefits: ['Qualification de visiteurs', 'Visites virtuelles', 'Suivi automatique'],
      stripeLink: STRIPE_PAYMENT_LINKS.professional.monthly
    },
    ecommerce: {
      name: 'Assistant E-commerce',
      price: '208 $CA/mois',
      description: 'Recommandations produits et support achat',
      benefits: ['Augmentation des ventes', 'Panier moyen plus élevé', 'Réduction des abandons'],
      stripeLink: STRIPE_PAYMENT_LINKS.professional.monthly
    }
  },
  services: {
    audit: {
      name: 'Audit IA Complet',
      price: '497 $CA',
      description: 'Analyse approfondie de vos besoins en IA',
      stripeLink: STRIPE_PAYMENT_LINKS.services.audit
    },
    consultation: {
      name: 'Consultation Stratégique',
      price: '147 $CA',
      description: '60 minutes avec un expert IA',
      stripeLink: STRIPE_PAYMENT_LINKS.services.consultation
    },
    training: {
      name: 'Formation IA pour Équipes',
      price: '997 $CA',
      description: 'Formation complète pour transformer vos équipes avec l\'IA.',
      stripeLink: STRIPE_PAYMENT_LINKS.services.formation
    }
  }
};

// Fonction pour analyser l'intention de l'utilisateur
function analyzeIntent(message: string): {
  intent: string;
  confidence: number;
  keywords: string[];
} {
  const lowerMessage = message.toLowerCase();
  
  // Intentions de prix
  if (lowerMessage.match(/prix|tarif|coût|combien|budget/)) {
    return { intent: 'pricing', confidence: 0.9, keywords: ['prix', 'tarif'] };
  }
  
  // Intentions de produit spécifique
  if (lowerMessage.match(/starter|démarrer|commencer|petit/)) {
    return { intent: 'starter_plan', confidence: 0.85, keywords: ['starter'] };
  }
  
  if (lowerMessage.match(/professional|professionnel|moyen|croissance/)) {
    return { intent: 'professional_plan', confidence: 0.85, keywords: ['professional'] };
  }
  
  if (lowerMessage.match(/enterprise|entreprise|grand|complet/)) {
    return { intent: 'enterprise_plan', confidence: 0.85, keywords: ['enterprise'] };
  }
  
  // Micro-agents
  if (lowerMessage.match(/lead|prospect|qualification/)) {
    return { intent: 'lead_qualification', confidence: 0.8, keywords: ['leads'] };
  }
  
  if (lowerMessage.match(/support|client|service/)) {
    return { intent: 'customer_support', confidence: 0.8, keywords: ['support'] };
  }
  
  if (lowerMessage.match(/rendez-vous|rdv|appointment|calendrier/)) {
    return { intent: 'appointment', confidence: 0.8, keywords: ['rendez-vous'] };
  }
  
  if (lowerMessage.match(/immobilier|real estate|propriété/)) {
    return { intent: 'real_estate', confidence: 0.8, keywords: ['immobilier'] };
  }
  
  if (lowerMessage.match(/e-commerce|boutique|vente en ligne|shop/)) {
    return { intent: 'ecommerce', confidence: 0.8, keywords: ['e-commerce'] };
  }
  
  // Services
  if (lowerMessage.match(/audit|analyse|évaluation/)) {
    return { intent: 'audit', confidence: 0.8, keywords: ['audit'] };
  }
  
  if (lowerMessage.match(/consultation|conseil|expert/)) {
    return { intent: 'consultation', confidence: 0.8, keywords: ['consultation'] };
  }
  
  if (lowerMessage.match(/formation|training|apprendre/)) {
    return { intent: 'training', confidence: 0.8, keywords: ['formation'] };
  }
  
  // Intentions générales
  if (lowerMessage.match(/bonjour|salut|hello|hi/)) {
    return { intent: 'greeting', confidence: 0.95, keywords: ['salutation'] };
  }
  
  if (lowerMessage.match(/aide|help|comment|quoi/)) {
    return { intent: 'help', confidence: 0.7, keywords: ['aide'] };
  }
  
  if (lowerMessage.match(/acheter|buy|commander|order/)) {
    return { intent: 'purchase', confidence: 0.85, keywords: ['achat'] };
  }
  
  return { intent: 'general', confidence: 0.5, keywords: [] };
}

// Fonction pour générer une réponse intelligente
function generateResponse(userMessage: string): {
  content: string;
  suggestions?: string[];
  productLinks?: { label: string; url: string }[];
} {
  const { intent } = analyzeIntent(userMessage);
  
  switch (intent) {
    case 'greeting':
      return {
        content: "👋 Bonjour ! Je suis l'assistant IA de ZyatrIA Global.\n\nJe peux vous aider à :\n• Découvrir nos plans et tarifs\n• Choisir le bon micro-agent pour votre entreprise\n• Répondre à vos questions sur nos services\n• Vous guider vers un achat\n\nQue puis-je faire pour vous aujourd'hui ?",
        suggestions: [
          'Voir les plans et tarifs',
          'Découvrir les micro-agents',
          'Parler à un expert',
          'Commencer un essai gratuit'
        ]
      };
    
    case 'pricing':
      return {
        content: "💰 **Nos Plans et Tarifs**\n\n**Plan Starter** - 68 $CA/mois\n• 1 Bot IA spécialisé\n• Déploiement en 7-15 jours\n• Jusqu'à 1 000 interactions/mois\n\n**Plan Professional** ⭐ (Recommandé)\n208 $CA/mois\n• 3 Bots IA spécialisés\n• Automatisation avancée\n• Jusqu'à 5 000 interactions/mois\n\n**Plan Enterprise** - 698 $CA/mois\n• 7 Bots IA - Suite complète\n• Gestionnaire dédié\n• Support 24/7\n\nQuel plan vous intéresse ?",
        suggestions: [
          'En savoir plus sur Starter',
          'En savoir plus sur Professional',
          'En savoir plus sur Enterprise',
          'Comparer les plans'
        ]
      };
    
    case 'starter_plan':
      return {
        content: `🚀 **Plan Starter - 68 $CA/mois**\n\nParfait pour démarrer avec l'IA !\n\n✅ Inclus :\n${PRODUCT_KNOWLEDGE.plans.starter.features.map(f => `• ${f}`).join('\n')}\n\n💡 Idéal pour : ${PRODUCT_KNOWLEDGE.plans.starter.ideal}\n\nVoulez-vous commencer avec ce plan ?`,
        suggestions: [
          'Acheter le plan Starter',
          'Comparer avec Professional',
          'Essai gratuit 7 jours'
        ],
        productLinks: [
          { label: '🛒 Acheter Starter (68 $CA/mois)', url: PRODUCT_KNOWLEDGE.plans.starter.stripeLink }
        ]
      };
    
    case 'professional_plan':
      return {
        content: `⭐ **Plan Professional - 208 $CA/mois**\n\nNotre plan le plus populaire !\n\n✅ Inclus :\n${PRODUCT_KNOWLEDGE.plans.professional.features.map(f => `• ${f}`).join('\n')}\n\n💡 Idéal pour : ${PRODUCT_KNOWLEDGE.plans.professional.ideal}\n\nC'est le meilleur rapport qualité-prix pour les entreprises en croissance.`,
        suggestions: [
          'Acheter le plan Professional',
          'Voir les micro-agents inclus',
          'Parler à un expert'
        ],
        productLinks: [
          { label: '🛒 Acheter Professional (208 $CA/mois)', url: PRODUCT_KNOWLEDGE.plans.professional.stripeLink }
        ]
      };
    
    case 'enterprise_plan':
      return {
        content: `🏆 **Plan Enterprise - 698 $CA/mois**\n\nLa solution complète pour les grandes entreprises.\n\n✅ Inclus :\n${PRODUCT_KNOWLEDGE.plans.enterprise.features.map(f => `• ${f}`).join('\n')}\n\n💡 Idéal pour : ${PRODUCT_KNOWLEDGE.plans.enterprise.ideal}\n\nVoulez-vous discuter de vos besoins spécifiques avec notre équipe ?`,
        suggestions: [
          'Acheter le plan Enterprise',
          'Demander une démo personnalisée',
          'Parler aux ventes'
        ],
        productLinks: [
          { label: '🛒 Acheter Enterprise (698 $CA/mois)', url: PRODUCT_KNOWLEDGE.plans.enterprise.stripeLink }
        ]
      };
    
    case 'lead_qualification':
      return {
        content: `🎯 **Micro-Agent : Qualification de Leads**\n\nPrix : ${PRODUCT_KNOWLEDGE.microAgents.leadQualification.price}\n\n${PRODUCT_KNOWLEDGE.microAgents.leadQualification.description}\n\n✅ Avantages :\n${PRODUCT_KNOWLEDGE.microAgents.leadQualification.benefits.map(b => `• ${b}`).join('\n')}\n\nParfait pour automatiser votre prospection !`,
        suggestions: [
          'Acheter ce micro-agent',
          'Voir d\'autres micro-agents',
          'Combiner avec un plan'
        ],
        productLinks: [
          { label: '🛒 Acheter Qualification Leads (68 $CA/mois)', url: PRODUCT_KNOWLEDGE.microAgents.leadQualification.stripeLink }
        ]
      };
    
    case 'customer_support':
      return {
        content: `💬 **Micro-Agent : Support Client 24/7**\n\nPrix : ${PRODUCT_KNOWLEDGE.microAgents.customerSupport.price}\n\n${PRODUCT_KNOWLEDGE.microAgents.customerSupport.description}\n\n✅ Avantages :\n${PRODUCT_KNOWLEDGE.microAgents.customerSupport.benefits.map(b => `• ${b}`).join('\n')}\n\nRéduisez vos coûts de support tout en améliorant la satisfaction client !`,
        suggestions: [
          'Acheter ce micro-agent',
          'Voir une démo',
          'Comparer les options'
        ],
        productLinks: [
          { label: '🛒 Acheter Support 24/7 (68 $CA/mois)', url: PRODUCT_KNOWLEDGE.microAgents.customerSupport.stripeLink }
        ]
      };
    
    case 'appointment':
      return {
        content: `📅 **Micro-Agent : Gestion de Rendez-vous**\n\nPrix : ${PRODUCT_KNOWLEDGE.microAgents.appointmentManagement.price}\n\n${PRODUCT_KNOWLEDGE.microAgents.appointmentManagement.description}\n\n✅ Avantages :\n${PRODUCT_KNOWLEDGE.microAgents.appointmentManagement.benefits.map(b => `• ${b}`).join('\n')}\n\nAutomatisez votre calendrier et ne manquez plus jamais un rendez-vous !`,
        suggestions: [
          'Acheter ce micro-agent',
          'Intégrations disponibles',
          'Voir les fonctionnalités'
        ],
        productLinks: [
          { label: '🛒 Acheter Gestion RDV (68 $CA/mois)', url: PRODUCT_KNOWLEDGE.microAgents.appointmentManagement.stripeLink }
        ]
      };
    
    case 'real_estate':
      return {
        content: `🏠 **Micro-Agent : Immobilier**\n\nPrix : ${PRODUCT_KNOWLEDGE.microAgents.realEstate.price}\n\n${PRODUCT_KNOWLEDGE.microAgents.realEstate.description}\n\n✅ Avantages :\n${PRODUCT_KNOWLEDGE.microAgents.realEstate.benefits.map(b => `• ${b}`).join('\n')}\n\nParfait pour les agents immobiliers et promoteurs !`,
        suggestions: [
          'Acheter ce micro-agent',
          'Voir une démo immobilier',
          'Cas d\'usage immobilier'
        ],
        productLinks: [
          { label: '🛒 Acheter Agent Immobilier (208 $CA/mois)', url: PRODUCT_KNOWLEDGE.microAgents.realEstate.stripeLink }
        ]
      };
    
    case 'ecommerce':
      return {
        content: `🛍️ **Micro-Agent : E-commerce**\n\nPrix : ${PRODUCT_KNOWLEDGE.microAgents.ecommerce.price}\n\n${PRODUCT_KNOWLEDGE.microAgents.ecommerce.description}\n\n✅ Avantages :\n${PRODUCT_KNOWLEDGE.microAgents.ecommerce.benefits.map(b => `• ${b}`).join('\n')}\n\nBoostez vos ventes en ligne avec l'IA !`,
        suggestions: [
          'Acheter ce micro-agent',
          'Intégrations e-commerce',
          'Voir des exemples'
        ],
        productLinks: [
          { label: '🛒 Acheter Assistant E-commerce (208 $CA/mois)', url: PRODUCT_KNOWLEDGE.microAgents.ecommerce.stripeLink }
        ]
      };
    
    case 'audit':
      return {
        content: `🔍 **Service : Audit IA Complet**\n\nPrix : ${PRODUCT_KNOWLEDGE.services.audit.price} (paiement unique)\n\n${PRODUCT_KNOWLEDGE.services.audit.description}\n\nCe que vous obtenez :\n• Analyse de vos processus actuels\n• Identification des opportunités d'automatisation\n• Recommandations personnalisées\n• Plan d'action détaillé\n• Rapport complet (30+ pages)\n\nParfait pour commencer votre transformation IA !`,
        suggestions: [
          'Commander un audit',
          'Voir un exemple de rapport',
          'Parler à un expert'
        ],
        productLinks: [
          { label: '🛒 Commander Audit IA (497 $CA)', url: PRODUCT_KNOWLEDGE.services.audit.stripeLink }
        ]
      };
    
    case 'consultation':
      return {
        content: `💼 **Service : Consultation Stratégique**\n\nPrix : ${PRODUCT_KNOWLEDGE.services.consultation.price} (paiement unique)\n\n${PRODUCT_KNOWLEDGE.services.consultation.description}\n\nAu programme :\n• Session vidéo de 60 minutes\n• Analyse de vos besoins\n• Recommandations d'experts\n• Q&A personnalisée\n\nRéservez votre créneau dès maintenant !`,
        suggestions: [
          'Réserver une consultation',
          'Voir les disponibilités',
          'Questions fréquentes'
        ],
        productLinks: [
          { label: '🛒 Réserver Consultation (147 $CA)', url: PRODUCT_KNOWLEDGE.services.consultation.stripeLink }
        ]
      };
    
    case 'training':
      return {
        content: `🎓 **Service : Formation IA pour Équipes**\n\nPrix : ${PRODUCT_KNOWLEDGE.services.training.price} (paiement unique)\n\n${PRODUCT_KNOWLEDGE.services.training.description}\n\nCe que vous apprendrez :\n• Fondamentaux de l'IA pour les entreprises\n• Comment utiliser nos outils\n• Meilleures pratiques d'automatisation\n• Cas d'usage concrets\n• Session pratique\n\nFormation sur site ou en ligne, jusqu'à 10 participants.`,
        suggestions: [
          'Réserver une formation',
          'Programme détaillé',
          'Demander un devis groupe'
        ],
        productLinks: [
          { label: '🛒 Réserver Formation (997 $CA)', url: PRODUCT_KNOWLEDGE.services.training.stripeLink }
        ]
      };
    
    case 'purchase':
      return {
        content: "🛒 **Prêt à acheter ?**\n\nSuper ! Voici comment procéder :\n\n1. Choisissez votre produit ci-dessous\n2. Cliquez sur le lien de paiement sécurisé (Stripe)\n3. Complétez votre commande\n4. Recevez votre confirmation par email\n5. Notre équipe vous contacte sous 24h pour le déploiement\n\nQuel produit vous intéresse ?",
        suggestions: [
          'Plan Starter (68 $CA/mois)',
          'Plan Professional (208 $CA/mois)',
          'Audit IA (497 $CA)',
          'Voir tous les produits'
        ]
      };
    
    case 'help':
      return {
        content: "🤝 **Comment puis-je vous aider ?**\n\nJe peux vous renseigner sur :\n\n📊 **Plans & Tarifs**\n• Starter, Professional, Enterprise\n\n🤖 **Micro-Agents**\n• Qualification de leads\n• Support client 24/7\n• Gestion de rendez-vous\n• Immobilier, E-commerce, etc.\n\n🎯 **Services**\n• Audit IA complet\n• Consultation stratégique\n• Formation pour équipes\n\nQu'est-ce qui vous intéresse ?",
        suggestions: [
          'Voir les plans',
          'Découvrir les micro-agents',
          'Services professionnels',
          'Parler à un humain'
        ]
      };
    
    default:
      return {
        content: "Je comprends que vous avez une question. Pouvez-vous préciser ce qui vous intéresse ?\n\nJe peux vous aider avec :\n• Nos plans et tarifs\n• Les micro-agents disponibles\n• Nos services professionnels\n• Le processus d'achat\n\nOu posez-moi directement votre question !",
        suggestions: [
          'Voir les plans',
          'Micro-agents disponibles',
          'Parler à un expert',
          'Essai gratuit'
        ]
      };
  }
}

export default function IntelligentChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Message de bienvenue automatique
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: Message = {
        id: 'welcome',
        role: 'assistant',
        content: "👋 Bonjour ! Je suis l'assistant IA de ZyatrIA Global.\n\nJe peux vous aider à :\n• Découvrir nos plans et tarifs\n• Choisir le bon micro-agent\n• Répondre à vos questions\n• Vous guider vers un achat\n\nQue puis-je faire pour vous ?",
        timestamp: new Date(),
        suggestions: [
          'Voir les plans et tarifs',
          'Découvrir les micro-agents',
          'Parler à un expert',
          'Essai gratuit 7 jours'
        ]
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    
    const newUserMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: userMessage,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsLoading(true);

    // Simuler un délai de réflexion (plus naturel)
    setTimeout(() => {
      const response = generateResponse(userMessage);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        suggestions: response.suggestions,
        productLinks: response.productLinks
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 800);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    // Auto-submit
    const fakeEvent = { preventDefault: () => {} } as React.FormEvent;
    setTimeout(() => {
      handleSubmit(fakeEvent);
    }, 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-blue-500 to-violet-500 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all hover:scale-110 animate-pulse-glow"
        aria-label="Ouvrir le chat IA"
        title="Besoin d'aide ? Cliquez ici !"
      >
        <Sparkles className="w-6 h-6" />
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white animate-pulse"></span>
      </button>
    );
  }

  return (
    <div 
      className={`fixed bottom-6 right-6 z-50 bg-white border-2 border-blue-200 rounded-2xl shadow-2xl transition-all flex flex-col ${
        isMinimized ? 'w-80 h-16' : 'w-96 h-[600px]'
      } max-w-[calc(100vw-3rem)] max-h-[calc(100vh-3rem)]`}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b-2 border-blue-200 bg-gradient-to-r from-blue-500 to-violet-500 text-white rounded-t-2xl flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Sparkles className="w-6 h-6" />
            <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white"></span>
          </div>
          <div>
            <h3 className="font-bold text-sm">Assistant IA ZyatrIA</h3>
            {!isMinimized && (
              <p className="text-xs opacity-90">En ligne • Réponse instantanée</p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMinimized(!isMinimized)}
            className="h-8 w-8 text-white hover:bg-white/20 hover:text-white"
            aria-label="Réduire"
            title="Réduire"
          >
            <Minimize2 className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(false)}
            className="h-10 w-10 text-white hover:bg-red-500/80 hover:text-white transition-all rounded-full"
            aria-label="Fermer le chat"
            title="Fermer"
          >
            <X className="w-6 h-6 stroke-[3]" />
          </Button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-blue-50/50 to-white">
            {messages.map((msg) => (
              <div key={msg.id}>
                <div
                  className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.role === 'assistant' && (
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-violet-500 flex items-center justify-center">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      msg.role === 'user'
                        ? 'bg-gradient-to-r from-blue-500 to-violet-500 text-white shadow-md'
                        : 'bg-white text-slate-900 border-2 border-blue-100 shadow-sm'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap leading-relaxed font-medium">{msg.content}</p>
                    <span className={`text-xs mt-2 block ${msg.role === 'user' ? 'opacity-90' : 'opacity-60'}`}>
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  {msg.role === 'user' && (
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center">
                      <User className="w-4 h-4 text-slate-700" />
                    </div>
                  )}
                </div>
                
                {/* Product Links */}
                {msg.productLinks && msg.productLinks.length > 0 && (
                  <div className="mt-3 ml-11 space-y-2">
                    {msg.productLinks.map((link, idx) => (
                      <a
                        key={idx}
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:from-green-600 hover:to-emerald-600 transition-all shadow-md hover:shadow-lg text-sm font-semibold"
                      >
                        <CreditCard className="w-4 h-4" />
                        {link.label}
                      </a>
                    ))}
                  </div>
                )}
                
                {/* Suggestions */}
                {msg.suggestions && msg.suggestions.length > 0 && (
                  <div className="mt-3 ml-11 flex flex-wrap gap-2">
                    {msg.suggestions.map((suggestion, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSuggestionClick(suggestion)}
                        className="px-3 py-1.5 bg-blue-100 text-blue-800 rounded-full text-xs font-medium hover:bg-blue-200 transition-colors border border-blue-200"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
            
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-violet-500 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div className="bg-white border-2 border-blue-100 rounded-2xl px-4 py-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-violet-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t-2 border-blue-200 bg-white flex-shrink-0">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Posez votre question..."
                disabled={isLoading}
                className="flex-1 border-2 border-blue-200 focus:border-blue-500 bg-white text-slate-900"
                onKeyDown={handleKeyPress}
              />
              <Button 
                type="submit" 
                size="icon"
                disabled={!input.trim() || isLoading}
                className="flex-shrink-0 bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </form>
            <p className="text-xs text-center text-slate-500 mt-2">
              💳 Paiements sécurisés par Stripe
            </p>
          </div>
        </>
      )}
    </div>
  );
}





