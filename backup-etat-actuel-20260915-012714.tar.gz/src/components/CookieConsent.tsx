import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { X, Cookie } from 'lucide-react';
import { useLanguage } from '../lib/language-context';

const translations = {
  en: {
    title: "🍪 We use cookies",
    description: "We use cookies to improve your experience on our site. By continuing to browse, you accept our use of cookies.",
    accept: "Accept",
    decline: "Decline",
    learnMore: "Learn more"
  },
  fr: {
    title: "🍪 Nous utilisons des cookies",
    description: "Nous utilisons des cookies pour améliorer votre expérience sur notre site. En continuant à naviguer, vous acceptez notre utilisation des cookies.",
    accept: "Accepter",
    decline: "Refuser",
    learnMore: "En savoir plus"
  },
  es: {
    title: "🍪 Usamos cookies",
    description: "Usamos cookies para mejorar su experiencia en nuestro sitio. Al continuar navegando, acepta nuestro uso de cookies.",
    accept: "Aceptar",
    decline: "Rechazar",
    learnMore: "Más información"
  },
  pt: {
    title: "🍪 Usamos cookies",
    description: "Usamos cookies para melhorar sua experiência em nosso site. Ao continuar navegando, você aceita nosso uso de cookies.",
    accept: "Aceitar",
    decline: "Recusar",
    learnMore: "Saiba mais"
  }
};

export default function CookieConsent() {
  const { language } = useLanguage();
  const t = translations[language];
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    // Check if user has already made a choice
    const consent = localStorage.getItem('cookie-consent');
    if (!consent) {
      // Show banner after a short delay for better UX
      setTimeout(() => setShowBanner(true), 1000);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookie-consent', 'accepted');
    setShowBanner(false);
    
    // Enable analytics if configured
    if (typeof window !== 'undefined') {
      // You can enable Google Analytics or other tracking here
      console.log('Cookies accepted - Analytics enabled');
    }
  };

  const handleDecline = () => {
    localStorage.setItem('cookie-consent', 'declined');
    setShowBanner(false);
    
    // Disable analytics
    if (typeof window !== 'undefined') {
      console.log('Cookies declined - Analytics disabled');
    }
  };

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 animate-fade-in-up">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white dark:bg-zinc-900 border-2 border-primary/20 rounded-xl shadow-2xl p-6 flex flex-col md:flex-row items-start md:items-center gap-4">
          {/* Icon */}
          <div className="flex-shrink-0">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
              <Cookie className="w-6 h-6 text-primary" />
            </div>
          </div>

          {/* Content */}
          <div className="flex-1">
            <h3 className="text-lg font-bold mb-1">{t.title}</h3>
            <p className="text-sm text-muted-foreground">
              {t.description}{' '}
              <a 
                href="/privacy" 
                className="text-primary hover:underline"
                aria-label="En savoir plus sur notre politique de confidentialité"
              >
                {t.learnMore}
              </a>
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3 w-full md:w-auto">
            <Button
              onClick={handleDecline}
              variant="outline"
              size="sm"
              className="flex-1 md:flex-none"
              aria-label="Refuser les cookies"
            >
              {t.decline}
            </Button>
            <Button
              onClick={handleAccept}
              size="sm"
              className="flex-1 md:flex-none"
              aria-label="Accepter les cookies"
            >
              {t.accept}
            </Button>
          </div>

          {/* Close button */}
          <button
            onClick={handleDecline}
            className="absolute top-4 right-4 md:relative md:top-0 md:right-0 p-2 hover:bg-muted rounded-lg transition-colors"
            aria-label="Fermer la bannière de cookies"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
