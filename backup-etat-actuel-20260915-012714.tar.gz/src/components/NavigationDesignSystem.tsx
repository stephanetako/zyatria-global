import React, { useState, useEffect } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { useLanguage } from '../lib/language-context';
import { baseUrl } from '../lib/base-url';

const translations = {
  fr: {
    links: [
      { label: 'Accueil', href: '#hero' },
      { label: 'Services', href: '#services' },
      { label: 'Micro-agents', href: '#micro-agents' },
      { label: 'Tarifs', href: '#pricing' },
      { label: 'Ressources', href: '#faq' }
    ],
    cta: 'Démo Gratuite',
    ctaHref: '#contact'
  },
  en: {
    links: [
      { label: 'Home', href: '#hero' },
      { label: 'Services', href: '#services' },
      { label: 'Micro-agents', href: '#micro-agents' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'Resources', href: '#faq' }
    ],
    cta: 'Free Demo',
    ctaHref: '#contact'
  }
};

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
  mobile?: boolean;
  onClick?: () => void;
}

const NavLink: React.FC<NavLinkProps> = ({ href, children, mobile = false, onClick }) => {
  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    if (onClick) onClick();
  };

  const baseStyle: React.CSSProperties = {
    color: '#374151',
    fontWeight: 600,
    textDecoration: 'none',
    transition: 'color 0.3s',
    cursor: 'pointer'
  };

  const mobileStyle: React.CSSProperties = mobile ? {
    display: 'block',
    padding: '10px 0',
    borderBottom: '1px solid #E5E7EB'
  } : {};

  return (
    <a 
      href={href}
      style={{ ...baseStyle, ...mobileStyle }}
      onClick={handleClick}
      onMouseEnter={(e) => {
        if (!mobile) {
          e.currentTarget.style.color = '#3B82F6';
        }
      }}
      onMouseLeave={(e) => {
        if (!mobile) {
          e.currentTarget.style.color = '#374151';
        }
      }}
    >
      {children}
    </a>
  );
};

const NavigationDesignSystem: React.FC = () => {
  const { language, setLanguage } = useLanguage();
  const t = translations[language];
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('#')) {
      e.preventDefault();
      const targetId = href.substring(1);
      
      // Fonction pour scroller vers l'élément
      const scrollToElement = () => {
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
          setIsMobileMenuOpen(false); // Fermer le menu mobile
          
          // Scroll avec offset pour la navigation fixe
          const navHeight = 80;
          const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navHeight;
          
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
          return true;
        }
        return false;
      };
      
      // Essayer immédiatement
      if (!scrollToElement()) {
        // Si l'élément n'est pas trouvé, réessayer après un court délai
        setTimeout(scrollToElement, 100);
      }
    }
  };

  const toggleLanguage = () => {
    setLanguage(language === 'fr' ? 'en' : 'fr');
  };

  return (
    <nav style={{
      background: 'white',
      padding: '15px 20px',
      boxShadow: isScrolled ? '0 4px 6px rgba(0, 0, 0, 0.1)' : '0 2px 4px rgba(0, 0, 0, 0.05)',
      position: 'sticky',
      top: 0,
      zIndex: 1000,
      transition: 'box-shadow 0.3s'
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        {/* Logo */}
        <a href={baseUrl || '/'}>
          <img 
            src={`${baseUrl}/zyatria-global-logo.svg`}
            alt="ZyatrIA Global" 
            style={{ width: '180px', height: 'auto' }}
            onError={(e) => {
              // Fallback si l'image n'existe pas
              const fallback = document.createElement('span');
              fallback.textContent = 'ZyatrIA Global';
              fallback.style.fontSize = '24px';
              fallback.style.fontWeight = 'bold';
              fallback.style.color = '#3B82F6';
              e.currentTarget.parentNode?.replaceChild(fallback, e.currentTarget);
            }}
          />
        </a>

        {/* Menu Desktop */}
        <div style={{
          display: 'flex',
          gap: '30px',
          alignItems: 'center'
        }}
        className="desktop-menu"
        >
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {t.links.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-sm font-medium hover:text-primary transition-colors"
                style={{ color: '#000000' }}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Language Switcher */}
          <button
            onClick={toggleLanguage}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              background: 'none',
              border: '2px solid #E5E7EB',
              borderRadius: '8px',
              padding: '6px 12px',
              cursor: 'pointer',
              fontWeight: 600,
              color: '#374151',
              transition: 'all 0.3s'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#3B82F6';
              e.currentTarget.style.color = '#3B82F6';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#E5E7EB';
              e.currentTarget.style.color = '#374151';
            }}
            aria-label="Change language"
          >
            <Globe size={16} />
            <span>{language.toUpperCase()}</span>
          </button>

          {/* CTA Button */}
          <a
            href={t.ctaHref}
            onClick={(e) => handleNavClick(e, t.ctaHref)}
            className="hidden md:inline-flex items-center justify-center font-medium hover:text-primary transition-colors"
            style={{ color: '#000000', textDecoration: 'none' }}
          >
            {t.cta}
          </a>
        </div>

        {/* Bouton Menu Mobile */}
        <button
          onClick={toggleMobileMenu}
          style={{
            display: 'none',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            color: '#374151'
          }}
          className="mobile-menu-button"
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Menu Mobile */}
      <div 
        style={{
          display: isMobileMenuOpen ? 'block' : 'none',
          background: 'white',
          padding: '20px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          marginTop: '15px',
          borderRadius: '8px'
        }}
        className="mobile-menu"
      >
        {/* Mobile Navigation Links */}
        <nav className="flex flex-col gap-4">
          {t.links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="text-lg font-medium hover:text-primary transition-colors"
              style={{ color: '#000000' }}
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Mobile CTA */}
        <a
          href={t.ctaHref}
          onClick={(e) => handleNavClick(e, t.ctaHref)}
          className="w-full inline-flex items-center justify-center font-medium hover:text-primary transition-colors"
          style={{ color: '#000000', textDecoration: 'none', padding: '10px 0' }}
        >
          {t.cta}
        </a>

        {/* Language Switcher Mobile */}
        <button
          onClick={() => {
            toggleLanguage();
            closeMobileMenu();
          }}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            width: '100%',
            padding: '10px 0',
            background: 'none',
            border: 'none',
            borderBottom: '1px solid #E5E7EB',
            cursor: 'pointer',
            fontWeight: 600,
            color: '#374151',
            fontSize: '16px'
          }}
        >
          <Globe size={20} />
          <span>{language === 'fr' ? 'English' : 'Français'}</span>
        </button>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .desktop-menu {
            display: none !important;
          }
          .mobile-menu-button {
            display: block !important;
          }
        }

        @media (min-width: 769px) {
          .mobile-menu {
            display: none !important;
          }
        }
      `}</style>
    </nav>
  );
};

export default NavigationDesignSystem;









