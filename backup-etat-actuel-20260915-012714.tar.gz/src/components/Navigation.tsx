





import React, { useState } from 'react';
import { Button } from './ui/button';
import { Globe, Menu, X, Home, Briefcase, Bot, DollarSign } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { baseUrl } from '../lib/base-url';
import { useLanguage } from '../lib/language-context';

const Navigation: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { language, setLanguage } = useLanguage();

  const languages = [
    { code: 'en' as const, name: 'English', flag: '🇬🇧' },
    { code: 'fr' as const, name: 'Français', flag: '🇫🇷' },
  ];

  const translations: Record<string, any> = {
    en: {
      home: 'Home',
      services: 'Services',
      microAgents: 'Micro-agents',
      pricing: 'Pricing',
      demo: 'Demo',
      about: 'About',
      getStarted: 'Get Started',
      resources: 'Resources',
      technology: 'Technology',
      docs: 'Documentation',
      help: 'Help Center',
      contact: 'Contact',
    },
    fr: {
      home: 'Accueil',
      services: 'Services',
      microAgents: 'Micro-agents',
      pricing: 'Tarifs',
      demo: 'Démo',
      about: 'À propos',
      getStarted: 'Commencer',
      resources: 'Ressources',
      technology: 'Technologie',
      docs: 'Documentation',
      help: 'Centre d\'Aide',
      contact: 'Contact',
    },
  };

  const t = translations[language];
  const currentLanguage = languages.find(lang => lang.code === language);

  // Smooth scroll to section
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  // Navigate to page
  const navigateToPage = (path: string) => {
    window.location.href = `${baseUrl}${path}`;
    setMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <button onClick={() => window.location.href = baseUrl} className="flex items-center group">
            <img 
              src="/zyatria-global-logo.svg" 
              alt="ZyatrIA Global — Agents IA Intelligents pour les Entreprises Modernes"
              style={{ width: '150px', height: 'auto' }}
              className="transition-transform group-hover:scale-105"
            />
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={() => window.location.href = baseUrl} className="text-foreground hover:text-primary transition flex items-center gap-1.5">
              <Home className="w-4 h-4" />
              {t.home}
            </button>
            <button onClick={() => navigateToPage('/services')} className="text-foreground hover:text-primary transition flex items-center gap-1.5">
              <Briefcase className="w-4 h-4" />
              {t.services}
            </button>
            <button onClick={() => navigateToPage('/micro-agents')} className="text-foreground hover:text-primary transition flex items-center gap-1.5">
              <Bot className="w-4 h-4" />
              {t.microAgents}
            </button>
            <button onClick={() => navigateToPage('/pricing')} className="text-foreground hover:text-primary transition flex items-center gap-1.5">
              <DollarSign className="w-4 h-4" />
              {t.pricing}
            </button>
            
            {/* Resources Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="text-foreground hover:text-primary transition flex items-center gap-1">
                  {t.resources}
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <button onClick={() => navigateToPage('/knowledge-base')} className="cursor-pointer w-full text-left">
                    {t.technology}
                  </button>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <button onClick={() => navigateToPage('/knowledge-base')} className="cursor-pointer w-full text-left">
                    {t.docs}
                  </button>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <button onClick={() => navigateToPage('/about')} className="cursor-pointer w-full text-left">
                    {t.help}
                  </button>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* Language Selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Globe className="w-4 h-4" />
                  <span className="hidden sm:inline">{currentLanguage?.flag}</span>
                  <span className="hidden lg:inline">{currentLanguage?.name}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {languages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    onClick={() => setLanguage(lang.code)}
                    className="cursor-pointer"
                  >
                    <span className="mr-2">{lang.flag}</span>
                    {lang.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* CTA Button */}
            <Button onClick={() => navigateToPage('/demo')} className="hidden md:inline-flex">
              {t.contact}
            </Button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-foreground hover:text-primary transition-colors"
              aria-label={mobileMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-4 border-t border-border">
            <button
              onClick={() => window.location.href = baseUrl}
              className="block w-full text-left text-foreground hover:text-primary transition flex items-center gap-2"
            >
              <Home className="w-4 h-4" />
              {t.home}
            </button>
            <button
              onClick={() => navigateToPage('/services')}
              className="block w-full text-left text-foreground hover:text-primary transition flex items-center gap-2"
            >
              <Briefcase className="w-4 h-4" />
              {t.services}
            </button>
            <button
              onClick={() => navigateToPage('/micro-agents')}
              className="block w-full text-left text-foreground hover:text-primary transition flex items-center gap-2"
            >
              <Bot className="w-4 h-4" />
              {t.microAgents}
            </button>
            <button
              onClick={() => navigateToPage('/pricing')}
              className="block w-full text-left text-foreground hover:text-primary transition flex items-center gap-2"
            >
              <DollarSign className="w-4 h-4" />
              {t.pricing}
            </button>
            <button
              onClick={() => navigateToPage('/knowledge-base')}
              className="block w-full text-left text-foreground hover:text-primary transition"
            >
              {t.technology}
            </button>
            <button
              onClick={() => navigateToPage('/knowledge-base')}
              className="block w-full text-left text-foreground hover:text-primary transition"
            >
              {t.docs}
            </button>
            <button
              onClick={() => navigateToPage('/about')}
              className="block w-full text-left text-foreground hover:text-primary transition"
            >
              {t.help}
            </button>
            <Button 
              className="w-full"
              onClick={() => navigateToPage('/demo')}
              aria-label="Commencer maintenant - Contactez-nous"
            >
              {t.contact}
            </Button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;


































