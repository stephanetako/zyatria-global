# Script de déploiement ZyatrIA Global sur Cloudflare Pages
# Encodage: UTF-8 avec BOM pour PowerShell

Write-Host "🚀 Déploiement de ZyatrIA Global..." -ForegroundColor Cyan
Write-Host ""

# Vérifier si npm est installé
Write-Host "📦 Vérification de npm..." -ForegroundColor Yellow
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Host "❌ ERREUR: npm n'est pas installé!" -ForegroundColor Red
    Write-Host "Installez Node.js depuis https://nodejs.org" -ForegroundColor Yellow
    pause
    exit 1
}
Write-Host "✅ npm trouvé" -ForegroundColor Green

# Vérifier si wrangler est installé
Write-Host "📦 Vérification de wrangler..." -ForegroundColor Yellow
if (-not (Get-Command wrangler -ErrorAction SilentlyContinue)) {
    Write-Host "⚠️  wrangler n'est pas installé globalement" -ForegroundColor Yellow
    Write-Host "📥 Installation de wrangler..." -ForegroundColor Cyan
    npm install -g wrangler
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Échec de l'installation de wrangler" -ForegroundColor Red
        pause
        exit 1
    }
}
Write-Host "✅ wrangler trouvé" -ForegroundColor Green
Write-Host ""

# Installer les dépendances
Write-Host "📦 Installation des dépendances..." -ForegroundColor Yellow
npm install
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Échec de l'installation des dépendances" -ForegroundColor Red
    pause
    exit 1
}
Write-Host "✅ Dépendances installées" -ForegroundColor Green
Write-Host ""

# Build du projet
Write-Host "🔨 Build du projet..." -ForegroundColor Yellow
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Échec du build" -ForegroundColor Red
    pause
    exit 1
}
Write-Host "✅ Build réussi" -ForegroundColor Green
Write-Host ""

# Déploiement sur Cloudflare Pages
Write-Host "🚀 Déploiement sur Cloudflare Pages..." -ForegroundColor Cyan
Write-Host ""

# Vérifier si l'utilisateur est connecté à Cloudflare
Write-Host "🔐 Vérification de l'authentification Cloudflare..." -ForegroundColor Yellow
wrangler whoami 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠️  Vous n'êtes pas connecté à Cloudflare" -ForegroundColor Yellow
    Write-Host "🔑 Connexion à Cloudflare..." -ForegroundColor Cyan
    wrangler login
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Échec de la connexion à Cloudflare" -ForegroundColor Red
        pause
        exit 1
    }
}
Write-Host "✅ Authentifié sur Cloudflare" -ForegroundColor Green
Write-Host ""

# Déployer
Write-Host "📤 Déploiement en cours..." -ForegroundColor Cyan
wrangler pages deploy dist --project-name=zyatria-global
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Échec du déploiement" -ForegroundColor Red
    pause
    exit 1
}

Write-Host ""
Write-Host "✅ ========================================" -ForegroundColor Green
Write-Host "✅ DÉPLOIEMENT RÉUSSI!" -ForegroundColor Green
Write-Host "✅ ========================================" -ForegroundColor Green
Write-Host ""
Write-Host "🌐 Votre site est en ligne sur:" -ForegroundColor Cyan
Write-Host "   https://zyatria-global.pages.dev" -ForegroundColor White
Write-Host ""
Write-Host "📊 Tableau de bord Cloudflare:" -ForegroundColor Cyan
Write-Host "   https://dash.cloudflare.com" -ForegroundColor White
Write-Host ""

pause
