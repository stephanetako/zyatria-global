@echo off
echo.
echo ========================================
echo   DEPLOIEMENT ZYATRIA GLOBAL
echo ========================================
echo.
echo Double-cliquez sur ce fichier pour deployer automatiquement
echo.
pause

powershell -ExecutionPolicy Bypass -File "%~dp0deploy.ps1"

echo.
echo Appuyez sur une touche pour fermer...
pause >nul
