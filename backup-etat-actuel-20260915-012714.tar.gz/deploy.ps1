# Script de déploiement automatique pour ZyatrIA Global
# Utilisation: .\deploy.ps1

Write-Host "🚀 Déploiement de ZyatrIA Global" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""

# Étape 0: Vérification de la configuration
Write-Host "🔍 Vérification de la configuration..." -ForegroundColor Yellow
& .\verifier-config.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "❌ Déploiement annulé en raison d'erreurs de configuration" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Étape 1: Nettoyage
Write-Host "🧹 Nettoyage des fichiers de build..." -ForegroundColor Yellow
Remove-Item -Recurse -Force dist, .astro -ErrorAction SilentlyContinue
Write-Host "✓ Nettoyage terminé" -ForegroundColor Green
Write-Host ""

# Étape 2: Build
Write-Host "🔨 Construction du projet..." -ForegroundColor Yellow
npm run build

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Erreur lors du build!" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Build terminé avec succès" -ForegroundColor Green
Write-Host ""

# Étape 3: Déploiement
Write-Host "☁️  Déploiement sur Cloudflare Pages..." -ForegroundColor Yellow
npx wrangler pages deploy dist --project-name=zyatria-global --commit-dirty=true

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Erreur lors du déploiement!" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "✨ Déploiement terminé avec succès!" -ForegroundColor Green
Write-Host "🌐 Votre site est en ligne à: https://zyatria-global.pages.dev" -ForegroundColor Cyan
Write-Host ""

