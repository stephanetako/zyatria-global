# Script de push manuel vers GitHub
# Ce script pousse le code vers GitHub pour déclencher le déploiement Cloudflare

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   PUSH VERS GITHUB" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Vérifier qu'on est dans le bon dossier
if (-not (Test-Path ".git")) {
    Write-Host "ERREUR: Pas dans un dossier Git!" -ForegroundColor Red
    Write-Host "Assurez-vous d'etre dans le dossier zyatria-global" -ForegroundColor Yellow
    pause
    exit 1
}

Write-Host "Verification du statut Git..." -ForegroundColor Yellow
git status --short

Write-Host ""
Write-Host "Le commit est deja fait (895e527)" -ForegroundColor Green
Write-Host "Maintenant on pousse vers GitHub..." -ForegroundColor Yellow
Write-Host ""

# Tenter le push
Write-Host "Execution: git push origin master" -ForegroundColor Cyan
Write-Host ""

git push origin master

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "   SUCCES!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Le code est sur GitHub!" -ForegroundColor Green
    Write-Host "Cloudflare Pages va deployer automatiquement." -ForegroundColor Green
    Write-Host ""
    Write-Host "Attendez 2-3 minutes puis allez sur:" -ForegroundColor Yellow
    Write-Host "https://zyatria-global.pages.dev" -ForegroundColor Cyan
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "   ERREUR D'AUTHENTIFICATION" -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "SOLUTIONS:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "1. Utilisez GitHub Desktop (plus simple)" -ForegroundColor White
    Write-Host "   - Ouvrez GitHub Desktop" -ForegroundColor Gray
    Write-Host "   - Cliquez sur 'Push origin'" -ForegroundColor Gray
    Write-Host ""
    Write-Host "2. Ou creez un token GitHub:" -ForegroundColor White
    Write-Host "   - Allez sur: https://github.com/settings/tokens" -ForegroundColor Gray
    Write-Host "   - Generate new token (classic)" -ForegroundColor Gray
    Write-Host "   - Cochez 'repo'" -ForegroundColor Gray
    Write-Host "   - Copiez le token" -ForegroundColor Gray
    Write-Host "   - Puis tapez:" -ForegroundColor Gray
    Write-Host "     git push https://VOTRE_TOKEN@github.com/VOTRE_USERNAME/zyatria-global.git master" -ForegroundColor Cyan
    Write-Host ""
}

Write-Host ""
pause
