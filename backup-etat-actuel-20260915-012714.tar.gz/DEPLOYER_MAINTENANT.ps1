#!/usr/bin/env pwsh
# Script de déploiement ZyatrIA Global - Juillet 2026
# Déploiement automatique sur Cloudflare Pages

Write-Host "🚀 DÉPLOIEMENT ZYATRIA GLOBAL - JUILLET 2026" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

# Étape 1: Vérification de l'environnement
Write-Host "📋 Étape 1/5: Vérification de l'environnement..." -ForegroundColor Yellow
if (-not (Test-Path "package.json")) {
    Write-Host "❌ Erreur: package.json introuvable!" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Environnement OK" -ForegroundColor Green
Write-Host ""

# Étape 2: Installation des dépendances
Write-Host "📦 Étape 2/5: Installation des dépendances..." -ForegroundColor Yellow
npm install
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Erreur lors de l'installation des dépendances!" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Dépendances installées" -ForegroundColor Green
Write-Host ""

# Étape 3: Build du projet
Write-Host "🔨 Étape 3/5: Build du projet..." -ForegroundColor Yellow
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Erreur lors du build!" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Build réussi" -ForegroundColor Green
Write-Host ""

# Étape 4: Vérification du dossier dist
Write-Host "🔍 Étape 4/5: Vérification du build..." -ForegroundColor Yellow
if (-not (Test-Path "dist")) {
    Write-Host "❌ Erreur: Dossier dist introuvable!" -ForegroundColor Red
    exit 1
}
$distSize = (Get-ChildItem -Path "dist" -Recurse | Measure-Object -Property Length -Sum).Sum / 1MB
Write-Host "✅ Build vérifié ($([math]::Round($distSize, 2)) MB)" -ForegroundColor Green
Write-Host ""

# Étape 5: Déploiement sur Cloudflare
Write-Host "🌐 Étape 5/5: Déploiement sur Cloudflare Pages..." -ForegroundColor Yellow
Write-Host ""
Write-Host "📝 INSTRUCTIONS DE DÉPLOIEMENT:" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Option 1 - Déploiement automatique via Git:" -ForegroundColor White
Write-Host "  1. Commitez vos changements:" -ForegroundColor Gray
Write-Host "     git add ." -ForegroundColor Gray
Write-Host "     git commit -m 'Deploy ZyatrIA Global - Juillet 2026'" -ForegroundColor Gray
Write-Host "     git push origin main" -ForegroundColor Gray
Write-Host ""
Write-Host "Option 2 - Déploiement manuel via Wrangler:" -ForegroundColor White
Write-Host "  1. Installez Wrangler si nécessaire:" -ForegroundColor Gray
Write-Host "     npm install -g wrangler" -ForegroundColor Gray
Write-Host "  2. Connectez-vous à Cloudflare:" -ForegroundColor Gray
Write-Host "     wrangler login" -ForegroundColor Gray
Write-Host "  3. Déployez:" -ForegroundColor Gray
Write-Host "     wrangler pages deploy dist --project-name=zyatria-global" -ForegroundColor Gray
Write-Host ""
Write-Host "Option 3 - Via le Dashboard Cloudflare:" -ForegroundColor White
Write-Host "  1. Allez sur https://dash.cloudflare.com" -ForegroundColor Gray
Write-Host "  2. Pages > zyatria-global > Settings" -ForegroundColor Gray
Write-Host "  3. Cliquez sur 'Retry deployment' ou 'Create deployment'" -ForegroundColor Gray
Write-Host ""
Write-Host "✅ BUILD PRÊT POUR LE DÉPLOIEMENT!" -ForegroundColor Green
Write-Host ""
Write-Host "📊 CONTENU DU PROJET:" -ForegroundColor Cyan
Write-Host "  ✅ 6 Micro-Agents IA interactifs" -ForegroundColor Green
Write-Host "  ✅ 14 Produits Stripe (LIVE MODE)" -ForegroundColor Green
Write-Host "  ✅ Chatbot Mistral IA" -ForegroundColor Green
Write-Host "  ✅ Support multilingue (EN/FR)" -ForegroundColor Green
Write-Host "  ✅ Design System complet" -ForegroundColor Green
Write-Host ""
Write-Host "🎉 Prêt à déployer!" -ForegroundColor Cyan
