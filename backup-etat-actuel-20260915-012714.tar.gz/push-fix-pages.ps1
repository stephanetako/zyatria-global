Write-Host "=== PUSH CORRECTION PAGES ===" -ForegroundColor Cyan
Write-Host ""

# Push avec le token GitHub
git push https://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@github.com/stephanetako/zyatria-global.git main

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✓ PUSH REUSSI!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Le deploiement va demarrer automatiquement sur Cloudflare." -ForegroundColor Yellow
    Write-Host "Attendez 2-3 minutes puis testez:" -ForegroundColor Yellow
    Write-Host "https://zyatria-global-cve.pages.dev" -ForegroundColor Cyan
} else {
    Write-Host ""
    Write-Host "✗ ERREUR PUSH!" -ForegroundColor Red
}
