# 🎨 ÉTAPE 1 : Images OG + Favicon

## 📋 Vue d'ensemble

Cette première étape consiste à créer les images qui représenteront votre site sur les réseaux sociaux et dans les onglets de navigateur.

---

## 🖼️ Images OG (Open Graph)

### Qu'est-ce que c'est ?
Les images OG s'affichent quand vous partagez votre site sur :
- Facebook
- LinkedIn
- Twitter/X
- WhatsApp
- Slack
- etc.

### Spécifications techniques
- **Format** : JPG ou PNG
- **Dimensions** : 1200 x 630 pixels (format horizontal)
- **Poids** : Maximum 5 MB (idéalement < 500 KB)
- **Nom du fichier** : `og-image.jpg`

### Contenu recommandé pour ZyatrIA Global

```
┌─────────────────────────────────────────┐
│  [Logo ZyatrIA]                         │
│                                         │
│  ZyatrIA Global                         │
│  AI Without Borders                     │
│                                         │
│  🤖 AI Agents • ⚡ Automation           │
│  🚀 Deploy in 7-15 days                 │
│                                         │
│  🇨🇦 Canadian Company                   │
└─────────────────────────────────────────┘
```

---

## 🎯 Favicon

### Qu'est-ce que c'est ?
Le favicon est la petite icône qui apparaît dans l'onglet du navigateur.

### Spécifications techniques
- **Format** : SVG (recommandé) ou PNG
- **Dimensions** : 32 x 32 pixels (ou format carré)
- **Nom du fichier** : `favicon.svg` ou `favicon.ico`

### Design recommandé
- Logo simplifié de ZyatrIA
- Monochrome ou 2 couleurs max
- Lisible même en très petit

---

## 🛠️ OPTION 1 : Canva (Gratuit & Facile)

### 1. Créer l'image OG

#### A. Ouvrir Canva
👉 [canva.com](https://www.canva.com)

#### B. Créer un design personnalisé
1. Cliquez sur "Créer un design"
2. Sélectionnez "Dimensions personnalisées"
3. Entrez : **1200 x 630 pixels**

#### C. Design de l'image
```
Éléments à inclure :
✅ Fond dégradé (bleu → violet) ou couleur #C98769
✅ Logo ZyatrIA (à créer ou importer)
✅ Titre : "ZyatrIA Global"
✅ Slogan : "AI Without Borders"
✅ Icônes : 🤖 ⚡ 🚀
✅ Badge : "🇨🇦 Canadian Company"
```

#### D. Télécharger
1. Cliquez sur "Partager"
2. Choisir "Télécharger"
3. Format : **JPG** (meilleure compression)
4. Qualité : **Standard** (suffit amplement)
5. Renommer le fichier en : **og-image.jpg**

### 2. Créer le Favicon

#### A. Nouveau design Canva
1. "Créer un design" → "Dimensions personnalisées"
2. Entrez : **512 x 512 pixels** (on réduira après)

#### B. Design simple
```
Option 1 : Lettre "Z" stylisée
Option 2 : Robot/AI icon minimaliste
Option 3 : Initiales "ZG" dans un cercle
```

**Conseil** : Faites simple, ça sera réduit à 32x32px

#### C. Télécharger
1. Format : **PNG** avec fond transparent
2. Renommer : **favicon-512.png**

#### D. Convertir en favicon
👉 Aller sur [favicon.io](https://favicon.io/favicon-converter/)
1. Upload votre `favicon-512.png`
2. Télécharger le package généré
3. Extraire le fichier `favicon.ico`

---

## 🛠️ OPTION 2 : Figma (Plus Pro)

Si vous avez déjà un designer ou si vous utilisez Figma :

### Template recommandé
```
Frame 1 : OG Image (1200 x 630)
Frame 2 : Favicon (512 x 512)
```

### Export
- OG Image : JPG, 80% qualité
- Favicon : PNG, transparent

---

## 📦 OPTION 3 : Générateurs en ligne

### Pour l'OG Image
- [og-image.vercel.app](https://og-image.vercel.app/)
- [bannerbear.com](https://www.bannerbear.com/)

### Pour le Favicon
- [favicon.io](https://favicon.io/)
- [realfavicongenerator.net](https://realfavicongenerator.net/)

---

## 📁 Installation des fichiers

### 1. Placer les fichiers dans votre projet

```bash
# Structure finale
/public
  ├── og-image.jpg       # Image OG principale
  ├── favicon.svg        # Favicon moderne (SVG)
  └── favicon.ico        # Favicon legacy (ICO)
```

### 2. Commandes pour ajouter les fichiers

```bash
# Si vous avez les fichiers sur votre ordinateur
# Placez-les dans le dossier /public de votre projet
```

---

## ✅ Vérification

### Tester l'image OG
1. **Facebook Debugger** : [developers.facebook.com/tools/debug](https://developers.facebook.com/tools/debug/)
2. **LinkedIn Inspector** : [linkedin.com/post-inspector](https://www.linkedin.com/post-inspector/)
3. **Twitter Card Validator** : [cards-dev.twitter.com/validator](https://cards-dev.twitter.com/validator)

### Tester le favicon
1. Ouvrez votre site dans le navigateur
2. Regardez l'onglet → le favicon doit apparaître
3. Testez dans Chrome, Firefox, Safari

---

## 🎨 Recommandations de Design

### Palette de couleurs ZyatrIA Global
```css
Primary:    #C98769  (Terracotta chaud)
Secondary:  #E6DCD4  (Beige clair)
Background: #F5F1EB  (Crème)
Foreground: #373D36  (Vert foncé)
```

### Typographie
- **Titre** : Instrument Sans (Bold)
- **Corps** : Instrument Sans (Regular)

### Style visuel
- ✅ Moderne, épuré
- ✅ International, professionnel
- ✅ Chaleureux mais tech
- ✅ Minimaliste

---

## 📝 Template texte pour l'image OG

```
┌──────────────────────────────────────────┐
│                                          │
│         [LOGO ZYATRIA]                   │
│                                          │
│      ZyatrIA Global                      │
│      AI Without Borders                  │
│                                          │
│   🤖 Intelligent AI Agents               │
│   ⚡ Advanced Automation                 │
│   🚀 Deploy in 7-15 Days                 │
│                                          │
│   🇨🇦 Canadian Company | Quebec          │
│                                          │
└──────────────────────────────────────────┘
```

---

## 🚀 Prochaines étapes

Une fois vos images créées et placées dans `/public` :

✅ **Étape 1 terminée !**

➡️ **Étape 2** : Configuration du formulaire de contact (Formspree)

---

## 💡 Besoin d'aide ?

### Si vous n'avez pas de logo
Deux options :
1. **Temporaire** : Utilisez juste le texte "ZyatrIA" stylisé
2. **Professionnel** : Engagez un designer sur Fiverr (15-50$)

### Si vous voulez que je le fasse
Partagez-moi :
- Votre logo (si vous en avez un)
- Les couleurs préférées
- Le style souhaité

Et je vous créerai un template Canva prêt à l'emploi !

---

## 📊 Checklist finale

Avant de passer à l'étape 2 :

- [ ] Image OG créée (1200x630px)
- [ ] Favicon créé (ICO ou SVG)
- [ ] Fichiers placés dans `/public`
- [ ] Image OG testée sur Facebook Debugger
- [ ] Favicon visible dans le navigateur
- [ ] Design cohérent avec la marque ZyatrIA

---

**🎯 Temps estimé : 30-60 minutes**

**💰 Coût : Gratuit** (avec Canva ou générateurs en ligne)
