# ⚡ QUICK START - ZYATRIA GLOBAL

## 🚀 DÉMARRAGE ULTRA-RAPIDE

### 3 Commandes Pour Lancer Le Site

```bash
# 1. Installer les dépendances
npm install

# 2. Lancer le serveur
npm run dev

# 3. Ouvrir dans le navigateur
# http://localhost:3000
```

**C'est tout ! 🎉**

---

## 📦 CONTENU DU PACKAGE

✅ **24 Sections Premium**
- Navigation
- Hero + Live Stats
- Services & Micro-Agents
- Pricing & Comparaison
- Case Studies & Testimonials
- FAQ & Contact
- Footer + Live Chat

✅ **4 Langues Intégrées**
- 🇬🇧 English
- 🇫🇷 Français
- 🇪🇸 Español
- 🇵🇹 Português

✅ **8 Pages Complètes**
- Accueil (Homepage)
- Services
- Micro-Agents
- Pricing
- About
- Demo/Contact
- Technology
- Knowledge Base

✅ **Design Premium**
- Responsive mobile-first
- Animations fluides
- Couleurs modernes
- Typographie professionnelle

---

## 🎯 PROCHAINES ÉTAPES

### 1. Personnalisation Basique (5 min)

**Changer les couleurs :**
```css
/* src/styles/color-override.css */
:root {
  --primary: #C98769;  /* Votre couleur */
}
```

**Modifier les textes :**
```typescript
// src/components/Hero.tsx
<h1>Votre Nouveau Titre</h1>
```

### 2. Configurer Formspree (2 min)

1. Allez sur https://formspree.io
2. Créez un compte gratuit
3. Créez un formulaire
4. Copiez votre Form ID
5. Collez dans `src/components/Contact.tsx`

### 3. Déployer (5 min)

```bash
# Build
npm run build

# Déployer sur Cloudflare Pages (gratuit)
npx wrangler pages deploy dist
```

---

## 📚 DOCUMENTATION

**Guide Complet :** `INSTALLATION_GUIDE.md`  
**Migration Webflow :** `../MIGRATION_VERS_WEBFLOW_DESIGNER.md`  

---

## 🆘 BESOIN D'AIDE ?

### Problème de Démarrage
```bash
# Nettoyer et réinstaller
rm -rf node_modules
npm install
npm run dev
```

### Port Déjà Utilisé
```bash
npx kill-port 3000
npm run dev
```

### Build qui Échoue
```bash
rm -rf dist node_modules
npm install
npm run build
```

---

## ✅ CHECKLIST

- [ ] Node.js installé (v18+)
- [ ] `npm install` exécuté
- [ ] `npm run dev` fonctionne
- [ ] Site visible sur localhost:3000
- [ ] Toutes les pages accessibles
- [ ] Navigation fonctionnelle
- [ ] Responsive vérifié

---

## 🎉 PRÊT À DÉMARRER !

```bash
cd ZYATRIA_EXPORT
npm install
npm run dev
```

**Votre site sera disponible sur :**
👉 http://localhost:3000

---

**Temps d'installation :** 2-5 minutes  
**Difficulté :** Débutant ✅  
**Support :** Documentation complète incluse
