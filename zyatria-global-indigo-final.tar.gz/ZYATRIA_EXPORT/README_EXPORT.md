# 📦 ZYATRIA GLOBAL - EXPORT COMPLET

## 🎯 CONTENU DE CE PACKAGE

Ce package contient **TOUT** le site ZyatrIA Global prêt à être déployé.

---

## 📁 STRUCTURE DU PACKAGE

```
ZYATRIA_EXPORT/
├── README_EXPORT.md (ce fichier)
├── INSTALLATION_GUIDE.md (guide d'installation)
├── src/ (tous les composants React)
├── styles/ (tous les styles CSS)
├── pages/ (toutes les pages Astro)
├── public/ (assets statiques)
├── generated/ (fonts et webflow.css)
└── config/ (fichiers de configuration)
```

---

## 🚀 INSTALLATION RAPIDE

### Option 1 : Nouveau Projet Astro

```bash
# 1. Créer un nouveau projet Astro
npm create astro@latest zyatria-copy

# 2. Choisir : Empty project

# 3. Copier tous les fichiers de ce package dans le nouveau projet

# 4. Installer les dépendances
cd zyatria-copy
npm install

# 5. Lancer le serveur de développement
npm run dev
```

### Option 2 : Import dans Projet Existant

```bash
# Copier les dossiers src/, public/, generated/ dans votre projet
# Fusionner package.json dependencies
# Lancer npm install
```

---

## 📋 DÉPENDANCES REQUISES

Toutes listées dans `package.json` :
- Astro 5.13+
- React 19+
- Tailwind CSS 4+
- ShadCN UI components
- Lucide React icons

---

## 🌍 CONFIGURATION MULTILINGUE

Le site supporte 4 langues :
- 🇬🇧 English (par défaut)
- 🇫🇷 Français
- 🇪🇸 Español
- 🇵🇹 Português

---

## 🔧 PERSONNALISATION

### Changer les Couleurs

Éditez `generated/webflow.css` ou `src/styles/color-override.css`

### Modifier le Contenu

Tous les textes sont dans les composants :
- `src/components/*.tsx`

### Ajouter des Pages

Créez de nouveaux fichiers dans `src/pages/`

---

## 🚀 DÉPLOIEMENT

### Cloudflare Pages (Recommandé)

```bash
npm run build
npx wrangler pages deploy dist
```

### Vercel

```bash
npm run build
vercel deploy
```

### Netlify

```bash
npm run build
netlify deploy --prod
```

---

## 📞 SUPPORT

- Documentation Astro : https://docs.astro.build
- ShadCN UI : https://ui.shadcn.com
- Tailwind CSS : https://tailwindcss.com

---

## ✅ CHECKLIST POST-INSTALLATION

- [ ] Site lance correctement (npm run dev)
- [ ] Toutes les pages accessibles
- [ ] Navigation fonctionnelle
- [ ] Formulaires configurés (Formspree)
- [ ] Responsive vérifié
- [ ] Prêt pour production

---

**Site créé le :** 2026-02-06  
**Version :** 1.0 Complete Export  
**Projet :** ZyatrIA Global
