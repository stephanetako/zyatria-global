

import React, { useState } from 'react';
import { Check, ArrowRight, Sparkles, Zap, Rocket, DollarSign } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface PricingProps {
  lang?: string;
}

const translations = {
  en: {
    badge: "Our Plans",
    title: "Solutions Tailored to Every Business",
    subtitle: "Available in EUR, USD, and CAD",
    currencies: {
      eur: 'EUR €',
      usd: 'USD $',
      cad: 'CAD $'
    },
    monthly: 'Monthly',
    yearly: 'Yearly',
    save: 'Save 20%',
    monthlyPrice: '/month',
    yearlyPrice: '/year',
    billed: 'Billed monthly',
    billedYearly: 'Billed yearly',
    customPricing: 'Custom',
    from: 'From',
    plans: [
      {
        name: "Starter",
        subtitle: "Perfect for testing automation",
        price: { eur: 49, usd: 52, cad: 69 },
        priceYearly: { eur: 470, usd: 499, cad: 662 },
        period: "/month",
        description: "Start small, see results fast",
        features: [
          "1 AI micro-agent",
          "24/7 responses",
          "Email support"
        ],
        cta: "Start Free Trial",
        popular: false,
        highlight: "✓ No credit card required",
        icon: Sparkles
      },
      {
        name: "Business",
        subtitle: "For scaling teams",
        price: { eur: 149, usd: 159, cad: 199 },
        priceYearly: { eur: 1430, usd: 1526, cad: 1910 },
        period: "/month",
        description: "Everything you need to grow faster",
        features: [
          "3 AI micro-agents",
          "Advanced automations",
          "CRM integrations",
          "Priority support"
        ],
        cta: "Start 14-Day Trial",
        popular: true,
        highlight: "✓ Most popular choice",
        icon: Zap
      },
      {
        name: "Enterprise",
        subtitle: "Custom solutions",
        priceFrom: { eur: 500, usd: 530, cad: 670 },
        period: "",
        description: "Built for your specific needs",
        features: [
          "Custom AI agents",
          "Complete automation",
          "Dedicated support"
        ],
        cta: "Book a Call",
        popular: false,
        highlight: "✓ ROI guarantee available",
        icon: Rocket,
        isCustom: true
      }
    ],
    note: "All prices exclude local taxes (VAT/GST). Final price shown at checkout. Cancel anytime, no questions asked.",
    popular: "Most Popular"
  },
  fr: {
    badge: "Nos Forfaits",
    title: "Des Solutions Adaptées à Chaque Entreprise",
    subtitle: "Disponibles en EUR, USD et CAD",
    currencies: {
      eur: 'EUR €',
      usd: 'USD $',
      cad: 'CAD $'
    },
    monthly: 'Mensuel',
    yearly: 'Annuel',
    save: '20% d\'économie',
    monthlyPrice: '/mois',
    yearlyPrice: '/an',
    billed: 'Facturé mensuellement',
    billedYearly: 'Facturé annuellement',
    customPricing: 'Sur mesure',
    from: 'À partir de',
    plans: [
      {
        name: "Starter",
        subtitle: "Parfait pour tester l'automatisation",
        price: { eur: 49, usd: 52, cad: 69 },
        priceYearly: { eur: 470, usd: 499, cad: 662 },
        period: "/mois",
        description: "Commencez petit, voyez des résultats rapidement",
        features: [
          "1 micro-agent IA",
          "Réponses 24/7",
          "Support email"
        ],
        cta: "Démarrer L'Essai Gratuit",
        popular: false,
        highlight: "✓ Aucune carte bancaire requise",
        icon: Sparkles
      },
      {
        name: "Business",
        subtitle: "Pour équipes en croissance",
        price: { eur: 149, usd: 159, cad: 199 },
        priceYearly: { eur: 1430, usd: 1526, cad: 1910 },
        period: "/mois",
        description: "Tout ce dont vous avez besoin pour grandir plus vite",
        features: [
          "3 micro-agents IA",
          "Automatisations avancées",
          "Intégrations CRM",
          "Support prioritaire"
        ],
        cta: "Démarrer Essai 14 Jours",
        popular: true,
        highlight: "✓ Choix le plus populaire",
        icon: Zap
      },
      {
        name: "Enterprise",
        subtitle: "Solutions sur-mesure",
        priceFrom: { eur: 500, usd: 530, cad: 670 },
        period: "",
        description: "Construit pour vos besoins spécifiques",
        features: [
          "Agents IA personnalisés",
          "Automatisation complète",
          "Support dédié"
        ],
        cta: "Réserver Un Appel",
        popular: false,
        highlight: "✓ Garantie ROI disponible",
        icon: Rocket,
        isCustom: true
      }
    ],
    note: "Tous les prix excluent les taxes locales (TVA/TPS). Prix final affiché lors du paiement. Annulez à tout moment, sans questions.",
    popular: "Le Plus Populaire"
  },
  es: {
    badge: "Nuestros Planes",
    title: "Soluciones Adaptadas a Cada Empresa",
    subtitle: "Disponibles en EUR, USD y CAD",
    currencies: {
      eur: 'EUR €',
      usd: 'USD $',
      cad: 'CAD $'
    },
    monthly: 'Mensual',
    yearly: 'Anual',
    save: 'Ahorre 20%',
    monthlyPrice: '/mes',
    yearlyPrice: '/año',
    billed: 'Facturado mensualmente',
    billedYearly: 'Facturado anualmente',
    customPricing: 'Personalizado',
    from: 'Desde',
    plans: [
      {
        name: "Starter",
        subtitle: "Perfecto para probar automatización",
        price: { eur: 49, usd: 52, cad: 69 },
        priceYearly: { eur: 470, usd: 499, cad: 662 },
        period: "/mes",
        description: "Empiece pequeño, vea resultados rápido",
        features: [
          "1 micro-agente IA",
          "Respuestas 24/7",
          "Soporte por email"
        ],
        cta: "Iniciar Prueba Gratuita",
        popular: false,
        highlight: "✓ No se requiere tarjeta de crédito",
        icon: Sparkles
      },
      {
        name: "Business",
        subtitle: "Para equipos en crecimiento",
        price: { eur: 149, usd: 159, cad: 199 },
        priceYearly: { eur: 1430, usd: 1526, cad: 1910 },
        period: "/mes",
        description: "Todo lo que necesita para crecer más rápido",
        features: [
          "3 micro-agentes IA",
          "Automatizaciones avanzadas",
          "Integraciones CRM",
          "Soporte prioritario"
        ],
        cta: "Iniciar Prueba 14 Días",
        popular: true,
        highlight: "✓ Opción más popular",
        icon: Zap
      },
      {
        name: "Enterprise",
        subtitle: "Soluciones personalizadas",
        priceFrom: { eur: 500, usd: 530, cad: 670 },
        period: "",
        description: "Construido para sus necesidades específicas",
        features: [
          "Agentes IA personalizados",
          "Automatización completa",
          "Soporte dedicado"
        ],
        cta: "Reservar Una Llamada",
        popular: false,
        highlight: "✓ Garantía ROI disponible",
        icon: Rocket,
        isCustom: true
      }
    ],
    note: "Todos los precios excluyen impuestos locales (IVA/IGV). Precio final mostrado al finalizar la compra. Cancele en cualquier momento, sin preguntas.",
    popular: "Más Popular"
  },
  pt: {
    badge: "Nossos Planos",
    title: "Soluções Adaptadas a Cada Empresa",
    subtitle: "Disponíveis em EUR, USD e CAD",
    currencies: {
      eur: 'EUR €',
      usd: 'USD $',
      cad: 'CAD $'
    },
    monthly: 'Mensal',
    yearly: 'Anual',
    save: 'Economize 20%',
    monthlyPrice: '/mês',
    yearlyPrice: '/ano',
    billed: 'Cobrado mensalmente',
    billedYearly: 'Cobrado anualmente',
    customPricing: 'Personalizado',
    from: 'A partir de',
    plans: [
      {
        name: "Starter",
        subtitle: "Perfeito para testar automação",
        price: { eur: 49, usd: 52, cad: 69 },
        priceYearly: { eur: 470, usd: 499, cad: 662 },
        period: "/mês",
        description: "Comece pequeno, veja resultados rápido",
        features: [
          "1 micro-agente IA",
          "Respostas 24/7",
          "Suporte por email"
        ],
        cta: "Iniciar Teste Gratuito",
        popular: false,
        highlight: "✓ Nenhum cartão de crédito necessário",
        icon: Sparkles
      },
      {
        name: "Business",
        subtitle: "Para equipes em crescimento",
        price: { eur: 149, usd: 159, cad: 199 },
        priceYearly: { eur: 1430, usd: 1526, cad: 1910 },
        period: "/mês",
        description: "Tudo que você precisa para crescer mais rápido",
        features: [
          "3 micro-agentes IA",
          "Automatizações avançadas",
          "Integrações CRM",
          "Suporte prioritário"
        ],
        cta: "Iniciar Teste 14 Dias",
        popular: true,
        highlight: "✓ Escolha mais popular",
        icon: Zap
      },
      {
        name: "Enterprise",
        subtitle: "Soluções personalizadas",
        priceFrom: { eur: 500, usd: 530, cad: 670 },
        period: "",
        description: "Construído para suas necessidades específicas",
        features: [
          "Agentes IA personalizados",
          "Automatização completa",
          "Suporte dedicado"
        ],
        cta: "Agendar Uma Chamada",
        popular: false,
        highlight: "✓ Garantia ROI disponível",
        icon: Rocket,
        isCustom: true
      }
    ],
    note: "Todos os preços excluem impostos locais (IVA/GST). Preço final mostrado no checkout. Cancele a qualquer momento, sem perguntas.",
    popular: "Mais Popular"
  }
};

const Pricing: React.FC<PricingProps> = ({ lang = 'en' }) => {
  const [currency, setCurrency] = useState<'eur' | 'usd' | 'cad'>('eur');
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('monthly');
  const t = translations[lang];

  const getCurrencySymbol = () => {
    switch (currency) {
      case 'usd':
      case 'cad':
        return '$';
      case 'eur':
      default:
        return '€';
    }
  };

  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="pricing" className="py-24 bg-gradient-to-b from-background to-muted/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/20 rounded-full mb-4">
            <DollarSign className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">{t.badge}</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6">
            {t.title}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            {t.subtitle}
          </p>

          {/* Currency & Billing Toggle */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            {/* Currency Selector */}
            <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-1">
              {(Object.keys(t.currencies) as Array<keyof typeof t.currencies>).map((curr) => (
                <button
                  key={curr}
                  onClick={() => setCurrency(curr)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    currency === curr
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {t.currencies[curr]}
                </button>
              ))}
            </div>

            {/* Billing Toggle */}
            <div className="flex items-center gap-3 bg-muted/50 rounded-lg p-1">
              <button
                onClick={() => setBillingPeriod('monthly')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  billingPeriod === 'monthly'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {t.monthly}
              </button>
              <button
                onClick={() => setBillingPeriod('yearly')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all relative ${
                  billingPeriod === 'yearly'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {t.yearly}
                <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">
                  {t.save}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {t.plans.map((plan: any, index: number) => {
            const Icon = plan.icon;
            const isPopular = plan.popular;
            const displayPrice = billingPeriod === 'yearly' && plan.priceYearly
              ? plan.priceYearly[currency]
              : plan.price?.[currency];

            return (
              <Card
                key={index}
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl ${
                  isPopular 
                    ? 'border-primary border-2 shadow-xl scale-105' 
                    : 'border-border hover:border-primary/50'
                }`}
              >
                {isPopular && (
                  <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-4 py-1 text-xs font-bold rounded-bl-lg">
                    {t.popular}
                  </div>
                )}

                <div className="p-8">
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${
                    isPopular 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-primary/10 text-primary'
                  }`}>
                    <Icon className="w-6 h-6" />
                  </div>

                  {/* Plan Name & Subtitle */}
                  <h3 className="text-2xl font-bold font-heading mb-2">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground mb-6">{plan.subtitle}</p>

                  {/* Price */}
                  <div className="mb-6">
                    {plan.isCustom ? (
                      <div>
                        <div className="text-4xl font-bold font-heading mb-1">
                          {t.customPricing}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {t.from} {getCurrencySymbol()}{plan.priceFrom[currency]}{billingPeriod === 'monthly' ? t.monthlyPrice : t.yearlyPrice}
                        </p>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-baseline mb-1">
                          <span className="text-4xl font-bold font-heading">
                            {getCurrencySymbol()}{displayPrice}
                          </span>
                          <span className="text-muted-foreground ml-2">
                            {billingPeriod === 'monthly' ? t.monthlyPrice : t.yearlyPrice}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {billingPeriod === 'monthly' ? t.billed : t.billedYearly}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground mb-6">{plan.description}</p>

                  {/* Features */}
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Highlight */}
                  <div className="mb-6 text-xs text-primary font-medium">
                    {plan.highlight}
                  </div>

                  {/* CTA Button */}
                  <Button
                    onClick={() => window.location.href = `${baseUrl}/demo`}
                    className={`w-full font-button ${
                      isPopular
                        ? 'bg-primary hover:bg-primary/90 text-primary-foreground'
                        : 'bg-secondary hover:bg-secondary/80 text-secondary-foreground'
                    }`}
                  >
                    {plan.cta}
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Note */}
        <p className="text-center text-sm text-muted-foreground mb-12">
          {t.note}
        </p>

        {/* Help CTA Section */}
        <div className="max-w-2xl mx-auto">
          <Card className="bg-gradient-to-br from-primary/5 via-primary/3 to-background border-primary/20 p-8 text-center">
            <h3 className="text-2xl md:text-3xl font-bold font-heading mb-4">
              {lang === 'fr' ? "Besoin d'aide pour choisir ?" :
               lang === 'es' ? "¿Necesita ayuda para elegir?" :
               lang === 'pt' ? "Precisa de ajuda para escolher?" :
               "Need help choosing?"}
            </h3>
            <p className="text-muted-foreground mb-6">
              {lang === 'fr' ? "Nos experts vous aident à trouver la solution parfaite pour votre entreprise." :
               lang === 'es' ? "Nuestros expertos le ayudan a encontrar la solución perfecta para su negocio." :
               lang === 'pt' ? "Nossos especialistas ajudam você a encontrar a solução perfeita para o seu negócio." :
               "Our experts help you find the perfect solution for your business."}
            </p>
            <Button
              onClick={() => window.location.href = `${baseUrl}/demo`}
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-button"
            >
              {lang === 'fr' ? "Demander une démo" :
               lang === 'es' ? "Solicitar una demo" :
               lang === 'pt' ? "Solicitar uma demo" :
               "Request a demo"}
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Pricing;


