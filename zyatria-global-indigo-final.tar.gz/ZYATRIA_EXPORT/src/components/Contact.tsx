import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Mail, Phone, MapPin, Send, CheckCircle2, AlertCircle } from 'lucide-react';

interface ContactProps {
  lang?: string;
}

const Contact: React.FC<ContactProps> = ({ lang = 'en' }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const content: Record<string, any> = {
    en: {
      badge: 'Get in Touch',
      title: 'Let\'s Build Something ',
      titleHighlight: 'Amazing Together',
      description: 'Ready to transform your business with AI? Contact our team for a personalized consultation.',
      form: {
        name: 'Full Name',
        namePlaceholder: 'John Doe',
        email: 'Email Address',
        emailPlaceholder: 'john@company.com',
        company: 'Company Name',
        companyPlaceholder: 'Your Company',
        message: 'Message',
        messagePlaceholder: 'Tell us about your project...',
        submit: 'Send Message',
      },
      info: [
        {
          icon: Mail,
          title: 'Email',
          value: 'contact@zyatria.global',
          link: 'mailto:contact@zyatria.global',
        },
        {
          icon: Phone,
          title: 'Phone',
          value: '+1 (555) 123-4567',
          link: 'tel:+15551234567',
        },
        {
          icon: MapPin,
          title: 'Global Offices',
          value: 'North America • Europe • Africa • Latin America',
          link: null,
        },
      ],
      successMessage: 'Thank you! We\'ll get back to you soon.',
    },
    fr: {
      badge: 'Contactez-nous',
      title: 'Construisons Ensemble ',
      titleHighlight: 'Quelque Chose d\'Incroyable',
      description: 'Prêt à transformer votre entreprise avec l\'IA ? Contactez notre équipe pour une consultation personnalisée.',
      form: {
        name: 'Nom Complet',
        namePlaceholder: 'Jean Dupont',
        email: 'Adresse Email',
        emailPlaceholder: 'jean@entreprise.com',
        company: 'Nom de l\'Entreprise',
        companyPlaceholder: 'Votre Entreprise',
        message: 'Message',
        messagePlaceholder: 'Parlez-nous de votre projet...',
        submit: 'Envoyer le Message',
      },
      info: [
        {
          icon: Mail,
          title: 'Email',
          value: 'contact@zyatria.global',
          link: 'mailto:contact@zyatria.global',
        },
        {
          icon: Phone,
          title: 'Téléphone',
          value: '+1 (555) 123-4567',
          link: 'tel:+15551234567',
        },
        {
          icon: MapPin,
          title: 'Bureaux Mondiaux',
          value: 'Amérique du Nord • Europe • Afrique • Amérique Latine',
          link: null,
        },
      ],
      successMessage: 'Merci ! Nous vous répondrons bientôt.',
    },
    es: {
      badge: 'Póngase en Contacto',
      title: 'Construyamos Juntos ',
      titleHighlight: 'Algo Increíble',
      description: '¿Listo para transformar su negocio con IA? Contacte a nuestro equipo para una consulta personalizada.',
      form: {
        name: 'Nombre Completo',
        namePlaceholder: 'Juan Pérez',
        email: 'Correo Electrónico',
        emailPlaceholder: 'juan@empresa.com',
        company: 'Nombre de la Empresa',
        companyPlaceholder: 'Su Empresa',
        message: 'Mensaje',
        messagePlaceholder: 'Cuéntenos sobre su proyecto...',
        submit: 'Enviar Mensaje',
      },
      info: [
        {
          icon: Mail,
          title: 'Email',
          value: 'contact@zyatria.global',
          link: 'mailto:contact@zyatria.global',
        },
        {
          icon: Phone,
          title: 'Teléfono',
          value: '+1 (555) 123-4567',
          link: 'tel:+15551234567',
        },
        {
          icon: MapPin,
          title: 'Oficinas Globales',
          value: 'América del Norte • Europa • África • América Latina',
          link: null,
        },
      ],
      successMessage: '¡Gracias! Nos pondremos en contacto pronto.',
    },
    pt: {
      badge: 'Entre em Contato',
      title: 'Vamos Construir Juntos ',
      titleHighlight: 'Algo Incrível',
      description: 'Pronto para transformar seu negócio com IA? Entre em contato com nossa equipe para uma consulta personalizada.',
      form: {
        name: 'Nome Completo',
        namePlaceholder: 'João Silva',
        email: 'Endereço de Email',
        emailPlaceholder: 'joao@empresa.com',
        company: 'Nome da Empresa',
        companyPlaceholder: 'Sua Empresa',
        message: 'Mensagem',
        messagePlaceholder: 'Conte-nos sobre seu projeto...',
        submit: 'Enviar Mensagem',
      },
      info: [
        {
          icon: Mail,
          title: 'Email',
          value: 'contact@zyatria.global',
          link: 'mailto:contact@zyatria.global',
        },
        {
          icon: Phone,
          title: 'Telefone',
          value: '+1 (555) 123-4567',
          link: 'tel:+15551234567',
        },
        {
          icon: MapPin,
          title: 'Escritórios Globais',
          value: 'América do Norte • Europa • África • América Latina',
          link: null,
        },
      ],
      successMessage: 'Obrigado! Entraremos em contato em breve.',
    },
  };

  const t = content[lang];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      // 🔧 REMPLACEZ 'YOUR_FORM_ID' par votre Form ID Formspree
      // Exemple: Si votre URL est https://formspree.io/f/mzbnwxyz
      // Alors YOUR_FORM_ID = mzbnwxyz
      const response = await fetch('https://formspree.io/f/YOUR_FORM_ID', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          company: formData.company,
          message: formData.message,
          language: lang, // Track which language the user is using
          _subject: `[ZyatrIA] Nouvelle demande de ${formData.name}`,
        }),
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({ name: '', email: '', company: '', message: '' });
        
        // Auto-hide success message after 5 seconds
        setTimeout(() => {
          setSubmitStatus('idle');
        }, 5000);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-primary/10 border border-primary/20 rounded-full mb-4">
            <span className="text-sm font-medium text-primary">{t.badge}</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold font-heading mb-6">
            {t.title}
            <span className="bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              {t.titleHighlight}
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {t.description}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="p-8 border-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Success Message */}
              {submitStatus === 'success' && (
                <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0" />
                  <p className="text-sm text-green-800 dark:text-green-200">{t.successMessage}</p>
                </div>
              )}

              {/* Error Message */}
              {submitStatus === 'error' && (
                <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0" />
                  <p className="text-sm text-red-800 dark:text-red-200">
                    {lang === 'fr' ? 'Une erreur est survenue. Veuillez réessayer.' :
                     lang === 'es' ? 'Ocurrió un error. Por favor, inténtelo de nuevo.' :
                     lang === 'pt' ? 'Ocorreu um erro. Por favor, tente novamente.' :
                     'An error occurred. Please try again.'}
                  </p>
                </div>
              )}

              <div>
                <Label htmlFor="name">{t.form.name}</Label>
                <Input
                  id="name"
                  name="name"
                  type="text"
                  placeholder={t.form.namePlaceholder}
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="mt-2"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="email">{t.form.email}</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder={t.form.emailPlaceholder}
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="mt-2"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="company">{t.form.company}</Label>
                <Input
                  id="company"
                  name="company"
                  type="text"
                  placeholder={t.form.companyPlaceholder}
                  value={formData.company}
                  onChange={handleChange}
                  className="mt-2"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="message">{t.form.message}</Label>
                <Textarea
                  id="message"
                  name="message"
                  placeholder={t.form.messagePlaceholder}
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="mt-2"
                  disabled={isSubmitting}
                />
              </div>

              <Button type="submit" size="lg" className="w-full group" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <span className="mr-2">
                      {lang === 'fr' ? 'Envoi en cours...' :
                       lang === 'es' ? 'Enviando...' :
                       lang === 'pt' ? 'Enviando...' :
                       'Sending...'}
                    </span>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  </>
                ) : (
                  <>
                    {t.form.submit}
                    <Send className="ml-2 w-4 h-4 group-hover:translate-x-1 transition" />
                  </>
                )}
              </Button>
            </form>
          </Card>

          {/* Contact Info */}
          <div className="space-y-8">
            {t.info.map((item: any, index: number) => {
              const Icon = item.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">{item.title}</h3>
                      {item.link ? (
                        <a
                          href={item.link}
                          className="text-muted-foreground hover:text-primary transition"
                        >
                          {item.value}
                        </a>
                      ) : (
                        <p className="text-muted-foreground">{item.value}</p>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })}

            {/* Map Placeholder */}
            <Card className="p-6 bg-gradient-to-br from-primary/5 to-purple-500/5 border-2 border-primary/20">
              <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-primary mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Global Presence</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;

