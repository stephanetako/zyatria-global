





import React from 'react';
import { Button } from './ui/button';
import { ArrowRight, Sparkles, Zap, Globe2 } from 'lucide-react';
import { baseUrl } from '../lib/base-url';

const translations = {
  en: {
    badge: "Global AI Agency",
    canadianBadge: "🇨🇦 Canadian Company from Quebec",
    title: {
      line1: "Transform Your Business",
      line2: "With Intelligent Automation",
      highlight: "In Days, Not Months"
    },
    subtitle: "Specialized solutions that work 24/7 to grow your business. Deploy in 10-15 days. Results from day one.",
    cta: {
      primary: "See How It Works",
      secondary: "Book a Free Demo"
    },
    stats: [
      { value: "50+", label: "Growing Companies" },
      { value: "10-15", label: "Days to Launch" },
      { value: "+42%", label: "Customer Satisfaction" },
      { value: "24/7", label: "Always Available" }
    ]
  },
  fr: {
    badge: "Agence IA Internationale",
    canadianBadge: "🇨🇦 Entreprise Canadienne du Québec",
    title: {
      line1: "Transformez Votre Entreprise",
      line2: "Avec L'Automatisation Intelligente",
      highlight: "En Jours, Pas En Mois"
    },
    subtitle: "Des solutions spécialisées qui travaillent 24/7 pour faire grandir votre entreprise. Déploiement en 10-15 jours. Résultats dès le premier jour.",
    cta: {
      primary: "Voir Comment Ça Marche",
      secondary: "Réserver Une Démo Gratuite"
    },
    stats: [
      { value: "50+", label: "Entreprises En Croissance" },
      { value: "10-15", label: "Jours Pour Lancer" },
      { value: "+42%", label: "Satisfaction Client" },
      { value: "24/7", label: "Toujours Disponible" }
    ]
  },
  es: {
    badge: "Agencia IA Internacional",
    canadianBadge: "🇨🇦 Empresa Canadiense de Quebec",
    title: {
      line1: "Transforme Su Negocio",
      line2: "Con Automatización Inteligente",
      highlight: "En Días, No En Meses"
    },
    subtitle: "Soluciones especializadas que trabajan 24/7 para hacer crecer su negocio. Implementación en 10-15 días. Resultados desde el primer día.",
    cta: {
      primary: "Ver Cómo Funciona",
      secondary: "Reservar Una Demo Gratuita"
    },
    stats: [
      { value: "50+", label: "Empresas En Crecimiento" },
      { value: "10-15", label: "Días Para Lanzar" },
      { value: "+42%", label: "Satisfacción Del Cliente" },
      { value: "24/7", label: "Siempre Disponible" }
    ]
  },
  pt: {
    badge: "Agência IA Internacional",
    canadianBadge: "🇨🇦 Empresa Canadense de Quebec",
    title: {
      line1: "Transforme Seu Negócio",
      line2: "Com Automação Inteligente",
      highlight: "Em Dias, Não Em Meses"
    },
    subtitle: "Soluções especializadas que trabalham 24/7 para fazer crescer seu negócio. Implementação em 10-15 dias. Resultados desde o primeiro dia.",
    cta: {
      primary: "Ver Como Funciona",
      secondary: "Agendar Uma Demo Gratuita"
    },
    stats: [
      { value: "50+", label: "Empresas Em Crescimento" },
      { value: "10-15", label: "Dias Para Lançar" },
      { value: "+42%", label: "Satisfação Do Cliente" },
      { value: "24/7", label: "Sempre Disponível" }
    ]
  }
};

interface HeroProps {
  lang?: string;
}

const Hero: React.FC<HeroProps> = ({ lang = 'en' }) => {
  const content: Record<string, any> = {
    en: {
      badge: 'AI without borders',
      title: 'Intelligent AI Agents for a ',
      titleHighlight: 'Borderless World',
      description: 'Transform your business with advanced AI automation, intelligent agents, and specialized micro-agents. Global solutions for modern enterprises.',
      cta1: 'Request a Demo',
      cta2: 'Explore Solutions',
      stats: [
        { value: '150+', label: 'Active Projects' },
        { value: '40+', label: 'Countries Served' },
        { value: '98%', label: 'Client Satisfaction' },
      ],
    },
    fr: {
      badge: 'IA sans frontières',
      title: 'Agents IA Intelligents pour un ',
      titleHighlight: 'Monde Sans Frontières',
      description: 'Transformez votre entreprise avec l\'automatisation IA avancée, des agents intelligents et des micro-agents spécialisés. Solutions mondiales pour entreprises modernes.',
      cta1: 'Demander une démo',
      cta2: 'Découvrir les solutions',
      stats: [
        { value: '150+', label: 'Projets actifs' },
        { value: '40+', label: 'Pays desservis' },
        { value: '98%', label: 'Satisfaction client' },
      ],
    },
    es: {
      badge: 'IA sin fronteras',
      title: 'Agentes de IA Inteligentes para un ',
      titleHighlight: 'Mundo Sin Fronteras',
      description: 'Transforme su negocio con automatización IA avanzada, agentes inteligentes y micro-agentes especializados. Soluciones globales para empresas modernas.',
      cta1: 'Solicitar una demo',
      cta2: 'Explorar soluciones',
      stats: [
        { value: '150+', label: 'Proyectos activos' },
        { value: '40+', label: 'Países atendidos' },
        { value: '98%', label: 'Satisfacción del cliente' },
      ],
    },
    pt: {
      badge: 'IA sem fronteiras',
      title: 'Agentes de IA Inteligentes para um ',
      titleHighlight: 'Mundo Sem Fronteiras',
      description: 'Transforme seu negócio com automação IA avançada, agentes inteligentes e micro-agentes especializados. Soluções globais para empresas modernas.',
      cta1: 'Solicitar uma demo',
      cta2: 'Explorar soluções',
      stats: [
        { value: '150+', label: 'Projetos ativos' },
        { value: '40+', label: 'Países atendidos' },
        { value: '98%', label: 'Satisfação do cliente' },
      ],
    },
  };

  const t = content[lang];

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-background via-muted/20 to-primary/5">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Colorful Gradient Orbs */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-primary opacity-30 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-accent opacity-25 rounded-full blur-3xl animate-float delay-1000" />
        <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-gradient-sunset opacity-20 rounded-full blur-3xl animate-float delay-500" />
        <div className="absolute bottom-1/3 left-1/4 w-80 h-80 bg-gradient-ocean opacity-20 rounded-full blur-3xl animate-float delay-300" />
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,102,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,102,255,0.03)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_80%)]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/20 rounded-full mb-8 animate-fade-in">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">{t.badge}</span>
        </div>

        {/* Main Title */}
        <h1 className="text-5xl md:text-7xl font-bold font-heading mb-6 animate-fade-in-up">
          {t.title}
          <br />
          <span className="bg-gradient-to-r from-primary via-purple-600 to-blue-600 bg-clip-text text-transparent">
            {t.titleHighlight}
          </span>
        </h1>

        {/* Description */}
        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12 animate-fade-in-up delay-200">
          {t.description}
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-20 animate-fade-in-up delay-300">
          <Button 
            size="lg" 
            className="text-lg px-8 py-6 group"
            onClick={() => window.location.href = `${baseUrl}/demo`}
          >
            {t.cta1}
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition" />
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="text-lg px-8 py-6"
            onClick={() => window.location.href = `${baseUrl}/services`}
          >
            {t.cta2}
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto animate-fade-in-up delay-400">
          {t.stats.map((stat: any, index: number) => (
            <div key={index} className="p-6 bg-card border border-border rounded-lg backdrop-blur-sm hover:shadow-lg transition-all duration-300">
              <div className="text-4xl font-bold text-primary mb-2">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Floating Icons */}
      <div className="absolute top-1/4 left-1/4 animate-float hidden lg:block">
        <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center backdrop-blur-sm">
          <Zap className="w-6 h-6 text-primary" />
        </div>
      </div>
      <div className="absolute bottom-1/3 right-1/4 animate-float delay-500 hidden lg:block">
        <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center backdrop-blur-sm">
          <Globe2 className="w-6 h-6 text-purple-500" />
        </div>
      </div>
    </section>
  );
};

export default Hero;









