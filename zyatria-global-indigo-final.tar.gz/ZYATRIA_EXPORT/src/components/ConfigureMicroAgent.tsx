import React, { useState } from 'react';
import { Sparkles, ArrowRight, CheckCircle2, Zap, Clock, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface ConfigureMicroAgentProps {
  lang?: string;
}

const translations = {
  en: {
    badge: "Ready to Start",
    title: "Configure Your Micro-Agent",
    subtitle: "Choose your micro-agent, we configure it, you see results in 7 days",
    benefits: [
      {
        icon: Clock,
        title: "Deployed in 7 Days",
        description: "From first contact to deployment, only one week"
      },
      {
        icon: Zap,
        title: "Immediate Results",
        description: "See concrete improvements from day one"
      },
      {
        icon: Shield,
        title: "Risk-Free",
        description: "30-day money-back guarantee"
      }
    ],
    cta: {
      primary: "Configure My Micro-Agent",
      secondary: "Or book a free 30-minute consultation"
    },
    trust: {
      title: "What You Get:",
      items: [
        "Free 30-minute consultation",
        "Custom configuration",
        "Team training",
        "Ongoing support",
        "Performance monitoring",
        "Continuous optimization"
      ]
    }
  },
  fr: {
    badge: "Prêt à Démarrer",
    title: "Configurez Votre Micro-Agent",
    subtitle: "Choisissez votre micro-agent, nous le configurons, vous voyez des résultats en 7 jours",
    benefits: [
      {
        icon: Clock,
        title: "Déployé en 7 Jours",
        description: "Du premier contact au déploiement, une seule semaine"
      },
      {
        icon: Zap,
        title: "Résultats Immédiats",
        description: "Voyez des améliorations concrètes dès le premier jour"
      },
      {
        icon: Shield,
        title: "Sans Risque",
        description: "Garantie satisfait ou remboursé 30 jours"
      }
    ],
    cta: {
      primary: "Configurer Mon Micro-Agent",
      secondary: "Ou réserver une consultation gratuite de 30 minutes"
    },
    trust: {
      title: "Ce Que Vous Obtenez :",
      items: [
        "Consultation gratuite de 30 minutes",
        "Configuration personnalisée",
        "Formation de votre équipe",
        "Support continu",
        "Surveillance des performances",
        "Optimisation continue"
      ]
    }
  },
  es: {
    badge: "Listo Para Empezar",
    title: "Configure Su Micro-Agente",
    subtitle: "Elija su micro-agente, lo configuramos, ve resultados en 7 días",
    benefits: [
      {
        icon: Clock,
        title: "Desplegado en 7 Días",
        description: "Del primer contacto al despliegue, solo una semana"
      },
      {
        icon: Zap,
        title: "Resultados Inmediatos",
        description: "Vea mejoras concretas desde el primer día"
      },
      {
        icon: Shield,
        title: "Sin Riesgo",
        description: "Garantía de devolución de dinero de 30 días"
      }
    ],
    cta: {
      primary: "Configurar Mi Micro-Agente",
      secondary: "O reservar una consulta gratuita de 30 minutos"
    },
    trust: {
      title: "Lo Que Obtiene:",
      items: [
        "Consulta gratuita de 30 minutos",
        "Configuración personalizada",
        "Formación de su equipo",
        "Soporte continuo",
        "Monitoreo de rendimiento",
        "Optimización continua"
      ]
    }
  },
  pt: {
    badge: "Pronto Para Começar",
    title: "Configure Seu Micro-Agente",
    subtitle: "Escolha seu micro-agente, configuramos, você vê resultados em 7 dias",
    benefits: [
      {
        icon: Clock,
        title: "Implementado em 7 Dias",
        description: "Do primeiro contato ao deployment, apenas uma semana"
      },
      {
        icon: Zap,
        title: "Resultados Imediatos",
        description: "Veja melhorias concretas desde o primeiro dia"
      },
      {
        icon: Shield,
        title: "Sem Risco",
        description: "Garantia de devolução do dinheiro em 30 dias"
      }
    ],
    cta: {
      primary: "Configurar Meu Micro-Agente",
      secondary: "Ou agendar uma consulta gratuita de 30 minutos"
    },
    trust: {
      title: "O Que Você Obtém:",
      items: [
        "Consulta gratuita de 30 minutos",
        "Configuração personalizada",
        "Treinamento da sua equipe",
        "Suporte contínuo",
        "Monitoramento de desempenho",
        "Otimização contínua"
      ]
    }
  }
};

const ConfigureMicroAgent: React.FC<ConfigureMicroAgentProps> = ({ lang = 'en' }) => {
  const t = translations[lang as keyof typeof translations];
  const [isHovered, setIsHovered] = useState(false);

  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="configure-micro-agent" className="py-24 bg-gradient-to-br from-primary/5 via-background to-primary/5 relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <div className="inline-block px-4 py-2 bg-primary border border-primary/20 rounded-full mb-4 shadow-lg">
            <span className="text-sm font-semibold text-primary-foreground flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              {t.badge}
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading mb-6">
            {t.title}
          </h2>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
            {t.subtitle}
          </p>
        </div>

        {/* Benefits Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {t.benefits.map((benefit: any, index: number) => {
            const Icon = benefit.icon;
            const delays = ['delay-200', 'delay-300', 'delay-400'];
            const gradients = [
              'from-blue-500 to-cyan-500',
              'from-purple-500 to-pink-500',
              'from-orange-500 to-yellow-500'
            ];

            return (
              <Card 
                key={index} 
                className={`p-8 text-center hover:shadow-2xl transition-all duration-500 group border-2 hover:border-primary/40 bg-card/80 backdrop-blur-sm animate-fade-in-up ${delays[index]}`}
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${gradients[index]} rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 mx-auto`}>
                  <Icon className="w-8 h-8 text-white" strokeWidth={2.5} />
                </div>
                <h3 className="text-xl font-bold font-heading mb-3 group-hover:text-primary transition-colors">
                  {benefit.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {benefit.description}
                </p>
              </Card>
            );
          })}
        </div>

        {/* Main CTA Card */}
        <div className="max-w-4xl mx-auto animate-fade-in-up delay-500">
          <Card className="p-12 bg-gradient-to-br from-card via-card/95 to-primary/5 border-2 border-primary/20 shadow-2xl">
            <div className="grid md:grid-cols-2 gap-12">
              {/* Left: CTA */}
              <div className="flex flex-col justify-center">
                <Button 
                  size="lg" 
                  onClick={scrollToContact}
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                  className="w-full text-lg py-8 group shadow-xl hover:shadow-2xl mb-6 bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary"
                >
                  <Sparkles className={`mr-2 w-6 h-6 ${isHovered ? 'animate-spin' : ''}`} />
                  {t.cta.primary}
                  <ArrowRight className="ml-2 w-6 h-6 group-hover:translate-x-2 transition-transform" />
                </Button>
                
                <p className="text-center text-muted-foreground">
                  {t.cta.secondary}
                </p>
              </div>

              {/* Right: Trust Elements */}
              <div>
                <h3 className="text-xl font-bold font-heading mb-6 flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6 text-primary" />
                  {t.trust.title}
                </h3>
                <ul className="space-y-4">
                  {t.trust.items.map((item: string, index: number) => (
                    <li key={index} className="flex items-start gap-3 group/item">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5 group-hover/item:scale-125 transition-transform" />
                      <span className="leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Trust Badge */}
            <div className="mt-8 pt-8 border-t border-border/50 flex items-center justify-center gap-8 flex-wrap">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4 text-primary" />
                <span>7 jours maximum</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="w-4 h-4 text-primary" />
                <span>30 jours garantie</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Zap className="w-4 h-4 text-primary" />
                <span>Résultats immédiats</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Social Proof */}
        <div className="text-center mt-12 animate-fade-in-up delay-1000">
          <p className="text-muted-foreground text-lg">
            ⭐⭐⭐⭐⭐ <span className="font-semibold">4.9/5</span> sur 200+ clients
          </p>
        </div>
      </div>
    </section>
  );
};

export default ConfigureMicroAgent;
