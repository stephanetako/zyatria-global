# 📚 GUIDE D'INSTALLATION - ZYATRIA GLOBAL

## 🎯 OBJECTIF
Installer et lancer une copie complète du site ZyatrIA Global sur votre machine.

---

## ⚙️ PRÉ-REQUIS

Avant de commencer, assurez-vous d'avoir installé :

### 1. Node.js (v18 ou supérieur)
```bash
# Vérifier votre version
node --version
# Doit afficher : v18.x.x ou supérieur
```

**Installation :** https://nodejs.org

### 2. npm (inclus avec Node.js)
```bash
npm --version
# Doit afficher : 9.x.x ou supérieur
```

### 3. Git (optionnel mais recommandé)
```bash
git --version
```

**Installation :** https://git-scm.com

---

## 🚀 INSTALLATION MÉTHODE 1 : NOUVEAU PROJET

### Étape 1 : Extraire le Package

```bash
# Si vous avez un fichier ZIP
unzip ZYATRIA_EXPORT.zip

# Aller dans le dossier
cd ZYATRIA_EXPORT
```

### Étape 2 : Installer les Dépendances

```bash
npm install
```

**Durée estimée :** 2-5 minutes

### Étape 3 : Configuration (Optionnel)

```bash
# Copier le fichier d'exemple
cp .env.example .env

# Éditez .env si nécessaire (pour Formspree, Analytics, etc.)
```

### Étape 4 : Lancer le Serveur de Développement

```bash
npm run dev
```

### Étape 5 : Ouvrir dans le Navigateur

Le site est maintenant accessible sur :
```
http://localhost:3000
```

---

## 🔄 INSTALLATION MÉTHODE 2 : CLONER DEPUIS GITHUB

Si le site est hébergé sur GitHub :

```bash
# Cloner le repository
git clone https://github.com/votre-username/zyatria-global.git

# Aller dans le dossier
cd zyatria-global

# Installer les dépendances
npm install

# Lancer le serveur
npm run dev
```

---

## 📁 STRUCTURE DU PROJET

```
ZYATRIA_EXPORT/
├── src/
│   ├── components/       # Composants React
│   │   ├── Navigation.tsx
│   │   ├── Hero.tsx
│   │   ├── Services.tsx
│   │   └── ... (24 composants)
│   ├── pages/           # Pages Astro
│   │   ├── index.astro  # Page d'accueil
│   │   ├── about.astro
│   │   ├── services.astro
│   │   └── ...
│   ├── layouts/         # Layouts Astro
│   │   └── main.astro
│   ├── styles/          # Styles CSS
│   │   ├── global.css
│   │   ├── animations.css
│   │   └── color-override.css
│   └── lib/             # Utilitaires
│       └── utils.ts
├── public/              # Assets statiques
│   ├── favicon.svg
│   ├── robots.txt
│   └── sitemap.xml
├── generated/           # Fichiers générés Webflow
│   ├── fonts.css
│   └── webflow.css
├── package.json         # Dépendances npm
├── astro.config.mjs     # Configuration Astro
├── tsconfig.json        # Configuration TypeScript
└── wrangler.jsonc       # Configuration Cloudflare
```

---

## 🎨 PERSONNALISATION

### Changer les Couleurs

**Fichier :** `src/styles/color-override.css`

```css
:root {
  --primary: #C98769;        /* Couleur principale */
  --background: #F5F1EB;     /* Fond */
  --foreground: #373D36;     /* Texte */
}
```

### Modifier les Textes

Tous les textes sont dans les composants :
- `src/components/Hero.tsx` - Section Hero
- `src/components/Services.tsx` - Services
- `src/components/About.tsx` - À propos
- etc.

### Ajouter une Nouvelle Page

1. Créer un fichier dans `src/pages/` :
```astro
<!-- src/pages/nouvelle-page.astro -->
---
import MainLayout from '../layouts/main.astro';
---

<MainLayout title="Nouvelle Page">
  <h1>Ma Nouvelle Page</h1>
</MainLayout>
```

2. Ajouter le lien dans la navigation :
```typescript
// src/components/Navigation.tsx
{ label: "Nouvelle Page", href: "/nouvelle-page" }
```

### Configurer Formspree (Formulaires de Contact)

1. Créez un compte gratuit sur https://formspree.io
2. Créez un nouveau formulaire
3. Copiez votre Form ID
4. Dans `src/components/Contact.tsx`, remplacez :
```typescript
action="https://formspree.io/f/YOUR_FORM_ID"
```

---

## 🌍 MULTILINGUE

Le site supporte 4 langues par défaut :
- 🇬🇧 English
- 🇫🇷 Français
- 🇪🇸 Español
- 🇵🇹 Português

### Ajouter une Nouvelle Langue

1. Dans chaque composant, ajoutez les traductions :
```typescript
const translations = {
  en: { title: "Services" },
  fr: { title: "Services" },
  es: { title: "Servicios" },
  pt: { title: "Serviços" },
  de: { title: "Dienstleistungen" } // Nouveau !
};
```

2. Ajoutez le bouton dans la navigation

---

## 🚀 DÉPLOIEMENT EN PRODUCTION

### Option 1 : Cloudflare Pages (Recommandé - GRATUIT)

```bash
# 1. Créer un compte Cloudflare (gratuit)
# https://dash.cloudflare.com/sign-up

# 2. Installer Wrangler
npm install -g wrangler

# 3. Authentification
wrangler login

# 4. Build du projet
npm run build

# 5. Déployer
npx wrangler pages deploy dist

# Votre site sera accessible sur :
# https://zyatria-global.pages.dev
```

**Avantages :**
- ✅ Gratuit illimité
- ✅ CDN mondial ultra-rapide
- ✅ SSL automatique
- ✅ Déploiements instantanés

### Option 2 : Vercel (Gratuit)

```bash
# 1. Installer Vercel CLI
npm install -g vercel

# 2. Authentification
vercel login

# 3. Déployer
vercel deploy

# Suivez les instructions
```

### Option 3 : Netlify (Gratuit)

```bash
# 1. Installer Netlify CLI
npm install -g netlify-cli

# 2. Authentification
netlify login

# 3. Build
npm run build

# 4. Déployer
netlify deploy --prod
```

### Option 4 : Hébergement Traditionnel (cPanel, etc.)

```bash
# 1. Build du site
npm run build

# 2. Uploader le dossier dist/ via FTP
# Le dossier dist/ contient tout le site statique
```

---

## 🔧 COMMANDES DISPONIBLES

```bash
# Développement (avec hot-reload)
npm run dev

# Build pour production
npm run build

# Preview du build
npm run preview

# Vérification TypeScript
npm run astro check

# Générer types Cloudflare
npm run cf-typegen
```

---

## 🐛 RÉSOLUTION DE PROBLÈMES

### Erreur : "Port 3000 already in use"

```bash
# Tuer le processus sur le port 3000
npm run predev

# Ou manuellement
npx kill-port 3000

# Puis relancer
npm run dev
```

### Erreur : "Module not found"

```bash
# Supprimer node_modules et réinstaller
rm -rf node_modules
npm install
```

### Erreur : "TypeScript errors"

```bash
# Vérifier les erreurs
npm run astro check

# Si trop d'erreurs, vous pouvez temporairement désactiver
# la vérification stricte dans tsconfig.json
```

### Le site ne s'affiche pas correctement

1. Vérifiez que toutes les dépendances sont installées
2. Vérifiez la console du navigateur (F12)
3. Essayez un build propre :
```bash
rm -rf dist node_modules
npm install
npm run build
npm run preview
```

### Problèmes de styles CSS

1. Vérifiez que `generated/webflow.css` existe
2. Vérifiez que `src/styles/global.css` est importé
3. Essayez de vider le cache du navigateur (Ctrl+Shift+R)

---

## 📊 OPTIMISATION PERFORMANCE

### Images

1. Utilisez des formats modernes : WebP ou AVIF
2. Compressez avec TinyPNG : https://tinypng.com
3. Utilisez des tailles appropriées (pas trop grandes)

### Fonts

Les polices sont déjà optimisées dans `generated/fonts.css`

### CSS

Le CSS est déjà minifié lors du build

### JavaScript

React est déjà optimisé avec code-splitting

---

## 🔒 SÉCURITÉ

### Variables d'Environnement

**IMPORTANT :** Ne jamais commiter le fichier `.env` sur Git !

Le fichier `.gitignore` inclut déjà :
```
.env
.env.local
```

### API Keys

- Ne jamais exposer vos clés API dans le code client
- Utilisez toujours des variables d'environnement
- Pour Formspree, c'est sécurisé (form ID public OK)

---

## 📈 ANALYTICS

### Ajouter Google Analytics

1. Créez une propriété GA4 : https://analytics.google.com
2. Copiez votre Measurement ID (G-XXXXXXXXXX)
3. Ajoutez dans `src/layouts/main.astro` avant `</head>` :

```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

---

## 📞 SUPPORT & RESSOURCES

### Documentation Officielle
- **Astro :** https://docs.astro.build
- **React :** https://react.dev
- **Tailwind CSS :** https://tailwindcss.com
- **ShadCN UI :** https://ui.shadcn.com

### Communautés
- **Astro Discord :** https://astro.build/chat
- **Stack Overflow :** Tag `astro`

### Tutoriels
- **Astro Tutorial :** https://docs.astro.build/en/tutorial/0-introduction/
- **YouTube :** Recherchez "Astro tutorial"

---

## ✅ CHECKLIST DE VÉRIFICATION

Après l'installation, vérifiez :

### Fonctionnalités de Base
- [ ] Le site se lance avec `npm run dev`
- [ ] Page d'accueil s'affiche correctement
- [ ] Navigation fonctionne
- [ ] Toutes les pages sont accessibles
- [ ] Responsive (testez sur mobile)

### Contenu
- [ ] Tous les textes s'affichent
- [ ] Les images se chargent
- [ ] Les icônes apparaissent
- [ ] Les animations fonctionnent

### Interactions
- [ ] Les liens fonctionnent
- [ ] Les boutons sont cliquables
- [ ] Le formulaire de contact fonctionne
- [ ] Le sélecteur de langue fonctionne

### Performance
- [ ] Page se charge rapidement
- [ ] Pas d'erreurs dans la console
- [ ] Score Lighthouse > 90

### Avant Production
- [ ] Build réussit (`npm run build`)
- [ ] Preview fonctionne (`npm run preview`)
- [ ] SEO configuré (meta tags)
- [ ] Favicon présent
- [ ] robots.txt configuré
- [ ] Formspree configuré avec votre ID

---

## 🎉 FÉLICITATIONS !

Votre site ZyatrIA Global est maintenant installé et fonctionnel !

**Prochaines étapes suggérées :**
1. Personnalisez le contenu
2. Configurez Formspree
3. Ajoutez votre domaine
4. Déployez en production
5. Ajoutez Google Analytics

---

## 💡 CONSEILS PRO

### Développement
- Utilisez VS Code avec extensions : Astro, Tailwind CSS IntelliSense
- Activez le format automatique (Prettier)
- Utilisez Git pour versionner votre code

### Performance
- Testez avec Lighthouse (F12 → Lighthouse)
- Visez 90+ sur tous les scores
- Optimisez les images avant de les ajouter

### SEO
- Mettez à jour les meta tags pour chaque page
- Créez un sitemap.xml (déjà inclus)
- Soumettez à Google Search Console

### Maintenance
- Mettez à jour régulièrement les dépendances :
```bash
npm update
```
- Testez après chaque mise à jour
- Faites des backups réguliers

---

**Document créé le :** 2026-02-06  
**Version :** 1.0 Complete  
**Support :** Documentation complète incluse

**Bon développement ! 🚀**
