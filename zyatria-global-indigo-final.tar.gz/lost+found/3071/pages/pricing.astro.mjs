globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Dvgu_8ko.mjs';
import { $ as $$Main, N as Navigation } from '../chunks/Navigation_Dw81bWF4.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_F_-x8amX.mjs';

const $$Pricing = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Tarifs Agents IA | Plans Starter, Business & Enterprise | \xC0 partir de 49\u20AC/mois | ZyatrIA",
    description: "D\xE9couvrez nos forfaits d'agents IA : Starter \xE0 49\u20AC/mois (1 micro-agent), Business \xE0 149\u20AC/mois (3 micro-agents + automatisations), Enterprise sur-mesure. Support multilingue, d\xE9ploiement en 7-15 jours. Tarification transparente en EUR, USD, CAD.",
    ogImage: "/og-image-pricing.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "PricingPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/PricingPage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/pricing.astro", void 0);

const $$file = "/app/src/pages/pricing.astro";
const $$url = "/pricing";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Pricing,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
