globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Dvgu_8ko.mjs';
import { $ as $$Main, N as Navigation } from '../chunks/Navigation_Dw81bWF4.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_F_-x8amX.mjs';

const $$Docs = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Documentation Technique | API & Int\xE9grations Agents IA | ZyatrIA Global",
    description: "Documentation technique compl\xE8te pour nos agents IA : r\xE9f\xE9rences API, webhooks, int\xE9grations CRM, exemples de code, guides d'impl\xE9mentation. Support d\xE9veloppeurs pour int\xE9grer nos micro-agents dans vos syst\xE8mes existants.",
    ogImage: "/og-image-docs.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "TechnicalDocsPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/TechnicalDocsPage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/docs.astro", void 0);

const $$file = "/app/src/pages/docs.astro";
const $$url = "/docs";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Docs,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
