globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Dvgu_8ko.mjs';
import { $ as $$Main, N as Navigation } from '../chunks/Navigation_Dw81bWF4.mjs';
export { r as renderers } from '../chunks/_@astro-renderers_F_-x8amX.mjs';

const $$Demo = createComponent(($$result, $$props, $$slots) => {
  const seoData = {
    title: "Demander une D\xE9mo Gratuite | Testez nos Agents IA | Contact ZyatrIA Global",
    description: "R\xE9servez votre d\xE9monstration gratuite et d\xE9couvrez comment nos agents IA peuvent transformer votre entreprise. R\xE9ponse en moins de 24h. Support multilingue disponible en fran\xE7ais, anglais, espagnol et portugais. D\xE9ploiement rapide en 7-15 jours.",
    ogImage: "/og-image-demo.jpg"};
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, { "title": seoData.title, "description": seoData.description, "ogImage": seoData.ogImage }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="relative"> ${renderComponent($$result2, "Navigation", Navigation, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/app/src/components/Navigation", "client:component-export": "default" })} ${renderComponent($$result2, "DemoPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/pages/DemoPage", "client:component-export": "default" })} ${renderComponent($$result2, "Footer", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/Footer", "client:component-export": "default" })} </div> ` })}`;
}, "/app/src/pages/demo.astro", void 0);

const $$file = "/app/src/pages/demo.astro";
const $$url = "/demo";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Demo,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
