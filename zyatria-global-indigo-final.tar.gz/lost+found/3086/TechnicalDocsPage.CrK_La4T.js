import{j as e}from"./jsx-runtime.D_zvdyIk.js";import{r as x}from"./index.0yr9KlQE.js";import{B as v}from"./button.DpnewnIZ.js";import{C as p}from"./card.BpUvcUWY.js";import{B as A}from"./badge.CVuZjkzJ.js";import{d as B,e as q,a as G,c as _}from"./index.o8Dgbvr_.js";import{a as L,c as k,R as $,I as U,P as F}from"./index.R_unBCod.js";import{P as j}from"./index.C8u6dyVI.js";import{c as y}from"./utils.CBfrqCZ4.js";import{C as h}from"./circle-check.DBd0IPtX.js";import{c as H}from"./createLucideIcon.DLjuz1K2.js";import"./index.B7WwCSsC.js";import"./index.ViApDAiE.js";/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],N=H("copy",V);var C="Tabs",[W,he]=G(C,[k]),I=k(),[Y,w]=W(C),S=x.forwardRef((o,n)=>{const{__scopeTabs:r,value:i,onValueChange:l,defaultValue:t,orientation:s="horizontal",dir:a,activationMode:d="automatic",...m}=o,u=B(a),[c,g]=q({prop:i,onChange:l,defaultProp:t??"",caller:C});return e.jsx(Y,{scope:r,baseId:L(),value:c,onValueChange:g,orientation:s,dir:u,activationMode:d,children:e.jsx(j.div,{dir:u,"data-orientation":s,...m,ref:n})})});S.displayName=C;var T="TabsList",P=x.forwardRef((o,n)=>{const{__scopeTabs:r,loop:i=!0,...l}=o,t=w(T,r),s=I(r);return e.jsx($,{asChild:!0,...s,orientation:t.orientation,dir:t.dir,loop:i,children:e.jsx(j.div,{role:"tablist","aria-orientation":t.orientation,...l,ref:n})})});P.displayName=T;var O="TabsTrigger",E=x.forwardRef((o,n)=>{const{__scopeTabs:r,value:i,disabled:l=!1,...t}=o,s=w(O,r),a=I(r),d=D(s.baseId,i),m=z(s.baseId,i),u=i===s.value;return e.jsx(U,{asChild:!0,...a,focusable:!l,active:u,children:e.jsx(j.button,{type:"button",role:"tab","aria-selected":u,"aria-controls":m,"data-state":u?"active":"inactive","data-disabled":l?"":void 0,disabled:l,id:d,...t,ref:n,onMouseDown:_(o.onMouseDown,c=>{!l&&c.button===0&&c.ctrlKey===!1?s.onValueChange(i):c.preventDefault()}),onKeyDown:_(o.onKeyDown,c=>{[" ","Enter"].includes(c.key)&&s.onValueChange(i)}),onFocus:_(o.onFocus,()=>{const c=s.activationMode!=="manual";!u&&!l&&c&&s.onValueChange(i)})})})});E.displayName=O;var R="TabsContent",M=x.forwardRef((o,n)=>{const{__scopeTabs:r,value:i,forceMount:l,children:t,...s}=o,a=w(R,r),d=D(a.baseId,i),m=z(a.baseId,i),u=i===a.value,c=x.useRef(u);return x.useEffect(()=>{const g=requestAnimationFrame(()=>c.current=!1);return()=>cancelAnimationFrame(g)},[]),e.jsx(F,{present:l||u,children:({present:g})=>e.jsx(j.div,{"data-state":u?"active":"inactive","data-orientation":a.orientation,role:"tabpanel","aria-labelledby":d,hidden:!g,id:m,tabIndex:0,...s,ref:n,style:{...o.style,animationDuration:c.current?"0s":void 0},children:g&&t})})});M.displayName=R;function D(o,n){return`${o}-trigger-${n}`}function z(o,n){return`${o}-content-${n}`}var K=S,J=P,Z=E,Q=M;function X({className:o,...n}){return e.jsx(K,{"data-slot":"tabs",className:y("flex flex-col gap-2",o),...n})}function ee({className:o,...n}){return e.jsx(J,{"data-slot":"tabs-list",className:y("bg-muted text-muted-foreground inline-flex h-9 w-fit items-center justify-center rounded-lg p-[3px]",o),...n})}function f({className:o,...n}){return e.jsx(Z,{"data-slot":"tabs-trigger",className:y("data-[state=active]:bg-background dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-primary/50 focus-visible:outline-2 focus-visible:outline-primary dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 data-[state=active]:shadow-sm [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",o),...n})}function b({className:o,...n}){return e.jsx(Q,{"data-slot":"tabs-content",className:y("flex-1 outline-none",o),...n})}function xe({lang:o="en"}){const[n,r]=x.useState(null),i=(s,a)=>{navigator.clipboard.writeText(s),r(a),setTimeout(()=>r(null),2e3)},t={en:{hero:{badge:"Technical Documentation",title:"Complete AI Agent Setup Guide",subtitle:"Step-by-step instructions to configure and deploy your autonomous agents",restricted:"🔒 Reserved for ZyatrIA Global Customers"},tabs:{setup:"Initial Setup",ai:"AI Brain Configuration",orchestration:"Orchestration",integrations:"Integrations",rules:"Autonomy Rules",deployment:"Deployment"},setup:{title:"Initial Setup - Prerequisites",description:"Before deploying your AI agents, ensure you have the following:",requirements:[{title:"1. AI Brain Access",items:["OpenAI API Key (GPT-4 access recommended)","Or Azure OpenAI Service endpoint","Or Anthropic Claude API key","Or Mistral AI API key"]},{title:"2. Orchestration Platform",items:["Make.com account (Pro plan recommended)","Or Zapier account (Professional plan)","Webhook endpoint configured"]},{title:"3. Data Storage",items:["Notion workspace (for knowledge base)","Or Airtable base (for structured data)","Or HubSpot account (for CRM integration)","PostgreSQL database (for production)"]},{title:"4. Webflow Integration",items:["Webflow site with CMS collections","Form submission webhooks configured","API access token generated"]}]},aiConfig:{title:"AI Brain Configuration",description:"Configure your AI model and parameters",models:[{name:"OpenAI GPT-4",config:{model:"gpt-4-turbo-preview",temperature:.7,max_tokens:4e3,top_p:1,frequency_penalty:0,presence_penalty:0},useCase:"Best for complex reasoning and multi-language support"},{name:"Azure OpenAI",config:{endpoint:"https://YOUR-RESOURCE.openai.azure.com/",deployment_name:"gpt-4",api_version:"2024-02-01",temperature:.7},useCase:"Enterprise security and compliance requirements"},{name:"Anthropic Claude",config:{model:"claude-3-opus-20240229",max_tokens:4096,temperature:.7},useCase:"Extended context and ethical reasoning"}],systemPrompt:`You are an intelligent AI agent for {COMPANY_NAME}.

Your role: {AGENT_ROLE}

Rules:
- Always respond in the customer's language
- Be professional and helpful
- If unsure, ask for clarification
- Never share sensitive information
- Escalate complex issues to human agents

Context: {BUSINESS_CONTEXT}

Current conversation: {CONVERSATION_HISTORY}`},orchestration:{title:"Orchestration Setup",description:"Configure Make.com or Zapier workflows",makeScenario:{title:"Make.com Scenario Example",steps:["1. Webhook Trigger - Receives form submission","2. Router - Determines agent type needed","3. OpenAI Module - Processes request with GPT-4","4. Data Store - Logs conversation in Notion/Airtable","5. CRM Update - Updates HubSpot/Salesforce","6. Email/SMS - Sends confirmation to customer","7. Slack Notification - Alerts team if needed"]},webhookExample:`{
  "event": "form_submission",
  "form_name": "demo_request",
  "data": {
    "name": "John Doe",
    "email": "john@company.com",
    "company": "Acme Corp",
    "message": "I need help with lead qualification"
  },
  "timestamp": "2024-02-05T10:30:00Z",
  "source": "webflow"
}`},integrations:{title:"Platform Integrations",description:"Connect your AI agents to external platforms",platforms:[{name:"Webflow CMS",icon:"🌐",setup:["Generate API token in Webflow Project Settings","Configure webhook for form submissions","Map CMS collection fields to agent inputs","Set up publish triggers for content updates"],code:`// Webflow API - Get collection items
fetch('https://api.webflow.com/v2/collections/{COLLECTION_ID}/items', {
  headers: {
    'Authorization': 'Bearer YOUR_API_TOKEN',
    'accept-version': '1.0.0'
  }
})`},{name:"HubSpot CRM",icon:"🎯",setup:["Create private app in HubSpot","Configure scopes: contacts, deals, tickets","Get API key from private app settings","Map lead fields to CRM properties"],code:`// HubSpot API - Create contact
fetch('https://api.hubapi.com/crm/v3/objects/contacts', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_HUBSPOT_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    properties: {
      email: 'contact@company.com',
      firstname: 'John',
      lastname: 'Doe',
      company: 'Acme Corp'
    }
  })
})`},{name:"Notion Database",icon:"📝",setup:["Create integration in Notion workspace","Share database with integration","Copy integration token","Define database schema for agent logs"],code:`// Notion API - Create database entry
fetch('https://api.notion.com/v1/pages', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_NOTION_TOKEN',
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    parent: { database_id: 'YOUR_DATABASE_ID' },
    properties: {
      'Name': { title: [{ text: { content: 'Lead Name' } }] },
      'Email': { email: 'lead@company.com' },
      'Status': { select: { name: 'Qualified' } }
    }
  })
})`}]},rules:{title:"Autonomy Rules Configuration",description:"Define when agents act automatically vs. escalate to humans",levels:[{level:"Level 1: Supervised",code:`{
  "autonomy_level": "supervised",
  "rules": {
    "auto_respond": false,
    "require_approval": true,
    "escalate_always": true
  },
  "triggers": {
    "high_value_deal": "> $10,000",
    "legal_matter": true,
    "contract_negotiation": true
  },
  "notification": {
    "slack_channel": "#sales-approvals",
    "email": "manager@company.com"
  }
}`,useCase:"High-stakes decisions requiring human oversight"},{level:"Level 2: Semi-Autonomous",code:`{
  "autonomy_level": "semi_autonomous",
  "rules": {
    "auto_respond": true,
    "confidence_threshold": 0.85,
    "escalate_if": {
      "low_confidence": "< 0.85",
      "complex_query": true,
      "negative_sentiment": true
    }
  },
  "auto_actions": [
    "send_confirmation_email",
    "update_crm",
    "log_conversation",
    "schedule_followup"
  ],
  "escalation": {
    "method": "slack",
    "response_time": "2 hours"
  }
}`,useCase:"Routine tasks with exception handling"},{level:"Level 3: Fully Autonomous",code:`{
  "autonomy_level": "fully_autonomous",
  "rules": {
    "auto_respond": true,
    "auto_execute": true,
    "require_approval": false
  },
  "capabilities": [
    "answer_questions",
    "qualify_leads",
    "book_appointments",
    "send_documents",
    "update_databases"
  ],
  "monitoring": {
    "log_all_actions": true,
    "daily_report": true,
    "alert_on_errors": true
  },
  "boundaries": {
    "max_deal_value": "$5,000",
    "max_discount": "10%",
    "max_followups": 3
  }
}`,useCase:"High-volume, low-risk operations"}]},deployment:{title:"Deployment Checklist",description:"Follow these steps to deploy your AI agents to production",steps:[{phase:"Pre-Deployment",tasks:["✅ All API keys configured and tested","✅ Webhooks responding correctly","✅ Test scenarios completed successfully","✅ Error handling configured","✅ Monitoring dashboards set up","✅ Backup systems in place"]},{phase:"Testing Phase",tasks:["✅ Unit tests for all agent functions","✅ Integration tests with live APIs","✅ Load testing with expected volume","✅ Security audit completed","✅ Data privacy compliance verified","✅ User acceptance testing (UAT)"]},{phase:"Production Launch",tasks:["✅ Deploy to production environment","✅ Enable monitoring and alerts","✅ Activate webhooks and triggers","✅ Start with 10% traffic (canary)","✅ Monitor for 24 hours","✅ Gradually increase to 100%"]},{phase:"Post-Launch",tasks:["✅ Daily performance reviews","✅ Weekly optimization sessions","✅ Monthly accuracy assessments","✅ Continuous training data updates","✅ Regular security audits","✅ Customer feedback integration"]}]},support:{title:"Need Help?",description:"Our technical team is here to support you",channels:[{icon:"📧",label:"Email",value:"tech@zyatria.global"},{icon:"💬",label:"Slack",value:"#technical-support"},{icon:"📞",label:"Phone",value:"+1 (555) 123-4567"},{icon:"📚",label:"Docs",value:"docs.zyatria.global"}]}},fr:{hero:{badge:"Documentation Technique",title:"Guide Complet de Configuration des Agents IA",subtitle:"Instructions étape par étape pour configurer et déployer vos agents autonomes",restricted:"🔒 Réservé aux Clients ZyatrIA Global"},tabs:{setup:"Configuration Initiale",ai:"Configuration IA",orchestration:"Orchestration",integrations:"Intégrations",rules:"Règles d'Autonomie",deployment:"Déploiement"},support:{title:"Besoin d'Aide ?",description:"Notre équipe technique est là pour vous accompagner",channels:[{icon:"📧",label:"Email",value:"tech@zyatria.global"},{icon:"💬",label:"Slack",value:"#support-technique"},{icon:"📞",label:"Téléphone",value:"+1 (555) 123-4567"},{icon:"📚",label:"Docs",value:"docs.zyatria.global"}]}}}[o];return e.jsxs("div",{className:"min-h-screen bg-background",children:[e.jsx("section",{className:"relative py-20 border-b",children:e.jsx("div",{className:"container mx-auto px-4",children:e.jsxs("div",{className:"max-w-4xl mx-auto text-center",children:[e.jsx(A,{className:"mb-4 bg-gradient-primary text-white border-0",children:t.hero.badge}),e.jsx("h1",{className:"text-4xl md:text-6xl font-bold font-heading mb-6 text-gradient-hero",children:t.hero.title}),e.jsx("p",{className:"text-xl text-muted-foreground mb-4",children:t.hero.subtitle}),e.jsx(A,{variant:"secondary",className:"text-sm",children:t.hero.restricted})]})})}),e.jsx("section",{className:"py-12",children:e.jsx("div",{className:"container mx-auto px-4",children:e.jsxs(X,{defaultValue:"setup",className:"max-w-6xl mx-auto",children:[e.jsxs(ee,{className:"grid grid-cols-3 lg:grid-cols-6 mb-8",children:[e.jsx(f,{value:"setup",children:t.tabs.setup}),e.jsx(f,{value:"ai",children:t.tabs.ai}),e.jsx(f,{value:"orchestration",children:t.tabs.orchestration}),e.jsx(f,{value:"integrations",children:t.tabs.integrations}),e.jsx(f,{value:"rules",children:t.tabs.rules}),e.jsx(f,{value:"deployment",children:t.tabs.deployment})]}),e.jsx(b,{value:"setup",className:"space-y-6",children:e.jsxs(p,{className:"p-8",children:[e.jsx("h2",{className:"text-3xl font-bold font-heading mb-4",children:t.setup.title}),e.jsx("p",{className:"text-muted-foreground mb-8",children:t.setup.description}),e.jsx("div",{className:"space-y-6",children:t.setup.requirements.map((s,a)=>e.jsxs("div",{children:[e.jsx("h3",{className:"text-xl font-bold mb-3",children:s.title}),e.jsx("ul",{className:"space-y-2",children:s.items.map((d,m)=>e.jsxs("li",{className:"flex items-start gap-2",children:[e.jsx(h,{className:"w-5 h-5 text-primary flex-shrink-0 mt-0.5"}),e.jsx("span",{children:d})]},m))})]},a))})]})}),e.jsx(b,{value:"ai",className:"space-y-6",children:e.jsxs(p,{className:"p-8",children:[e.jsx("h2",{className:"text-3xl font-bold font-heading mb-4",children:t.aiConfig.title}),e.jsx("p",{className:"text-muted-foreground mb-8",children:t.aiConfig.description}),e.jsxs("div",{className:"space-y-8",children:[t.aiConfig.models.map((s,a)=>e.jsxs("div",{className:"border-l-4 border-primary pl-6",children:[e.jsx("h3",{className:"text-xl font-bold mb-2",children:s.name}),e.jsx("p",{className:"text-sm text-muted-foreground mb-4",children:s.useCase}),e.jsxs("div",{className:"relative",children:[e.jsx("pre",{className:"bg-muted p-4 rounded-lg overflow-x-auto",children:e.jsx("code",{children:JSON.stringify(s.config,null,2)})}),e.jsx(v,{size:"sm",variant:"ghost",className:"absolute top-2 right-2",onClick:()=>i(JSON.stringify(s.config,null,2),`model-${a}`),children:n===`model-${a}`?e.jsx(h,{className:"w-4 h-4"}):e.jsx(N,{className:"w-4 h-4"})})]})]},a)),e.jsxs("div",{className:"mt-8",children:[e.jsx("h3",{className:"text-xl font-bold mb-4",children:"System Prompt Template"}),e.jsxs("div",{className:"relative",children:[e.jsx("pre",{className:"bg-muted p-4 rounded-lg overflow-x-auto text-sm",children:e.jsx("code",{children:t.aiConfig.systemPrompt})}),e.jsx(v,{size:"sm",variant:"ghost",className:"absolute top-2 right-2",onClick:()=>i(t.aiConfig.systemPrompt,"system-prompt"),children:n==="system-prompt"?e.jsx(h,{className:"w-4 h-4"}):e.jsx(N,{className:"w-4 h-4"})})]})]})]})]})}),e.jsx(b,{value:"orchestration",className:"space-y-6",children:e.jsxs(p,{className:"p-8",children:[e.jsx("h2",{className:"text-3xl font-bold font-heading mb-4",children:t.orchestration.title}),e.jsx("p",{className:"text-muted-foreground mb-8",children:t.orchestration.description}),e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-xl font-bold mb-4",children:t.orchestration.makeScenario.title}),e.jsx("div",{className:"space-y-3",children:t.orchestration.makeScenario.steps.map((s,a)=>e.jsxs("div",{className:"flex items-center gap-3 p-3 bg-muted rounded-lg",children:[e.jsx("div",{className:"w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center text-white font-bold flex-shrink-0",children:a+1}),e.jsx("span",{children:s})]},a))})]}),e.jsxs("div",{className:"mt-8",children:[e.jsx("h3",{className:"text-xl font-bold mb-4",children:"Webhook Payload Example"}),e.jsxs("div",{className:"relative",children:[e.jsx("pre",{className:"bg-muted p-4 rounded-lg overflow-x-auto",children:e.jsx("code",{children:t.orchestration.webhookExample})}),e.jsx(v,{size:"sm",variant:"ghost",className:"absolute top-2 right-2",onClick:()=>i(t.orchestration.webhookExample,"webhook"),children:n==="webhook"?e.jsx(h,{className:"w-4 h-4"}):e.jsx(N,{className:"w-4 h-4"})})]})]})]})]})}),e.jsx(b,{value:"integrations",className:"space-y-6",children:e.jsxs(p,{className:"p-8",children:[e.jsx("h2",{className:"text-3xl font-bold font-heading mb-4",children:t.integrations.title}),e.jsx("p",{className:"text-muted-foreground mb-8",children:t.integrations.description}),e.jsx("div",{className:"space-y-8",children:t.integrations.platforms.map((s,a)=>e.jsxs("div",{className:"border-l-4 border-primary pl-6",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-4",children:[e.jsx("span",{className:"text-3xl",children:s.icon}),e.jsx("h3",{className:"text-2xl font-bold",children:s.name})]}),e.jsx("ul",{className:"space-y-2 mb-4",children:s.setup.map((d,m)=>e.jsxs("li",{className:"flex items-start gap-2",children:[e.jsx(h,{className:"w-5 h-5 text-primary flex-shrink-0 mt-0.5"}),e.jsx("span",{className:"text-sm",children:d})]},m))}),e.jsxs("div",{className:"relative",children:[e.jsx("pre",{className:"bg-muted p-4 rounded-lg overflow-x-auto text-xs",children:e.jsx("code",{children:s.code})}),e.jsx(v,{size:"sm",variant:"ghost",className:"absolute top-2 right-2",onClick:()=>i(s.code,`platform-${a}`),children:n===`platform-${a}`?e.jsx(h,{className:"w-4 h-4"}):e.jsx(N,{className:"w-4 h-4"})})]})]},a))})]})}),e.jsx(b,{value:"rules",className:"space-y-6",children:e.jsxs(p,{className:"p-8",children:[e.jsx("h2",{className:"text-3xl font-bold font-heading mb-4",children:t.rules.title}),e.jsx("p",{className:"text-muted-foreground mb-8",children:t.rules.description}),e.jsx("div",{className:"space-y-8",children:t.rules.levels.map((s,a)=>e.jsxs("div",{className:"border-l-4 border-primary pl-6",children:[e.jsx("h3",{className:"text-xl font-bold mb-2",children:s.level}),e.jsx("p",{className:"text-sm text-muted-foreground mb-4",children:s.useCase}),e.jsxs("div",{className:"relative",children:[e.jsx("pre",{className:"bg-muted p-4 rounded-lg overflow-x-auto text-xs",children:e.jsx("code",{children:s.code})}),e.jsx(v,{size:"sm",variant:"ghost",className:"absolute top-2 right-2",onClick:()=>i(s.code,`level-${a}`),children:n===`level-${a}`?e.jsx(h,{className:"w-4 h-4"}):e.jsx(N,{className:"w-4 h-4"})})]})]},a))})]})}),e.jsx(b,{value:"deployment",className:"space-y-6",children:e.jsxs(p,{className:"p-8",children:[e.jsx("h2",{className:"text-3xl font-bold font-heading mb-4",children:t.deployment.title}),e.jsx("p",{className:"text-muted-foreground mb-8",children:t.deployment.description}),e.jsx("div",{className:"space-y-8",children:t.deployment.steps.map((s,a)=>e.jsxs("div",{children:[e.jsxs("h3",{className:"text-xl font-bold mb-4 flex items-center gap-2",children:[e.jsx("span",{className:"w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center text-white text-sm",children:a+1}),s.phase]}),e.jsx("div",{className:"space-y-2 ml-10",children:s.tasks.map((d,m)=>e.jsx("div",{className:"flex items-center gap-2 p-2 hover:bg-muted rounded",children:e.jsx("span",{children:d})},m))})]},a))})]})})]})})}),e.jsx("section",{className:"py-20 bg-muted/30",children:e.jsx("div",{className:"container mx-auto px-4",children:e.jsxs(p,{className:"p-12 max-w-4xl mx-auto",children:[e.jsx("h2",{className:"text-3xl font-bold font-heading text-center mb-4",children:t.support.title}),e.jsx("p",{className:"text-center text-muted-foreground mb-8",children:t.support.description}),e.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-4 gap-6",children:t.support.channels.map((s,a)=>e.jsxs("div",{className:"text-center p-4",children:[e.jsx("div",{className:"text-4xl mb-2",children:s.icon}),e.jsx("h3",{className:"font-bold mb-1",children:s.label}),e.jsx("p",{className:"text-sm text-muted-foreground",children:s.value})]},a))})]})})})]})}export{xe as default};
