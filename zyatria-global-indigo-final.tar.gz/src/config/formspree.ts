


/**
 * Configuration Formspree pour ZyatrIA Global
 * Email de réception : ZyatrIA.contact@gmail.com
 */

export const formspreeConfig = {
  // Form ID Formspree public (gratuit - 50 soumissions/mois)
  contactFormId: 'xeelvrdl',
  demoFormId: 'xeelvrdl',
  
  // Email de contact
  contactEmail: 'ZyatrIA.contact@gmail.com',
  
  // URL de base Formspree
  baseUrl: 'https://formspree.io/f',
} as const;

// Helper pour obtenir l'URL complète du formulaire
export const getFormspreeUrl = (formType: 'contact' | 'demo' = 'contact') => {
  const formId = formType === 'contact' ? formspreeConfig.contactFormId : formspreeConfig.demoFormId;
  return `${formspreeConfig.baseUrl}/${formId}`;
};



