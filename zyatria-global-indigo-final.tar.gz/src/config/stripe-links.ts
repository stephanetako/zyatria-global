/**
 * STRIPE PAYMENT LINKS CONFIGURATION
 * 
 * Ces liens sont générés depuis votre dashboard Stripe.
 * Pour modifier les prix ou créer de nouveaux liens :
 * 1. Allez sur https://dashboard.stripe.com
 * 2. Produits → Sélectionnez un produit → Créer un lien de paiement
 * 3. Copiez le lien et mettez-le à jour ici
 */

export const STRIPE_PAYMENT_LINKS = {
  starter: "https://buy.stripe.com/14A14o14Sglm2yabCW",
  business: "https://buy.stripe.com/7sY14odRE7OQ7Su8qK",
  enterprise: "https://buy.stripe.com/aFa3cw7tg8SU3Ce6iC",
} as const;

export type StripePlan = keyof typeof STRIPE_PAYMENT_LINKS;

/**
 * Obtenir le lien de paiement pour un plan spécifique
 */
export function getStripeLink(plan: StripePlan): string {
  return STRIPE_PAYMENT_LINKS[plan];
}

/**
 * Vérifier si un lien Stripe est en mode test
 */
export function isTestMode(link: string): boolean {
  return link.includes('/test_');
}

/**
 * Informations des plans (pour référence)
 */
export const PLAN_INFO = {
  starter: {
    name: "Plan Starter",
    price: 69,
    currency: "CAD",
    period: "mois",
    trial: 7, // jours
  },
  business: {
    name: "Plan Business",
    price: 169,
    currency: "CAD",
    period: "mois",
    trial: 7, // jours
  },
  enterprise: {
    name: "Plan Enterprise",
    price: 500,
    currency: "CAD",
    period: "mois",
    trial: 7, // jours
  },
} as const;
