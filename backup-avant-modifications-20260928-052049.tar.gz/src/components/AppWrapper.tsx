import React from 'react';
import { LanguageProvider } from '../lib/language-context';
import NavigationDesignSystem from './NavigationDesignSystem';
import HeroDesignSystem from './HeroDesignSystem';
import TrustStatsSimple from './TrustStatsSimple';
import Services from './Services';
import MicroAgents from './MicroAgents';
import RoadmapDesignSystem from './RoadmapDesignSystem';
import Pricing from './Pricing';
import TestimonialsDesignSystem from './TestimonialsDesignSystem';
import FAQDesignSystem from './FAQDesignSystem';
import CTAFinal from './CTAFinal';
import FooterDesignSystem from './FooterDesignSystem';
import SuperChatbotFamily from './SuperChatbotFamily';

const AppWrapper: React.FC = () => {
  return (
    <LanguageProvider>
      <div className="min-h-screen bg-background">
        <NavigationDesignSystem />
        <main>
          <HeroDesignSystem />
          <TrustStatsSimple />
          <Services />
          <MicroAgents />
          <RoadmapDesignSystem />
          <Pricing />
          <TestimonialsDesignSystem />
          <FAQDesignSystem />
          <CTAFinal />
        </main>
        <FooterDesignSystem />
        <SuperChatbotFamily />
      </div>
    </LanguageProvider>
  );
};

export default AppWrapper;













